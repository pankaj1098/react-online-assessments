import { useLocation } from 'react-router-dom'
import { PageBreadcrumbs } from '@/components/layout/PageBreadcrumbs'
import { PageHero } from '@/components/layout/PageHero'
import { findModuleByPath } from '@/config/modules'
import { usePageMeta } from '@/hooks/usePageMeta'
import NotFoundPage from '@/features/errors/pages/NotFoundPage'

/** Landing page for portal areas that have not been migrated yet. */
export default function ModulePage() {
  const { pathname } = useLocation()
  const module = findModuleByPath(pathname)
  usePageMeta(module?.name, module?.summary)
  if (!module) return <NotFoundPage />
  return (
    <div className="mx-auto max-w-[100rem]">
      <PageBreadcrumbs items={[{ label: module.name }]} />
      <PageHero icon={<module.icon />} title={module.name} description={module.summary} />
      <div className="rounded-2xl border border-border bg-card p-8 text-center shadow-sm">
        <p className="font-semibold">This section is being moved to the new portal.</p>
        <p className="mt-2 text-muted-foreground">
          {module.name} tools will appear here soon. Until then, continue to use the existing portal
          for this area.
        </p>
      </div>
    </div>
  )
}
