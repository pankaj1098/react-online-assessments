import { useAbility } from '@casl/react'
import { Eye, IdCard, ListFilter, Pencil, Plus, RotateCcw, Search, X } from 'lucide-react'
import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { EmptyState } from '@/components/common/EmptyState'
import { PageBreadcrumbs } from '@/components/layout/PageBreadcrumbs'
import { PageHero } from '@/components/layout/PageHero'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input, NativeSelect } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { useDebouncedValue } from '@/hooks/useDebouncedValue'
import { usePageMeta } from '@/hooks/usePageMeta'
import { getErrorMessage } from '@/lib/api-error'
import { formatDateTime } from '@/lib/date'
import { GatePassDetailsDialog } from '../components/GatePassDetailsDialog'
import { GatePassStatusBadge } from '../components/GatePassStatusBadge'
import { useGatePassList } from '../hooks'
import { emptyFilters, gatePassPurposes, gatePassStatuses } from '../types'

const PAGE_SIZES = [10, 25, 50]

const columns = [
  '#',
  'Place',
  'Date & Time',
  'Purpose',
  'Contact Person',
  'Status',
  'Created On',
  'Actions',
]

export default function GatePassListPage() {
  usePageMeta('Gate Pass', 'Create, track and manage your gate pass requests.')
  const ability = useAbility()
  const navigate = useNavigate()
  const location = useLocation()
  const [notice, setNotice] = useState(location.state?.notice ?? null)
  const [draft, setDraft] = useState(emptyFilters)
  const [applied, setApplied] = useState(emptyFilters)
  const [filterError, setFilterError] = useState('')
  const [search, setSearch] = useState('')
  const [pageSize, setPageSize] = useState(10)
  const [page, setPage] = useState(1)
  const [viewing, setViewing] = useState(null)
  const debouncedSearch = useDebouncedValue(search)
  const { data, isPending, isError, error, refetch, isPlaceholderData } = useGatePassList({
    ...applied,
    search: debouncedSearch,
    page,
    pageSize,
  })
  const items = data?.items ?? []
  const total = data?.total ?? 0
  const pageCount = Math.max(1, Math.ceil(total / pageSize))
  const currentPage = Math.min(page, pageCount)
  const firstShown = total === 0 ? 0 : (currentPage - 1) * pageSize + 1
  const lastShown = Math.min(currentPage * pageSize, total)
  function applyFilters(event) {
    event.preventDefault()
    if (draft.from && draft.to && draft.from > draft.to) {
      setFilterError('"From Date" must be on or before "To Date".')
      return
    }
    setFilterError('')
    setApplied(draft)
    setPage(1)
  }
  function resetFilters() {
    setDraft(emptyFilters)
    setApplied(emptyFilters)
    setFilterError('')
    setSearch('')
    setPage(1)
  }
  return (
    <div className="mx-auto max-w-[100rem]">
      <PageBreadcrumbs items={[{ label: 'Gate Pass' }]} />
      <PageHero
        icon={<IdCard />}
        title="Gate Pass"
        description="Create, track and manage gate pass requests."
        action={
          ability.can('create', 'gate-pass') ? (
            <Button asChild className="max-sm:w-full">
              <Link to="/gate-pass/create">
                <Plus aria-hidden="true" /> Create Gate Pass Request
              </Link>
            </Button>
          ) : undefined
        }
      />

      {notice && (
        <div
          role="status"
          className="mb-5 flex items-center justify-between gap-3 rounded-xl bg-success-soft px-4 py-3 text-success"
        >
          <p className="font-semibold">{notice}</p>
          <button
            type="button"
            aria-label="Dismiss message"
            onClick={() => setNotice(null)}
            className="rounded p-1 hover:bg-card/50"
          >
            <X className="size-4" aria-hidden="true" />
          </button>
        </div>
      )}

      <Card className="mb-5 p-5">
        <form
          onSubmit={applyFilters}
          className="grid items-end gap-4 sm:grid-cols-2 lg:grid-cols-[repeat(4,minmax(0,1fr))_auto_auto]"
          aria-label="Filter gate pass requests"
        >
          <div className="grid gap-1.5 text-sm">
            <label htmlFor="filter-from">From Date</label>
            <Input
              id="filter-from"
              type="date"
              value={draft.from}
              onChange={(e) => setDraft({ ...draft, from: e.target.value })}
              className="h-12"
            />
          </div>
          <div className="grid gap-1.5 text-sm">
            <label htmlFor="filter-to">To Date</label>
            <Input
              id="filter-to"
              type="date"
              value={draft.to}
              onChange={(e) => setDraft({ ...draft, to: e.target.value })}
              className="h-12"
            />
          </div>
          <div className="grid gap-1.5 text-sm">
            <label htmlFor="filter-purpose">Purpose</label>
            <NativeSelect
              id="filter-purpose"
              value={draft.purpose}
              onChange={(e) => setDraft({ ...draft, purpose: e.target.value })}
              className="h-12"
            >
              <option value="">All Purpose</option>
              {gatePassPurposes.map((purpose) => (
                <option key={purpose} value={purpose}>
                  {purpose}
                </option>
              ))}
            </NativeSelect>
          </div>
          <div className="grid gap-1.5 text-sm">
            <label htmlFor="filter-status">Status</label>
            <NativeSelect
              id="filter-status"
              value={draft.status}
              onChange={(e) => setDraft({ ...draft, status: e.target.value })}
              className="h-12"
            >
              <option value="">All Status</option>
              {gatePassStatuses.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </NativeSelect>
          </div>
          <Button type="button" variant="outline" className="h-12" onClick={resetFilters}>
            <RotateCcw aria-hidden="true" /> Reset
          </Button>
          <Button type="submit" className="h-12">
            <ListFilter aria-hidden="true" /> Apply
          </Button>
          {filterError && (
            <p role="alert" className="text-sm text-destructive sm:col-span-full">
              {filterError}
            </p>
          )}
        </form>
      </Card>

      <Card className="p-5">
        <div className="mb-5 flex flex-col gap-3 text-sm sm:flex-row sm:items-center sm:justify-between">
          <label className="flex items-center gap-2.5">
            Show
            <NativeSelect
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value))
                setPage(1)
              }}
              className="h-10 w-20"
            >
              {PAGE_SIZES.map((size) => (
                <option key={size} value={size}>
                  {size}
                </option>
              ))}
            </NativeSelect>
            entries
          </label>
          <div className="w-full sm:w-[min(27.5rem,52%)]">
            <Input
              type="search"
              icon={<Search />}
              aria-label="Search gate pass requests"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value)
                setPage(1)
              }}
              placeholder="Search by place, purpose or contact person..."
              className="h-12"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table
            className="w-full border-separate border-spacing-0 text-sm"
            aria-busy={isPlaceholderData}
          >
            <caption className="sr-only">Your gate pass requests</caption>
            <thead>
              <tr>
                {columns.map((title, index) => (
                  <th
                    key={title}
                    scope="col"
                    className={`h-14 bg-primary-soft px-4 text-left font-bold whitespace-nowrap ${index === 0 ? 'rounded-tl-lg' : ''} ${index === columns.length - 1 ? 'rounded-tr-lg' : ''}`}
                  >
                    {title}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className={isPlaceholderData ? 'opacity-60' : undefined}>
              {isPending &&
                [0, 1, 2].map((row) => (
                  <tr key={row}>
                    <td colSpan={columns.length} className="border-b border-border p-3">
                      <Skeleton className="h-12" />
                    </td>
                  </tr>
                ))}
              {items.map((request, index) => (
                <tr key={request.id}>
                  {[
                    (currentPage - 1) * pageSize + index + 1,
                    request.place,
                    formatDateTime(request.dateTime),
                    request.purpose,
                    request.contactPerson,
                  ].map((cell, cellIndex) => (
                    <td
                      key={cellIndex}
                      className="h-[4.5rem] border-b border-border px-4 whitespace-nowrap"
                    >
                      {cell}
                    </td>
                  ))}
                  <td className="h-[4.5rem] border-b border-border px-4 whitespace-nowrap">
                    <GatePassStatusBadge status={request.status} />
                  </td>
                  <td className="h-[4.5rem] border-b border-border px-4 whitespace-nowrap">
                    {formatDateTime(request.createdOn)}
                  </td>
                  <td className="h-[4.5rem] border-b border-border px-4 whitespace-nowrap">
                    <div className="flex gap-2">
                      {ability.can('update', 'gate-pass') && (
                        <Button
                          variant="outline"
                          size="icon"
                          aria-label={`Edit request ${request.id}`}
                          title="Edit request"
                          onClick={() =>
                            navigate(`/gate-pass/${encodeURIComponent(request.id)}/edit`)
                          }
                        >
                          <Pencil aria-hidden="true" />
                        </Button>
                      )}
                      <Button
                        variant="outline"
                        size="icon"
                        aria-label={`View request ${request.id}`}
                        title="View request"
                        onClick={() => setViewing(request)}
                      >
                        <Eye aria-hidden="true" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {isError && (
            <div role="alert" className="py-8 text-center text-sm">
              <p className="text-destructive">{getErrorMessage(error)}</p>
              <Button variant="link" onClick={() => void refetch()}>
                Try again
              </Button>
            </div>
          )}
          {!isPending && !isError && items.length === 0 && (
            <EmptyState>No gate pass requests found.</EmptyState>
          )}
        </div>

        <div className="mt-5 flex flex-col gap-3 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <span>
            Showing {firstShown} to {lastShown} of {total} entries
          </span>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={currentPage <= 1}
              onClick={() => setPage(currentPage - 1)}
            >
              &lsaquo; Previous
            </Button>
            <span
              aria-current="page"
              className="grid h-9 min-w-9 place-items-center rounded-lg bg-primary px-3 font-semibold text-primary-foreground"
            >
              {currentPage}
            </span>
            <Button
              variant="outline"
              size="sm"
              disabled={currentPage >= pageCount}
              onClick={() => setPage(currentPage + 1)}
            >
              Next &rsaquo;
            </Button>
          </div>
        </div>
      </Card>

      <GatePassDetailsDialog request={viewing} onClose={() => setViewing(null)} />
    </div>
  )
}
