import { IdCard } from 'lucide-react'
import { useNavigate, useParams } from 'react-router-dom'
import { PageBreadcrumbs } from '@/components/layout/PageBreadcrumbs'
import { PageHero } from '@/components/layout/PageHero'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { usePageMeta } from '@/hooks/usePageMeta'
import { getErrorMessage, toApiError } from '@/lib/api-error'
import { GatePassForm } from '../components/GatePassForm'
import { useCreateGatePass, useGatePass, useUpdateGatePass } from '../hooks'

const blankForm = {
  place: '',
  dateTime: '',
  contactPerson: '',
  purpose: '',
  reason: '',
}

export default function GatePassFormPage() {
  const { id } = useParams()
  const isEdit = Boolean(id)
  const title = isEdit ? 'Edit Gate Pass Request' : 'Create Gate Pass Request'
  usePageMeta(title, 'Raise or update a gate pass request for an official or personal visit.')
  const navigate = useNavigate()
  const existing = useGatePass(id)
  const create = useCreateGatePass()
  const update = useUpdateGatePass(id ?? '')
  const mutation = isEdit ? update : create
  function goToList(notice) {
    void navigate('/gate-pass', { state: notice ? { notice } : undefined })
  }
  function handleSubmit(values) {
    mutation.mutate(values, {
      onSuccess: () =>
        goToList(
          isEdit ? 'Gate pass request updated.' : 'Gate pass request submitted for approval.',
        ),
    })
  }
  let body
  if (isEdit && existing.isPending) {
    body = (
      <div className="space-y-4 p-8" role="status">
        <span className="sr-only">Loading request</span>
        {[0, 1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-12" />
        ))}
      </div>
    )
  } else if (isEdit && existing.isError) {
    const status = toApiError(existing.error).status
    body = (
      <div role="alert" className="p-8 text-center">
        <p className="font-semibold">
          {status === 404
            ? 'This gate pass request could not be found.'
            : getErrorMessage(existing.error)}
        </p>
        <Button className="mt-5" onClick={() => goToList()}>
          Back to Gate Pass
        </Button>
      </div>
    )
  } else {
    const defaults = existing.data
      ? {
          place: existing.data.place,
          dateTime: existing.data.dateTime,
          contactPerson: existing.data.contactPerson,
          purpose: existing.data.purpose,
          reason: existing.data.reason,
        }
      : blankForm
    body = (
      <GatePassForm
        defaultValues={defaults}
        mode={isEdit ? 'edit' : 'create'}
        isSubmitting={mutation.isPending}
        submitError={mutation.error}
        onSubmit={handleSubmit}
        onCancel={() => goToList()}
      />
    )
  }
  return (
    <div className="mx-auto max-w-[100rem]">
      <PageBreadcrumbs items={[{ label: 'Gate Pass', to: '/gate-pass' }, { label: title }]} />
      <Card className="overflow-hidden">
        <PageHero
          variant="embedded"
          icon={<IdCard />}
          title={title}
          description="Raise a new gate pass request for official or personal visit."
        />
        {body}
      </Card>
    </div>
  )
}
