import { Navigate } from 'react-router-dom'
import { AppShell } from '@/components/layout/AppShell'
import { PageLoader } from '@/components/common/PageLoader'
import { modules } from '@/config/modules'
import RouteErrorPage from '@/features/errors/pages/RouteErrorPage'
import { GuestRoute, ProtectedRoute, RequireAbility } from './guards'

/** Pages are lazy-loaded so each one becomes its own small JavaScript chunk. */
const page = (load) => ({
  lazy: async () => ({ Component: (await load()).default }),
})

const moduleRoutes = modules
  .filter((module) => module.id !== 'home' && module.id !== 'gate-pass')
  .map((module) => ({
    path: module.path,
    element: <RequireAbility subject={module.id} />,
    children: [{ index: true, ...page(() => import('@/features/modules/pages/ModulePage')) }],
  }))

/** Route table. Kept separate from the router instance so tests can use an in-memory router. */
export const routes = [
  {
    errorElement: <RouteErrorPage />,
    hydrateFallbackElement: <PageLoader />,
    children: [
      {
        element: <GuestRoute />,
        children: [{ path: '/login', ...page(() => import('@/features/auth/pages/LoginPage')) }],
      },
      {
        element: <ProtectedRoute />,
        children: [
          {
            element: <AppShell />,
            children: [
              { index: true, ...page(() => import('@/features/dashboard/pages/DashboardPage')) },
              {
                path: 'gate-pass',
                element: <RequireAbility subject="gate-pass" />,
                children: [
                  {
                    index: true,
                    ...page(() => import('@/features/gate-pass/pages/GatePassListPage')),
                  },
                  {
                    path: 'create',
                    ...page(() => import('@/features/gate-pass/pages/GatePassFormPage')),
                  },
                  {
                    path: ':id/edit',
                    ...page(() => import('@/features/gate-pass/pages/GatePassFormPage')),
                  },
                ],
              },
              ...moduleRoutes,
              { path: '*', ...page(() => import('@/features/errors/pages/NotFoundPage')) },
            ],
          },
        ],
      },
      { path: '/index.html', element: <Navigate to="/" replace /> },
    ],
  },
]
