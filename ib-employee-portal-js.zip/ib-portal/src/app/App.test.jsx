import { render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { createMemoryRouter, RouterProvider } from 'react-router-dom'
import { beforeEach, describe, expect, it } from 'vitest'
import { useAuthStore } from '@/features/auth/store/authStore'
import { queryClient } from '@/lib/query-client'
import { AppProviders } from './providers/AppProviders'
import { routes } from './router/routes'

function renderApp(path) {
  const router = createMemoryRouter(routes, { initialEntries: [path] })
  return render(
    <AppProviders>
      <RouterProvider router={router} />
    </AppProviders>,
  )
}

function signIn(roles = ['employee']) {
  useAuthStore.getState().setSession({
    accessToken: 't',
    user: { employeeId: '10039601', name: 'Test User', roles },
  })
}
beforeEach(() => {
  useAuthStore.getState().clear()
  queryClient.clear()
})
describe('routing and auth', () => {
  it('sends signed-out visitors to the login page with a single h1 and its own title', async () => {
    renderApp('/gate-pass')
    expect(
      await screen.findByRole('heading', { level: 1, name: /employee portal/i }),
    ).toBeInTheDocument()
    expect(screen.getAllByRole('heading', { level: 1 })).toHaveLength(1)
    expect(document.title).toBe('Sign in | IB Group Employee Portal')
  })
  it('returns the user to the page they originally asked for after login', async () => {
    const user = userEvent.setup()
    renderApp('/gate-pass')
    await user.type(await screen.findByLabelText(/employee id/i), '10039601')
    await user.type(screen.getByLabelText(/^password/i), 'secret')
    await user.click(screen.getByRole('button', { name: 'Login' }))
    expect(await screen.findByRole('heading', { level: 1, name: 'Gate Pass' })).toBeInTheDocument()
  })
  it('validates the login form before calling the API', async () => {
    const user = userEvent.setup()
    renderApp('/login')
    await user.click(await screen.findByRole('button', { name: 'Login' }))
    expect(await screen.findByText('Enter your employee ID or username.')).toBeInTheDocument()
    expect(screen.getByText('Enter your password.')).toBeInTheDocument()
  })
  it('signs in and lands on the dashboard', async () => {
    const user = userEvent.setup()
    renderApp('/login')
    await user.type(await screen.findByLabelText(/employee id/i), '10039601')
    await user.type(screen.getByLabelText(/^password/i), 'secret')
    await user.click(screen.getByRole('button', { name: 'Login' }))
    expect(
      await screen.findByRole('heading', { level: 1, name: /welcome back, 10039601/i }),
    ).toBeInTheDocument()
    expect(document.title).toBe('Home | IB Group Employee Portal')
  })
  it('shows a custom 404 page for unknown addresses', async () => {
    signIn()
    renderApp('/does-not-exist')
    expect(
      await screen.findByRole('heading', { level: 1, name: 'Page not found' }),
    ).toBeInTheDocument()
    expect(document.title).toBe('Page not found | IB Group Employee Portal')
  })
  it('hides Admin from employees and blocks direct access', async () => {
    signIn(['employee'])
    renderApp('/admin')
    expect(
      await screen.findByRole('heading', { level: 1, name: 'Access denied' }),
    ).toBeInTheDocument()
    expect(
      within(screen.getByRole('navigation', { name: 'Main navigation' })).queryByText('Admin'),
    ).toBeNull()
  })
})
describe('gate pass', () => {
  it('lists requests, validates the form, then creates a new request', async () => {
    signIn()
    const user = userEvent.setup()
    renderApp('/gate-pass')
    expect(await screen.findByRole('heading', { level: 1, name: 'Gate Pass' })).toBeInTheDocument()
    expect(await screen.findByRole('button', { name: 'View request GP-1001' })).toBeInTheDocument()
    await user.click(screen.getByRole('link', { name: /create gate pass request/i }))
    expect(
      await screen.findByRole('heading', { level: 1, name: 'Create Gate Pass Request' }),
    ).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: /submit request/i }))
    expect(await screen.findByText('Enter the place.')).toBeInTheDocument()
    expect(screen.getByText('Select the purpose of visit.')).toBeInTheDocument()
    await user.type(screen.getByLabelText(/^place/i), 'Warehouse')
    await user.type(screen.getByLabelText(/date & time/i), '2026-12-01T10:30')
    await user.type(screen.getByLabelText(/contact person/i), 'R. Sharma')
    await user.selectOptions(screen.getByLabelText(/^purpose/i), 'Official')
    await user.type(screen.getByLabelText(/^reason/i), 'Stock audit')
    await user.click(screen.getByRole('button', { name: /submit request/i }))
    expect(await screen.findByRole('status')).toHaveTextContent('submitted for approval')
    await waitFor(() => expect(screen.getByText('Warehouse')).toBeInTheDocument())
    expect(within(screen.getByRole('table')).getByText('Pending')).toBeInTheDocument()
  })
})
