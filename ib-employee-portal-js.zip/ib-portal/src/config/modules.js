import {
  FileText,
  House,
  IdCard,
  Megaphone,
  Monitor,
  Receipt,
  Settings,
  UserRound,
  Users,
} from 'lucide-react'

/** Every area of the portal. Drives the sidebar, routes and permission checks. */
export const modules = [
  {
    id: 'home',
    name: 'Home',
    path: '/',
    icon: House,
    summary: 'Your applications and notifications.',
  },
  {
    id: 'hr',
    name: 'HR',
    path: '/hr',
    icon: Users,
    summary: 'Human resources services and requests.',
  },
  {
    id: 'it',
    name: 'IT',
    path: '/it',
    icon: Monitor,
    summary: 'IT support, assets and access requests.',
  },
  {
    id: 'taxes',
    name: 'Taxes',
    path: '/taxes',
    icon: Receipt,
    summary: 'Tax declarations and statements.',
  },
  {
    id: 'ibigian-self-service',
    name: 'Ibigian Self Service',
    path: '/self-service',
    icon: UserRound,
    summary: 'View and manage your own employee details.',
  },
  {
    id: 'admin',
    name: 'Admin',
    path: '/admin',
    icon: Settings,
    summary: 'Office administration services.',
  },
  {
    id: 'corp-communication',
    name: 'Corp Communication',
    path: '/corp-communication',
    icon: Megaphone,
    summary: 'Company announcements and communication.',
  },
  {
    id: 'corporate-policies',
    name: 'Corporate Policies',
    path: '/corporate-policies',
    icon: FileText,
    summary: 'Company policies and guidelines.',
  },
  {
    id: 'gate-pass',
    name: 'Gate Pass',
    path: '/gate-pass',
    icon: IdCard,
    summary: 'Create, track and manage gate pass requests.',
  },
]

export function findModuleByPath(pathname) {
  return modules.find(
    (m) => m.path !== '/' && (pathname === m.path || pathname.startsWith(`${m.path}/`)),
  )
}
