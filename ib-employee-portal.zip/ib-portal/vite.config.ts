import { fileURLToPath, URL } from 'node:url'

import babel from '@rolldown/plugin-babel'
import tailwindcss from '@tailwindcss/vite'
import react, { reactCompilerPreset } from '@vitejs/plugin-react'
import { loadEnv } from 'vite'
import { defineConfig } from 'vitest/config'

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  const isTest = mode === 'test'
  const useMock = env.VITE_USE_MOCK === 'true'

  if (mode === 'production' && useMock) {
    throw new Error('VITE_USE_MOCK must be "false" for production builds.')
  }

  return {
    plugins: [
      react(),
      // React Compiler (auto-memoisation). Skipped in tests to keep them fast.
      ...(isTest ? [] : [babel({ presets: [reactCompilerPreset()] })]),
      tailwindcss(),
    ],
    define: {
      // Replaced at build time so mock code is removed entirely from production bundles.
      __USE_MOCK__: JSON.stringify(useMock),
    },
    resolve: {
      alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) },
    },
    server: {
      port: 5173,
      // Forward /api calls to the .NET Web API during development (avoids CORS).
      proxy: env.VITE_API_PROXY_TARGET
        ? {
            '/api': {
              target: env.VITE_API_PROXY_TARGET,
              changeOrigin: true,
              secure: false,
            },
          }
        : undefined,
    },
    build: {
      target: 'es2022',
      // Never ship source maps to production.
      sourcemap: false,
      chunkSizeWarningLimit: 400,
      rolldownOptions: {
        output: {
          // Keep long-lived third-party code in separate, cache-friendly chunks.
          codeSplitting: {
            groups: [
              {
                name: 'react-vendor',
                test: /node_modules[\\/](react|react-dom|react-router|react-router-dom|scheduler)[\\/]/,
                priority: 30,
              },
              {
                name: 'data-vendor',
                test: /node_modules[\\/](@tanstack|axios|zustand|zod|@casl)[\\/]/,
                priority: 20,
              },
              {
                name: 'ui-vendor',
                test: /node_modules[\\/](@radix-ui|lucide-react|react-hook-form|@hookform|class-variance-authority|clsx|tailwind-merge)[\\/]/,
                priority: 10,
              },
            ],
          },
        },
      },
    },
    test: {
      globals: true,
      environment: 'jsdom',
      setupFiles: ['./src/test/setup.ts'],
      css: false,
      restoreMocks: true,
    },
  }
})
