export type ApplicationTone = 'orange' | 'green' | 'purple' | 'rose' | 'teal' | 'amber' | 'blue'

export interface PortalApplication {
  id: string
  name: string
  group: string
  tone: ApplicationTone
  /** Short text shown inside the badge when the app has no logo. */
  mark: string
  /** Use the IB Group logo as the badge instead of `mark`. */
  useLogo?: boolean
  /** Where the tile opens. Leave empty until the real URL is known - the tile then shows as "coming soon". */
  href: string
}

/** Applications shown on the dashboard. Fill in `href` for each app. */
export const applications: readonly PortalApplication[] = [
  { id: 'i-learn', name: 'I-Learn', group: 'Learning', tone: 'orange', mark: 'i-L', href: '' },
  {
    id: 'ib-next',
    name: 'IB NEXT',
    group: 'Workplace',
    tone: 'green',
    mark: 'IB',
    useLogo: true,
    href: '',
  },
  { id: 'ideabank', name: 'IDEABANK', group: 'Innovation', tone: 'purple', mark: 'Idea', href: '' },
  {
    id: 'grim',
    name: 'GRIM Material Request',
    group: 'Operations',
    tone: 'rose',
    mark: 'IB',
    useLogo: true,
    href: '',
  },
  {
    id: 'website',
    name: 'Corporate Website',
    group: 'Workplace',
    tone: 'teal',
    mark: 'IB',
    useLogo: true,
    href: '',
  },
  { id: 'crm', name: 'CRM', group: 'Sales', tone: 'amber', mark: 'Connect', href: '' },
  {
    id: 'email',
    name: 'Email',
    group: 'Workplace',
    tone: 'blue',
    mark: 'IB',
    useLogo: true,
    href: '',
  },
  {
    id: 'vehicle-tracking',
    name: 'Vehicle Tracking',
    group: 'Operations',
    tone: 'green',
    mark: 'Track',
    href: '',
  },
  {
    id: 'vision-360',
    name: 'VISION-360 (Compliance)',
    group: 'Compliance',
    tone: 'rose',
    mark: 'IB',
    useLogo: true,
    href: '',
  },
]
