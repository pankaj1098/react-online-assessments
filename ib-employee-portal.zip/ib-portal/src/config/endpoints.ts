/**
 * .NET Web API routes, relative to VITE_API_BASE_URL.
 * Adjust these to match the real controllers - this is the only file that knows the URLs.
 */
export const endpoints = {
  auth: {
    login: '/auth/login',
    refresh: '/auth/refresh',
    logout: '/auth/logout',
  },
  dashboard: {
    announcements: '/announcements',
    notifications: '/notifications',
  },
  gatePass: {
    collection: '/gate-passes',
    item: (id: string) => `/gate-passes/${encodeURIComponent(id)}`,
  },
} as const
