import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'

interface UiState {
  sidebarCollapsed: boolean
  mobileNavOpen: boolean
  applicationSearch: string
  toggleSidebar: () => void
  setMobileNavOpen: (open: boolean) => void
  setApplicationSearch: (value: string) => void
}

export const useUiStore = create<UiState>()(
  persist(
    (set) => ({
      sidebarCollapsed: false,
      mobileNavOpen: false,
      applicationSearch: '',
      toggleSidebar: () => set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
      setMobileNavOpen: (open) => set({ mobileNavOpen: open }),
      setApplicationSearch: (value) => set({ applicationSearch: value }),
    }),
    {
      name: 'ib-portal-ui',
      storage: createJSONStorage(() => window.localStorage),
      partialize: ({ sidebarCollapsed }) => ({ sidebarCollapsed }),
    },
  ),
)
