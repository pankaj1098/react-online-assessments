import { useEffect } from 'react'

import { buildTitle, site } from '@/config/site'

/**
 * Sets the browser tab title and meta description for the current page.
 * Every page calls this once so each one has a unique title and description.
 */
export function usePageMeta(title?: string, description: string = site.description): void {
  useEffect(() => {
    document.title = buildTitle(title)
    document
      .querySelector<HTMLMetaElement>('meta[name="description"]')
      ?.setAttribute('content', description)
  }, [title, description])
}
