import { endpoints } from '@/config/endpoints'
import { http } from '@/lib/http'

import type { Announcement } from '../types'

export const dashboardApi = {
  async announcements(): Promise<Announcement[]> {
    if (__USE_MOCK__) {
      const { mockAnnouncements } = await import('./dashboardMock')
      return mockAnnouncements()
    }
    const { data } = await http.get<Announcement[]>(endpoints.dashboard.announcements)
    return data
  },
}
