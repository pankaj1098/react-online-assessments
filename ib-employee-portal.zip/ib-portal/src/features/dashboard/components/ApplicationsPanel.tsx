import { LayoutGrid } from 'lucide-react'
import { useState } from 'react'

import { EmptyState } from '@/components/common/EmptyState'
import { Logo } from '@/components/common/Logo'
import { Card } from '@/components/ui/card'
import { NativeSelect } from '@/components/ui/input'
import { applications, type ApplicationTone, type PortalApplication } from '@/config/applications'
import { cn } from '@/lib/utils'
import { useUiStore } from '@/stores/uiStore'

const ALL = 'All Applications'
const groups = [...new Set(applications.map((app) => app.group))]

// Full class names (not built dynamically) so Tailwind can detect them.
const toneClasses: Record<ApplicationTone, string> = {
  orange: 'border-tone-orange-border bg-gradient-to-br from-card to-tone-orange-bg',
  green: 'border-tone-green-border bg-gradient-to-br from-card to-tone-green-bg',
  purple: 'border-tone-purple-border bg-gradient-to-br from-card to-tone-purple-bg',
  rose: 'border-tone-rose-border bg-gradient-to-br from-card to-tone-rose-bg',
  teal: 'border-tone-teal-border bg-gradient-to-br from-card to-tone-teal-bg',
  amber: 'border-tone-amber-border bg-gradient-to-br from-card to-tone-amber-bg',
  blue: 'border-tone-blue-border bg-gradient-to-br from-card to-tone-blue-bg',
}

const tileClasses =
  'flex h-32 flex-col items-center justify-center gap-2 rounded-2xl border p-2.5 text-center transition hover:-translate-y-0.5 hover:shadow-md sm:h-36'

function ApplicationTile({ app }: { app: PortalApplication }) {
  const content = (
    <>
      <span className="grid size-14 place-items-center rounded-full bg-card/70 text-lg font-extrabold text-primary shadow-sm sm:size-16">
        {app.useLogo ? <Logo alt="" className="size-full" /> : app.mark}
      </span>
      <b className="text-xs leading-tight uppercase sm:text-sm">{app.name}</b>
    </>
  )

  if (!app.href) {
    return (
      <button
        type="button"
        disabled
        title="This application link is not available yet"
        className={cn(
          tileClasses,
          toneClasses[app.tone],
          'cursor-not-allowed opacity-75 hover:translate-y-0 hover:shadow-none',
        )}
      >
        {content}
      </button>
    )
  }

  return (
    <a
      href={app.href}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(tileClasses, toneClasses[app.tone])}
    >
      {content}
      <span className="sr-only">(opens in a new tab)</span>
    </a>
  )
}

export function ApplicationsPanel() {
  const search = useUiStore((state) => state.applicationSearch)
  const [group, setGroup] = useState(ALL)

  const query = search.trim().toLowerCase()
  const visible = applications.filter(
    (app) => app.name.toLowerCase().includes(query) && (group === ALL || app.group === group),
  )

  return (
    <Card role="region" aria-labelledby="applications-heading" className="p-4 pb-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <h2
          id="applications-heading"
          className="flex items-center gap-2.5 text-xl font-bold tracking-tight"
        >
          <LayoutGrid className="size-6 text-primary" aria-hidden="true" /> IB Group Applications
        </h2>
        <NativeSelect
          aria-label="Filter applications by category"
          value={group}
          onChange={(event) => setGroup(event.target.value)}
          className="max-w-48"
        >
          <option>{ALL}</option>
          {groups.map((name) => (
            <option key={name}>{name}</option>
          ))}
        </NativeSelect>
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {visible.map((app) => (
          <ApplicationTile key={app.id} app={app} />
        ))}
        {visible.length === 0 && <EmptyState>No applications match your search.</EmptyState>}
      </div>
    </Card>
  )
}
