export const gatePassPurposes = ['Official', 'Personal', 'Business', 'Emergency', 'Other'] as const
export const gatePassStatuses = ['Pending', 'Approved', 'Rejected'] as const

export type GatePassPurpose = (typeof gatePassPurposes)[number]
export type GatePassStatus = (typeof gatePassStatuses)[number]

export interface GatePassRequest {
  id: string
  place: string
  /** Local date-time, "YYYY-MM-DDTHH:mm". */
  dateTime: string
  purpose: GatePassPurpose
  contactPerson: string
  reason: string
  status: GatePassStatus
  /** ISO timestamp set by the server. */
  createdOn: string
}

/** What the employee fills in. Status and createdOn are set by the server. */
export type GatePassInput = Pick<
  GatePassRequest,
  'place' | 'dateTime' | 'purpose' | 'contactPerson' | 'reason'
>

export interface GatePassFilters {
  /** "YYYY-MM-DD" or "". */
  from: string
  to: string
  purpose: GatePassPurpose | ''
  status: GatePassStatus | ''
}

export interface GatePassListParams extends GatePassFilters {
  search: string
  page: number
  pageSize: number
}

export interface Paged<T> {
  items: T[]
  total: number
}

export const emptyFilters: GatePassFilters = { from: '', to: '', purpose: '', status: '' }
