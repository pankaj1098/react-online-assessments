import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query'

import { gatePassApi } from './api/gatePassApi'
import type { GatePassInput, GatePassListParams } from './types'

export const gatePassKeys = {
  all: ['gate-pass'] as const,
  list: (params: GatePassListParams) => [...gatePassKeys.all, 'list', params] as const,
  detail: (id: string) => [...gatePassKeys.all, 'detail', id] as const,
}

export function useGatePassList(params: GatePassListParams) {
  return useQuery({
    queryKey: gatePassKeys.list(params),
    queryFn: () => gatePassApi.list(params),
    placeholderData: keepPreviousData,
  })
}

export function useGatePass(id: string | undefined) {
  return useQuery({
    queryKey: gatePassKeys.detail(id ?? ''),
    queryFn: () => gatePassApi.get(id ?? ''),
    enabled: Boolean(id),
  })
}

export function useCreateGatePass() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (input: GatePassInput) => gatePassApi.create(input),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: gatePassKeys.all }),
  })
}

export function useUpdateGatePass(id: string) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (input: GatePassInput) => gatePassApi.update(id, input),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: gatePassKeys.all }),
  })
}
