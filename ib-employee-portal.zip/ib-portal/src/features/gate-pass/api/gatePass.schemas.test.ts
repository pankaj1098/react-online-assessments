import { describe, expect, it } from 'vitest'

import { gatePassFormSchema } from './gatePass.schemas'

const valid = {
  place: ' Plant ',
  dateTime: '2026-12-01T10:00',
  contactPerson: 'A. Kumar',
  purpose: 'Official',
  reason: 'Audit visit',
}

describe('gatePassFormSchema', () => {
  it('accepts a complete request and trims text', () => {
    const result = gatePassFormSchema.safeParse(valid)
    expect(result.success && result.data.place).toBe('Plant')
  })

  it('asks for a purpose when none is selected', () => {
    const result = gatePassFormSchema.safeParse({ ...valid, purpose: '' })
    expect(result.success).toBe(false)
    expect(result.error?.issues[0]?.message).toBe('Select the purpose of visit.')
  })

  it('rejects a reason over 500 characters', () => {
    expect(gatePassFormSchema.safeParse({ ...valid, reason: 'x'.repeat(501) }).success).toBe(false)
  })
})
