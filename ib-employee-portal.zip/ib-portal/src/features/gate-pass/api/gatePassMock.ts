import { ApiError } from '@/lib/api-error'
import { readJson, writeJson } from '@/lib/storage'

import type { GatePassInput, GatePassListParams, GatePassRequest, Paged } from '../types'

const STORAGE_KEY = 'ib-gate-pass-requests'

const seed: GatePassRequest[] = [
  {
    id: 'GP-1001',
    place: 'Home',
    dateTime: '2026-11-16T13:30',
    purpose: 'Personal',
    contactPerson: 'Self',
    reason: 'Personal visit',
    status: 'Approved',
    createdOn: '2026-11-16T11:57:00.000Z',
  },
]

const delay = () => new Promise((resolve) => setTimeout(resolve, 250))

function load(): GatePassRequest[] {
  return readJson<GatePassRequest[]>(STORAGE_KEY) ?? seed
}

function save(items: GatePassRequest[]) {
  writeJson(STORAGE_KEY, items)
}

export async function mockList(params: GatePassListParams): Promise<Paged<GatePassRequest>> {
  await delay()
  const search = params.search.trim().toLowerCase()
  const filtered = load().filter((item) => {
    const date = item.dateTime.slice(0, 10)
    return (
      [item.place, item.purpose, item.contactPerson, item.status]
        .join(' ')
        .toLowerCase()
        .includes(search) &&
      (!params.from || date >= params.from) &&
      (!params.to || date <= params.to) &&
      (!params.purpose || item.purpose === params.purpose) &&
      (!params.status || item.status === params.status)
    )
  })
  const start = (params.page - 1) * params.pageSize
  return { items: filtered.slice(start, start + params.pageSize), total: filtered.length }
}

export async function mockGet(id: string): Promise<GatePassRequest> {
  await delay()
  const found = load().find((item) => item.id === id)
  if (!found) throw new ApiError('Gate pass request not found.', 404)
  return found
}

export async function mockCreate(input: GatePassInput): Promise<GatePassRequest> {
  await delay()
  const created: GatePassRequest = {
    ...input,
    id: `GP-${Date.now()}`,
    status: 'Pending',
    createdOn: new Date().toISOString(),
  }
  save([created, ...load()])
  return created
}

export async function mockUpdate(id: string, input: GatePassInput): Promise<GatePassRequest> {
  await delay()
  const items = load()
  const existing = items.find((item) => item.id === id)
  if (!existing) throw new ApiError('Gate pass request not found.', 404)
  const updated: GatePassRequest = { ...existing, ...input }
  save(items.map((item) => (item.id === id ? updated : item)))
  return updated
}
