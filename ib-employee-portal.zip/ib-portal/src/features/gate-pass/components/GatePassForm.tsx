import { zodResolver } from '@hookform/resolvers/zod'
import {
  ArrowRight,
  CalendarDays,
  Info,
  Layers,
  MapPin,
  MessageSquare,
  UserRound,
} from 'lucide-react'
import type { ReactNode } from 'react'
import { useForm, useWatch } from 'react-hook-form'

import { Button } from '@/components/ui/button'
import { Input, NativeSelect, Textarea } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { getErrorMessage } from '@/lib/api-error'

import {
  gatePassFormSchema,
  REASON_MAX_LENGTH,
  type GatePassFormInput,
  type GatePassFormValues,
} from '../api/gatePass.schemas'
import { gatePassPurposes } from '../types'
import { GateIllustration } from './GateIllustration'

interface GatePassFormProps {
  defaultValues: GatePassFormInput
  mode: 'create' | 'edit'
  isSubmitting: boolean
  submitError: unknown
  onSubmit: (values: GatePassFormValues) => void
  onCancel: () => void
}

function Field({
  id,
  label,
  error,
  hint,
  children,
}: {
  id: string
  label: string
  error?: string
  hint?: ReactNode
  children: ReactNode
}) {
  return (
    <div className="grid gap-1.5 md:grid-cols-[11rem_minmax(0,1fr)] md:gap-x-5">
      <Label htmlFor={id} className="md:pt-3.5">
        {label} <span className="text-destructive">*</span>
      </Label>
      <div className="space-y-1.5">
        {children}
        {error && (
          <p id={`${id}-error`} className="text-sm text-destructive">
            {error}
          </p>
        )}
        {hint}
      </div>
    </div>
  )
}

export function GatePassForm({
  defaultValues,
  mode,
  isSubmitting,
  submitError,
  onSubmit,
  onCancel,
}: GatePassFormProps) {
  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<GatePassFormInput, unknown, GatePassFormValues>({
    resolver: zodResolver(gatePassFormSchema),
    defaultValues,
  })
  const reason = useWatch({ control, name: 'reason' }) ?? ''
  const invalid = (name: keyof GatePassFormInput) => (errors[name] ? true : undefined)
  const describedBy = (name: keyof GatePassFormInput) =>
    errors[name] ? `${name}-error` : undefined

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate>
      <div className="grid gap-8 px-5 py-7 sm:px-8 lg:grid-cols-[minmax(0,1.3fr)_minmax(18rem,0.7fr)] lg:gap-11">
        <div className="grid content-start gap-6">
          <Field id="place" label="Place" error={errors.place?.message}>
            <Input
              id="place"
              icon={<MapPin />}
              placeholder="Enter place (e.g., Plant, Office, Warehouse)"
              aria-invalid={invalid('place')}
              aria-describedby={describedBy('place')}
              {...register('place')}
            />
          </Field>
          <Field id="dateTime" label="Date & Time" error={errors.dateTime?.message}>
            <Input
              id="dateTime"
              type="datetime-local"
              icon={<CalendarDays />}
              aria-invalid={invalid('dateTime')}
              aria-describedby={describedBy('dateTime')}
              {...register('dateTime')}
            />
          </Field>
          <Field id="contactPerson" label="Contact Person" error={errors.contactPerson?.message}>
            <Input
              id="contactPerson"
              icon={<UserRound />}
              placeholder="Enter contact person name"
              aria-invalid={invalid('contactPerson')}
              aria-describedby={describedBy('contactPerson')}
              {...register('contactPerson')}
            />
          </Field>
          <Field id="purpose" label="Purpose" error={errors.purpose?.message}>
            <NativeSelect
              id="purpose"
              icon={<Layers />}
              aria-invalid={invalid('purpose')}
              aria-describedby={describedBy('purpose')}
              {...register('purpose')}
            >
              <option value="">Select purpose of visit</option>
              {gatePassPurposes.map((purpose) => (
                <option key={purpose} value={purpose}>
                  {purpose}
                </option>
              ))}
            </NativeSelect>
          </Field>
          <Field
            id="reason"
            label="Reason"
            error={errors.reason?.message}
            hint={
              <small className="block text-muted-foreground">
                {REASON_MAX_LENGTH - reason.length} characters remaining
              </small>
            }
          >
            <Textarea
              id="reason"
              icon={<MessageSquare />}
              maxLength={REASON_MAX_LENGTH}
              placeholder={`Enter the reason for visit (max ${REASON_MAX_LENGTH} characters)`}
              aria-invalid={invalid('reason')}
              aria-describedby={describedBy('reason')}
              {...register('reason')}
            />
          </Field>
          {submitError != null && (
            <p role="alert" className="rounded-lg bg-danger-soft px-3 py-2 text-sm text-danger">
              {getErrorMessage(submitError)}
            </p>
          )}
        </div>

        <aside className="border-border pt-6 text-center lg:border-l lg:pt-0 lg:pl-9">
          <GateIllustration />
          <h2 className="mb-2 text-xl font-bold">Gate Pass Request</h2>
          <p className="mx-auto max-w-sm text-sm leading-relaxed text-muted-foreground">
            Use this form to raise a gate pass request for plant, office or other authorized visits.
          </p>
          <div className="mt-6 rounded-2xl bg-primary-soft p-5 text-left">
            <h3 className="mb-2.5 flex items-center gap-2.5 font-bold text-primary-soft-foreground">
              <Info className="size-5" aria-hidden="true" /> Important
            </h3>
            <ul className="grid list-disc gap-2 pl-6 text-sm leading-snug">
              <li>Provide accurate visit details.</li>
              <li>Ensure the contact person is available.</li>
              <li>Gate pass will be subject to approval.</li>
            </ul>
          </div>
        </aside>
      </div>

      <footer className="flex justify-end gap-3 border-t border-border px-5 py-4 sm:px-8">
        <Button
          type="button"
          variant="outline"
          className="min-w-28 max-sm:flex-1"
          onClick={onCancel}
        >
          Cancel
        </Button>
        <Button type="submit" disabled={isSubmitting} className="min-w-52 max-sm:flex-1">
          {isSubmitting ? 'Saving...' : mode === 'edit' ? 'Save Changes' : 'Submit Request'}
          {!isSubmitting && <ArrowRight aria-hidden="true" />}
        </Button>
      </footer>
    </form>
  )
}
