/** Decorative office-entrance picture. Colours come from the theme classes. */
export function GateIllustration() {
  return (
    <svg
      className="mx-auto mb-2 block h-40 w-full max-w-[22rem]"
      viewBox="0 0 420 180"
      aria-hidden="true"
      focusable="false"
    >
      <circle cx="218" cy="96" r="80" className="fill-primary-soft" />
      <path
        d="M47 153h330"
        className="stroke-brand-highlight"
        strokeWidth="5"
        strokeLinecap="round"
        fill="none"
      />
      <rect
        x="152"
        y="75"
        width="104"
        height="78"
        className="fill-card stroke-input"
        strokeWidth="3"
      />
      <rect x="144" y="70" width="120" height="18" rx="5" className="fill-primary" />
      <rect
        x="164"
        y="94"
        width="29"
        height="35"
        className="fill-secondary stroke-brand-light"
        strokeWidth="3"
      />
      <rect
        x="213"
        y="94"
        width="29"
        height="35"
        className="fill-secondary stroke-brand-light"
        strokeWidth="3"
      />
      <path
        d="M276 85v54m0-33h83"
        className="stroke-primary"
        strokeWidth="7"
        strokeLinecap="round"
        fill="none"
      />
      <path d="M41 153c16-22 31-20 42 0m245 0c14-24 29-24 44 0" className="fill-brand-highlight" />
      <circle cx="65" cy="140" r="9" className="fill-brand-highlight" />
      <circle cx="344" cy="142" r="10" className="fill-brand-highlight" />
    </svg>
  )
}
