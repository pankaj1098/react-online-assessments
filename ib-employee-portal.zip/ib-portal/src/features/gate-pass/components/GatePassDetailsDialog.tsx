import { Dialog, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog'
import { formatDateTime } from '@/lib/date'

import type { GatePassRequest } from '../types'
import { GatePassStatusBadge } from './GatePassStatusBadge'

interface Props {
  request: GatePassRequest | null
  onClose: () => void
}

export function GatePassDetailsDialog({ request, onClose }: Props) {
  return (
    <Dialog open={request !== null} onOpenChange={(open) => !open && onClose()}>
      <DialogContent>
        {request && (
          <>
            <DialogTitle>Gate Pass Request</DialogTitle>
            <DialogDescription className="mt-1">Request {request.id}</DialogDescription>
            <dl className="mt-5 grid gap-3.5">
              {[
                ['Place', request.place],
                ['Date & Time', formatDateTime(request.dateTime)],
                ['Purpose', request.purpose],
                ['Contact Person', request.contactPerson],
                ['Reason', request.reason],
              ].map(([key, value]) => (
                <div key={key} className="grid grid-cols-[8.5rem_1fr] gap-2.5">
                  <dt className="text-muted-foreground">{key}</dt>
                  <dd className="font-semibold break-words">{value || '-'}</dd>
                </div>
              ))}
              <div className="grid grid-cols-[8.5rem_1fr] items-center gap-2.5">
                <dt className="text-muted-foreground">Status</dt>
                <dd>
                  <GatePassStatusBadge status={request.status} />
                </dd>
              </div>
            </dl>
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}
