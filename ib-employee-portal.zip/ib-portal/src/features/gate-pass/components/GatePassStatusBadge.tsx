import { CircleCheck, Clock, CircleX, type LucideIcon } from 'lucide-react'

import { Badge } from '@/components/ui/badge'

import type { GatePassStatus } from '../types'

const config: Record<
  GatePassStatus,
  { variant: 'success' | 'warning' | 'danger'; icon: LucideIcon }
> = {
  Approved: { variant: 'success', icon: CircleCheck },
  Pending: { variant: 'warning', icon: Clock },
  Rejected: { variant: 'danger', icon: CircleX },
}

export function GatePassStatusBadge({ status }: { status: GatePassStatus }) {
  const { variant, icon: Icon } = config[status]
  return (
    <Badge variant={variant}>
      <Icon aria-hidden="true" />
      {status}
    </Badge>
  )
}
