import { Bell, CalendarDays, FileText, Users, type LucideIcon } from 'lucide-react'

import type { NotificationCategory } from '../types'

export const notificationIcons: Record<NotificationCategory, LucideIcon> = {
  event: CalendarDays,
  holiday: CalendarDays,
  hr: Users,
  policy: FileText,
  general: Bell,
}
