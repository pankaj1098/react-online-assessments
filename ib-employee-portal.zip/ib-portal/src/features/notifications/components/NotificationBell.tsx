import { Bell } from 'lucide-react'
import { Link } from 'react-router-dom'

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { formatRelativeTime } from '@/lib/relative-time'

import { useNotifications } from '../hooks'
import { notificationIcons } from './notificationIcon'

/** Bell in the top bar: shows the unread count and the latest notifications. */
export function NotificationBell() {
  const { data: notifications = [] } = useNotifications()
  const unread = notifications.filter((item) => item.unread).length

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        aria-label={unread ? `Notifications, ${unread} unread` : 'Notifications'}
        className="relative rounded-lg p-2 text-primary hover:bg-secondary"
      >
        <Bell className="size-6" aria-hidden="true" />
        {unread > 0 && (
          <span
            aria-hidden="true"
            className="absolute -top-0.5 -right-0.5 grid min-w-5 place-items-center rounded-full border-2 border-card bg-primary px-1 text-xs leading-4 font-bold text-primary-foreground"
          >
            {unread}
          </span>
        )}
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-80 max-w-[calc(100vw-2rem)]">
        <DropdownMenuLabel className="font-bold">Notifications</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {notifications.length === 0 && (
          <p className="px-3 py-4 text-center text-sm text-muted-foreground">
            You&rsquo;re all caught up.
          </p>
        )}
        {notifications.slice(0, 4).map((item) => {
          const Icon = notificationIcons[item.category]
          return (
            <DropdownMenuItem key={item.id} asChild>
              <Link to="/" className="items-start gap-3">
                <span className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-full bg-primary-soft text-primary">
                  <Icon aria-hidden="true" />
                </span>
                <span className="min-w-0">
                  <span className="block truncate font-semibold">{item.title}</span>
                  <span className="block text-xs text-muted-foreground">
                    {formatRelativeTime(item.createdAt)}
                  </span>
                </span>
              </Link>
            </DropdownMenuItem>
          )
        })}
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link to="/" className="justify-center font-semibold text-primary">
            View all
          </Link>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
