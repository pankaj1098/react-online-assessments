import { Bell } from 'lucide-react'
import { useState } from 'react'

import { Card } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { EmptyState } from '@/components/common/EmptyState'
import { cn } from '@/lib/utils'
import { formatRelativeTime } from '@/lib/relative-time'
import { getErrorMessage } from '@/lib/api-error'

import { useNotifications } from '../hooks'
import type { PortalNotification } from '../types'
import { notificationIcons } from './notificationIcon'

type Filter = 'All' | 'Important' | 'Unread'
const filters: Filter[] = ['All', 'Important', 'Unread']

function matches(filter: Filter, item: PortalNotification): boolean {
  if (filter === 'Important') return item.important
  if (filter === 'Unread') return item.unread
  return true
}

export function NotificationsPanel() {
  const [filter, setFilter] = useState<Filter>('All')
  const { data: notifications = [], isPending, isError, error, refetch } = useNotifications()
  const visible = notifications.filter((item) => matches(filter, item))

  return (
    <Card role="region" className="p-5 pb-3" aria-labelledby="notifications-heading">
      <div className="mb-4 flex items-center justify-between gap-2">
        <h2
          id="notifications-heading"
          className="flex items-center gap-2.5 text-xl font-bold tracking-tight"
        >
          <Bell className="size-6 text-primary" aria-hidden="true" /> Notifications
        </h2>
      </div>

      <div
        role="group"
        aria-label="Filter notifications"
        className="grid grid-cols-3 gap-2 border-b border-border pb-4"
      >
        {filters.map((name) => {
          const count = notifications.filter((item) => matches(name, item)).length
          const selected = filter === name
          return (
            <button
              key={name}
              type="button"
              aria-pressed={selected}
              onClick={() => setFilter(name)}
              className={cn(
                'min-h-10 rounded-xl border px-2 text-sm whitespace-nowrap transition-colors',
                selected
                  ? 'border-primary bg-primary font-bold text-primary-foreground shadow-sm'
                  : 'border-input bg-card hover:bg-secondary',
              )}
            >
              {name} ({count})
            </button>
          )
        })}
      </div>

      <div>
        {isPending && (
          <div className="space-y-3 py-4">
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-16" />
            ))}
          </div>
        )}
        {isError && (
          <div role="alert" className="py-6 text-center text-sm">
            <p className="text-destructive">{getErrorMessage(error)}</p>
            <button
              type="button"
              className="mt-2 font-semibold text-primary underline"
              onClick={() => void refetch()}
            >
              Try again
            </button>
          </div>
        )}
        {!isPending && !isError && visible.length === 0 && (
          <EmptyState>You&rsquo;re all caught up.</EmptyState>
        )}
        <ul>
          {visible.map((item) => {
            const Icon = notificationIcons[item.category]
            return (
              <li
                key={item.id}
                className="grid grid-cols-[2.75rem_minmax(0,1fr)] items-center gap-x-3 border-b border-border py-3.5 last:border-b-0 sm:grid-cols-[3.25rem_minmax(0,1fr)_auto]"
              >
                <span className="grid size-11 place-items-center rounded-full bg-primary-soft text-primary sm:size-[3.25rem]">
                  <Icon className="size-5 sm:size-6" aria-hidden="true" />
                </span>
                <div className="min-w-0">
                  <h3 className="font-semibold">{item.title}</h3>
                  <p className="mt-0.5 text-sm text-foreground/80">{item.message}</p>
                </div>
                <small className="col-start-2 mt-1 text-muted-foreground sm:col-start-3 sm:mt-0">
                  {formatRelativeTime(item.createdAt)}
                </small>
              </li>
            )
          })}
        </ul>
      </div>
    </Card>
  )
}
