import type { PortalNotification } from '../types'

const hoursAgo = (hours: number) => new Date(Date.now() - hours * 3_600_000).toISOString()

export async function mockNotifications(): Promise<PortalNotification[]> {
  await new Promise((resolve) => setTimeout(resolve, 250))
  return [
    {
      id: 'n-1',
      category: 'event',
      title: 'IB Group Annual Townhall',
      message: 'Join us on 28 Nov 2026 at 4:00 PM.',
      createdAt: hoursAgo(2),
      important: true,
      unread: true,
    },
    {
      id: 'n-2',
      category: 'hr',
      title: 'HR: Profile Update Reminder',
      message: 'Please complete your profile details by 24 Nov 2026.',
      createdAt: hoursAgo(5),
      important: true,
      unread: true,
    },
    {
      id: 'n-3',
      category: 'holiday',
      title: 'Holiday Announcement',
      message: 'Office will remain closed on 25 Nov 2026 (Guru Nanak Jayanti).',
      createdAt: hoursAgo(26),
      important: false,
      unread: true,
    },
    {
      id: 'n-4',
      category: 'policy',
      title: 'Policy Update',
      message: 'Revised Travel & Expense policy is now live. Kindly review the updated document.',
      createdAt: hoursAgo(50),
      important: true,
      unread: false,
    },
  ]
}
