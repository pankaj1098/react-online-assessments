import { endpoints } from '@/config/endpoints'
import { http } from '@/lib/http'

import type { PortalNotification } from '../types'

export const notificationsApi = {
  async list(): Promise<PortalNotification[]> {
    if (__USE_MOCK__) {
      const { mockNotifications } = await import('./notificationsMock')
      return mockNotifications()
    }
    const { data } = await http.get<PortalNotification[]>(endpoints.dashboard.notifications)
    return data
  },
}
