export type NotificationCategory = 'event' | 'hr' | 'holiday' | 'policy' | 'general'

export interface PortalNotification {
  id: string
  category: NotificationCategory
  title: string
  message: string
  /** ISO timestamp. */
  createdAt: string
  important: boolean
  unread: boolean
}
