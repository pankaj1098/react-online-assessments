export interface AuthUser {
  employeeId: string
  name: string
  email?: string
  roles: string[]
}

export interface AuthSession {
  user: AuthUser
  accessToken: string
  refreshToken?: string
}
