import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'

import type { AuthSession, AuthUser } from '../types'

interface AuthState {
  user: AuthUser | null
  accessToken: string | null
  refreshToken: string | null
  setSession: (session: AuthSession) => void
  setTokens: (tokens: { accessToken: string; refreshToken?: string }) => void
  clear: () => void
}

/**
 * Signed-in session. Persisted so a page refresh keeps the user signed in.
 * To keep tokens only for the browser tab's lifetime, swap `localStorage` for `sessionStorage`.
 */
export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      accessToken: null,
      refreshToken: null,
      setSession: ({ user, accessToken, refreshToken }) =>
        set({ user, accessToken, refreshToken: refreshToken ?? null }),
      setTokens: ({ accessToken, refreshToken }) =>
        set((state) => ({ accessToken, refreshToken: refreshToken ?? state.refreshToken })),
      clear: () => set({ user: null, accessToken: null, refreshToken: null }),
    }),
    {
      name: 'ib-portal-auth',
      storage: createJSONStorage(() => window.localStorage),
      partialize: ({ user, accessToken, refreshToken }) => ({ user, accessToken, refreshToken }),
    },
  ),
)

export const selectIsAuthenticated = (state: AuthState) => Boolean(state.user && state.accessToken)
