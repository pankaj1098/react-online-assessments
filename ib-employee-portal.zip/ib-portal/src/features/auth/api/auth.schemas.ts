import { z } from 'zod'

export const loginSchema = z.object({
  employeeId: z.string().trim().min(1, 'Enter your employee ID or username.'),
  password: z.string().min(1, 'Enter your password.'),
})

export type LoginValues = z.infer<typeof loginSchema>

/**
 * Shape we expect back from the .NET login API.
 * If the real response differs, adjust ONLY this schema and `toSession` below.
 */
export const loginResponseSchema = z.object({
  accessToken: z.string().min(1),
  refreshToken: z.string().optional(),
  user: z.object({
    employeeId: z.string(),
    name: z.string(),
    email: z.string().optional(),
    roles: z.array(z.string()).default(['employee']),
  }),
})

export type LoginResponse = z.infer<typeof loginResponseSchema>
