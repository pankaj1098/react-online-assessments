import { zodResolver } from '@hookform/resolvers/zod'
import {
  ArrowRight,
  Bell,
  Eye,
  EyeOff,
  LayoutGrid,
  Lock,
  ShieldCheck,
  UserRound,
} from 'lucide-react'
import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { Link } from 'react-router-dom'

import { Logo } from '@/components/common/Logo'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { usePageMeta } from '@/hooks/usePageMeta'
import { getErrorMessage } from '@/lib/api-error'

import { loginSchema, type LoginValues } from '../api/auth.schemas'
import { useLogin } from '../hooks'

const benefits = [
  { icon: LayoutGrid, text: ['All Applications', 'in One Place'] },
  { icon: Bell, text: ['Real-time', 'Announcements'] },
  { icon: ShieldCheck, text: ['Secure &', 'Role-based Access'] },
] as const

export default function LoginPage() {
  usePageMeta('Sign in', 'Sign in to the IB Group Employee Portal with your employee ID.')
  const login = useLogin()
  const [showPassword, setShowPassword] = useState(false)
  const [forgotShown, setForgotShown] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { employeeId: '', password: '' },
  })

  // On success the session is stored and GuestRoute sends the user to where they were heading.
  function onSubmit(values: LoginValues) {
    setForgotShown(false)
    login.mutate(values)
  }

  return (
    <main className="grid min-h-screen bg-background lg:grid-cols-[46%_54%]">
      <section className="relative flex flex-col overflow-hidden rounded-br-[3.75rem] px-[7vw] py-7 text-white bg-brand-gradient lg:min-h-screen lg:rounded-br-[7.5rem] lg:px-[clamp(2rem,6vw,6.5rem)] lg:py-12">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute top-[15%] -right-72 h-72 w-[38rem] -rotate-[24deg] rounded-full border border-white/15 ring-[35px] ring-white/[0.04]"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-[5%] -bottom-1 -left-[5%] h-20 bg-brand-highlight/80 [clip-path:polygon(0_42%,100%_0,100%_100%,0_100%)]"
        />

        <Link
          to="/login"
          className="relative z-10 flex items-center gap-3.5 text-2xl font-bold tracking-wide lg:text-3xl"
        >
          <Logo alt="" className="size-12 lg:size-14" />
          <span>IB GROUP</span>
        </Link>

        <div className="relative z-10 my-auto max-w-lg py-10 lg:py-0 lg:pb-14">
          <h1 className="text-4xl leading-tight font-bold tracking-tight lg:text-6xl">
            IB Group
            <br />
            Employee Portal
          </h1>
          <span className="my-5 block h-1.5 w-24 rounded-full bg-brand-highlight" />
          <p className="max-w-md text-lg leading-relaxed lg:text-xl">
            A single platform to access workplace applications, services and information.
          </p>
        </div>

        <ul className="relative z-10 mb-10 hidden max-w-xl grid-cols-3 text-center lg:grid">
          {benefits.map(({ icon: Icon, text }) => (
            <li key={text.join(' ')} className="border-r border-white/40 px-2.5 last:border-r-0">
              <span className="inline-grid size-14 place-items-center rounded-2xl bg-white/15">
                <Icon className="size-6" aria-hidden="true" />
              </span>
              <p className="mt-2.5 text-sm leading-snug">
                {text[0]}
                <br />
                {text[1]}
              </p>
            </li>
          ))}
        </ul>
      </section>

      <section className="flex flex-col items-center justify-center px-5 py-10 lg:px-8 lg:py-12">
        <form
          onSubmit={handleSubmit(onSubmit)}
          noValidate
          className="w-full max-w-2xl rounded-3xl border border-border bg-card/95 px-6 pt-8 pb-10 shadow-xl sm:px-14"
        >
          <Logo className="mx-auto mb-5 size-24 shadow-md sm:size-28" />
          <h2 className="text-center text-3xl font-bold tracking-tight sm:text-4xl">
            Welcome Back
          </h2>
          <p className="mt-2.5 mb-8 text-center text-muted-foreground sm:text-lg">
            Sign in to your IB Group Employee Portal
          </p>

          <div className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="employeeId">
                Employee ID / Username <span className="text-destructive">*</span>
              </Label>
              <Input
                id="employeeId"
                icon={<UserRound />}
                autoComplete="username"
                placeholder="Enter your employee ID or username"
                aria-invalid={errors.employeeId ? true : undefined}
                aria-describedby={errors.employeeId ? 'employeeId-error' : undefined}
                className="h-14"
                {...register('employeeId')}
              />
              {errors.employeeId && (
                <p id="employeeId-error" className="text-sm text-destructive">
                  {errors.employeeId.message}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">
                Password <span className="text-destructive">*</span>
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  icon={<Lock />}
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  placeholder="Enter your password"
                  aria-invalid={errors.password ? true : undefined}
                  aria-describedby={errors.password ? 'password-error' : undefined}
                  className="h-14 pr-12"
                  {...register('password')}
                />
                <button
                  type="button"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  aria-pressed={showPassword}
                  onClick={() => setShowPassword((value) => !value)}
                  className="absolute top-1/2 right-3 -translate-y-1/2 rounded p-1 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? (
                    <EyeOff className="size-5" aria-hidden="true" />
                  ) : (
                    <Eye className="size-5" aria-hidden="true" />
                  )}
                </button>
              </div>
              {errors.password && (
                <p id="password-error" className="text-sm text-destructive">
                  {errors.password.message}
                </p>
              )}
            </div>
          </div>

          <div className="mt-4 mb-6 text-right">
            <button
              type="button"
              onClick={() => setForgotShown(true)}
              className="font-semibold text-primary hover:underline"
            >
              Forgot Password?
            </button>
          </div>

          {forgotShown && (
            <p
              role="status"
              className="mb-4 rounded-lg bg-primary-soft px-3 py-2 text-sm text-primary-soft-foreground"
            >
              Please contact your IT administrator to reset your password.
            </p>
          )}
          {login.isError && (
            <p
              role="alert"
              className="mb-4 rounded-lg bg-danger-soft px-3 py-2 text-sm text-danger"
            >
              {getErrorMessage(login.error)}
            </p>
          )}

          <Button
            type="submit"
            size="lg"
            className="h-14 w-full text-lg"
            disabled={login.isPending}
          >
            {login.isPending ? 'Signing in...' : 'Login'}
            {!login.isPending && <ArrowRight aria-hidden="true" className="size-5" />}
          </Button>
        </form>
        <p className="mt-7 text-center text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} IB Group. All Rights Reserved.
        </p>
      </section>
    </main>
  )
}
