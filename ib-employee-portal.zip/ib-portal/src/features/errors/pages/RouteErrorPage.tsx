import { isRouteErrorResponse, Link, useRouteError } from 'react-router-dom'

import { Button } from '@/components/ui/button'
import { usePageMeta } from '@/hooks/usePageMeta'

/** Shown by the router when a page crashes or fails to load (e.g. after a new deployment). */
export default function RouteErrorPage() {
  usePageMeta('Something went wrong', 'An unexpected error occurred.')
  const error = useRouteError()
  if (!isRouteErrorResponse(error)) {
    console.error(error)
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-xl flex-col items-center justify-center px-4 text-center">
      <h1 className="text-3xl font-bold tracking-tight">Something went wrong</h1>
      <p className="mt-3 text-muted-foreground">
        The page could not be displayed. Reloading usually fixes this.
      </p>
      <div className="mt-8 flex gap-3">
        <Button onClick={() => window.location.reload()}>Reload page</Button>
        <Button asChild variant="outline">
          <Link to="/">Go to Home</Link>
        </Button>
      </div>
    </main>
  )
}
