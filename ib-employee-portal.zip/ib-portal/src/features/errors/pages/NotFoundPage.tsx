import { Link } from 'react-router-dom'

import { Button } from '@/components/ui/button'
import { usePageMeta } from '@/hooks/usePageMeta'

export default function NotFoundPage() {
  usePageMeta('Page not found', 'The page you are looking for does not exist or has moved.')
  return (
    <section className="mx-auto flex max-w-xl flex-col items-center px-4 py-16 text-center">
      <p className="text-6xl font-extrabold text-primary" aria-hidden="true">
        404
      </p>
      <h1 className="mt-4 text-3xl font-bold tracking-tight">Page not found</h1>
      <p className="mt-3 text-muted-foreground">
        The page you are looking for does not exist or has moved. Check the address or head back to
        the portal home.
      </p>
      <Button asChild className="mt-8">
        <Link to="/">Back to Home</Link>
      </Button>
    </section>
  )
}
