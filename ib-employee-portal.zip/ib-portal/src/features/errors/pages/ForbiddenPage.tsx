import { Link } from 'react-router-dom'

import { Button } from '@/components/ui/button'
import { usePageMeta } from '@/hooks/usePageMeta'

export default function ForbiddenPage() {
  usePageMeta('Access denied', 'You do not have permission to view this page.')
  return (
    <section className="mx-auto flex max-w-xl flex-col items-center px-4 py-16 text-center">
      <h1 className="text-3xl font-bold tracking-tight">Access denied</h1>
      <p className="mt-3 text-muted-foreground">
        You do not have permission to view this page. If you think this is a mistake, contact your
        administrator.
      </p>
      <Button asChild className="mt-8">
        <Link to="/">Back to Home</Link>
      </Button>
    </section>
  )
}
