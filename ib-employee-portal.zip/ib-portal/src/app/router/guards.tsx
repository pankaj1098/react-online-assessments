import { useAbility } from '@casl/react'
import { Navigate, Outlet, useLocation } from 'react-router-dom'

import { safeRedirect } from '@/features/auth/redirect'
import { selectIsAuthenticated, useAuthStore } from '@/features/auth/store/authStore'
import type { AppAbility, Subject } from '@/lib/ability'
import ForbiddenPage from '@/features/errors/pages/ForbiddenPage'

/** Only signed-in users pass. Others go to /login and come back afterwards. */
export function ProtectedRoute() {
  const isAuthenticated = useAuthStore(selectIsAuthenticated)
  const location = useLocation()

  if (!isAuthenticated) {
    return (
      <Navigate
        to="/login"
        replace
        state={{ from: `${location.pathname}${location.search}${location.hash}` }}
      />
    )
  }
  return <Outlet />
}

/** Signed-in users skip the login page and go to where they were heading (or home). */
export function GuestRoute() {
  const isAuthenticated = useAuthStore(selectIsAuthenticated)
  const location = useLocation()
  const from = (location.state as { from?: string } | null)?.from
  return isAuthenticated ? <Navigate to={safeRedirect(from)} replace /> : <Outlet />
}

/** Shows a "no access" page unless the user may view the given module. */
export function RequireAbility({ subject }: { subject: Subject }) {
  const ability = useAbility<AppAbility>()
  return ability.can('view', subject) ? <Outlet /> : <ForbiddenPage />
}
