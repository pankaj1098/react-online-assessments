import { AbilityProvider } from '@casl/react'
import { QueryClientProvider } from '@tanstack/react-query'
import { useMemo, type ReactNode } from 'react'

import { useAuthStore } from '@/features/auth/store/authStore'
import { defineAbilityFor } from '@/lib/ability'
import { queryClient } from '@/lib/query-client'

/** Wraps the app with server-state and permission providers. */
export function AppProviders({ children }: { children: ReactNode }) {
  const roles = useAuthStore((state) => state.user?.roles)
  const ability = useMemo(() => defineAbilityFor(roles), [roles])

  return (
    <QueryClientProvider client={queryClient}>
      <AbilityProvider value={ability}>{children}</AbilityProvider>
    </QueryClientProvider>
  )
}
