import { AxiosError, type AxiosResponse } from 'axios'
import { describe, expect, it } from 'vitest'

import { ApiError, getErrorMessage, toApiError } from './api-error'

function axiosError(status: number, data: unknown) {
  const error = new AxiosError('failed')
  error.response = { status, data } as AxiosResponse
  return error
}

describe('toApiError', () => {
  it('reads the detail from .NET ProblemDetails', () => {
    const result = toApiError(axiosError(400, { title: 'Bad', detail: 'Employee ID is invalid.' }))
    expect(result.message).toBe('Employee ID is invalid.')
    expect(result.status).toBe(400)
  })

  it('collects validation errors per field', () => {
    const result = toApiError(axiosError(400, { errors: { Place: ['Required'] } }))
    expect(result.fieldErrors).toEqual({ Place: ['Required'] })
  })

  it('falls back to friendly text for server errors', () => {
    expect(getErrorMessage(axiosError(500, ''))).toMatch(/went wrong/i)
  })

  it('reports a network failure when there is no response', () => {
    expect(getErrorMessage(new AxiosError('Network Error'))).toMatch(/unable to reach/i)
  })

  it('passes ApiError through untouched', () => {
    const original = new ApiError('x', 418)
    expect(toApiError(original)).toBe(original)
  })
})
