import axios from 'axios'

/** Normalised error thrown by every API call. */
export class ApiError extends Error {
  readonly status: number | null
  readonly fieldErrors: Record<string, string[]>

  constructor(
    message: string,
    status: number | null = null,
    fieldErrors: Record<string, string[]> = {},
  ) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.fieldErrors = fieldErrors
  }
}

interface ProblemDetails {
  title?: unknown
  detail?: unknown
  message?: unknown
  errors?: unknown
}

function asString(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value : undefined
}

/** Converts any thrown value (Axios, .NET ProblemDetails, plain Error) into an ApiError. */
export function toApiError(error: unknown): ApiError {
  if (error instanceof ApiError) return error

  if (axios.isAxiosError<ProblemDetails>(error)) {
    if (!error.response) {
      return new ApiError(
        error.code === 'ECONNABORTED'
          ? 'The request took too long. Please try again.'
          : 'Unable to reach the server. Check your connection and try again.',
      )
    }
    const { status, data } = error.response
    const fieldErrors: Record<string, string[]> = {}
    if (data && typeof data === 'object' && data.errors && typeof data.errors === 'object') {
      for (const [field, messages] of Object.entries(data.errors)) {
        if (Array.isArray(messages)) {
          fieldErrors[field] = messages.filter((m): m is string => typeof m === 'string')
        }
      }
    }
    const message =
      asString(data?.detail) ??
      asString(data?.message) ??
      asString(data?.title) ??
      (status === 401
        ? 'Your session has expired. Please sign in again.'
        : status === 403
          ? 'You do not have permission to do that.'
          : status >= 500
            ? 'Something went wrong on our side. Please try again later.'
            : 'The request could not be completed.')
    return new ApiError(message, status, fieldErrors)
  }

  return new ApiError(error instanceof Error ? error.message : 'Something went wrong.')
}

export function getErrorMessage(error: unknown): string {
  return toApiError(error).message
}
