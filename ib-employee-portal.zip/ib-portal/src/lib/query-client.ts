import { QueryClient } from '@tanstack/react-query'

import { ApiError } from '@/lib/api-error'

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60_000,
      gcTime: 5 * 60_000,
      refetchOnWindowFocus: false,
      retry: (failureCount, error) => {
        // Client errors (4xx) will not fix themselves - do not retry them.
        if (error instanceof ApiError && error.status !== null && error.status < 500) return false
        return failureCount < 2
      },
    },
    mutations: { retry: false },
  },
})
