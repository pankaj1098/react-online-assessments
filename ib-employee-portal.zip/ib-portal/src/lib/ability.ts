import { createMongoAbility, type MongoAbility } from '@casl/ability'

import { modules, type ModuleId } from '@/config/modules'

export type Action = 'view' | 'create' | 'update' | 'manage'
export type Subject = ModuleId | 'all'
export type AppAbility = MongoAbility<[Action, Subject]>

/** Modules that need a specific role. Everything else is open to every signed-in employee. */
const restrictedModules: Partial<Record<ModuleId, string>> = {
  admin: 'admin',
}

/**
 * Builds the permission set for a signed-in user.
 * Roles come from the .NET login response (`user.roles`).
 */
export function defineAbilityFor(roles: readonly string[] | undefined): AppAbility {
  // Not signed in: no permissions at all.
  if (!roles) return createMongoAbility<[Action, Subject]>([])
  const userRoles = roles
  const rules: { action: Action; subject: Subject }[] = []

  if (userRoles.includes('admin')) {
    rules.push({ action: 'manage', subject: 'all' })
  } else {
    for (const { id } of modules) {
      const required = restrictedModules[id]
      if (!required || userRoles.includes(required)) {
        rules.push({ action: 'view', subject: id })
      }
    }
    rules.push(
      { action: 'create', subject: 'gate-pass' },
      { action: 'update', subject: 'gate-pass' },
    )
  }

  return createMongoAbility<[Action, Subject]>(rules)
}
