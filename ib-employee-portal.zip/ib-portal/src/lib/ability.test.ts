import { describe, expect, it } from 'vitest'

import { defineAbilityFor } from './ability'

describe('defineAbilityFor', () => {
  it('lets employees open everything except Admin', () => {
    const ability = defineAbilityFor(['employee'])
    expect(ability.can('view', 'gate-pass')).toBe(true)
    expect(ability.can('view', 'hr')).toBe(true)
    expect(ability.can('view', 'admin')).toBe(false)
  })

  it('lets admins open Admin', () => {
    expect(defineAbilityFor(['employee', 'admin']).can('view', 'admin')).toBe(true)
  })

  it('denies everything when signed out', () => {
    expect(defineAbilityFor(undefined).can('create', 'gate-pass')).toBe(false)
  })
})
