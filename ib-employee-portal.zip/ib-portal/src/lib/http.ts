import axios, { type AxiosError, type InternalAxiosRequestConfig } from 'axios'

import { endpoints } from '@/config/endpoints'
import { env } from '@/config/env'
import { useAuthStore } from '@/features/auth/store/authStore'
import { toApiError } from '@/lib/api-error'

/** Shared Axios instance for the .NET Web API. */
export const http = axios.create({
  baseURL: env.apiBaseUrl,
  timeout: 30_000,
  headers: { Accept: 'application/json' },
})

http.interceptors.request.use((config) => {
  const token = useAuthStore.getState().accessToken
  if (token) config.headers.set('Authorization', `Bearer ${token}`)
  return config
})

type RetriableConfig = InternalAxiosRequestConfig & { _retried?: boolean }

let refreshInFlight: Promise<string | null> | null = null

/** Exchanges the refresh token for a new access token. Concurrent callers share one request. */
async function refreshAccessToken(): Promise<string | null> {
  const { refreshToken, setTokens } = useAuthStore.getState()
  if (!refreshToken) return null

  refreshInFlight ??= axios
    .post<{ accessToken: string; refreshToken?: string }>(
      `${env.apiBaseUrl}${endpoints.auth.refresh}`,
      { refreshToken },
      { timeout: 15_000 },
    )
    .then(({ data }) => {
      setTokens(data)
      return data.accessToken
    })
    .catch(() => null)
    .finally(() => {
      refreshInFlight = null
    })

  return refreshInFlight
}

http.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const original = error.config as RetriableConfig | undefined
    const isAuthCall = original?.url?.startsWith(endpoints.auth.login) ?? false

    if (error.response?.status === 401 && original && !original._retried && !isAuthCall) {
      original._retried = true
      const newToken = await refreshAccessToken()
      if (newToken) {
        original.headers.set('Authorization', `Bearer ${newToken}`)
        return http(original)
      }
      // Session is no longer valid: clearing it sends the user to /login via the route guard.
      useAuthStore.getState().clear()
    }
    return Promise.reject(toApiError(error))
  },
)
