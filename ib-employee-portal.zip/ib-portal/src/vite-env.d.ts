/// <reference types="vite/client" />

/** true when running with built-in mock data (set via VITE_USE_MOCK, never in production). */
declare const __USE_MOCK__: boolean
