import type { ReactNode } from 'react'

export function EmptyState({ children }: { children: ReactNode }) {
  return (
    <p className="col-span-full px-4 py-8 text-center text-sm text-muted-foreground">{children}</p>
  )
}
