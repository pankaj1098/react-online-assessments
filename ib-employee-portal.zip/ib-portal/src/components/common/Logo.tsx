import logoUrl from '@/assets/ib-group-logo.svg'
import { cn } from '@/lib/utils'

interface LogoProps {
  className?: string
  /** Pass "" when the logo sits next to the text "IB GROUP" (decorative). */
  alt?: string
}

/** The single place that imports the logo file. Swap the asset to rebrand. */
export function Logo({ className, alt = 'IB Group logo' }: LogoProps) {
  return (
    <img
      src={logoUrl}
      alt={alt}
      width={64}
      height={64}
      className={cn('rounded-full bg-white object-contain', className)}
    />
  )
}
