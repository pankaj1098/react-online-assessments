export function PageLoader() {
  return (
    <div role="status" aria-live="polite" className="flex min-h-[40vh] items-center justify-center">
      <span className="size-8 animate-spin rounded-full border-4 border-primary-soft border-t-primary" />
      <span className="sr-only">Loading</span>
    </div>
  )
}
