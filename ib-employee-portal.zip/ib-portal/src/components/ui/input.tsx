import type { ComponentProps, ReactNode } from 'react'

import { cn } from '@/lib/utils'

const controlClasses =
  'w-full rounded-lg border border-input bg-card text-sm text-foreground transition-colors placeholder:text-muted-foreground focus-visible:border-ring focus-visible:outline-2 focus-visible:outline-offset-0 focus-visible:outline-ring/25 disabled:cursor-not-allowed disabled:opacity-60 aria-invalid:border-destructive'

interface IconProps {
  /** Decorative icon shown inside the left edge of the control. */
  icon?: ReactNode
}

/** Wraps a control so an optional icon can sit inside its left edge. */
function IconSlot({
  icon,
  alignTop,
  children,
  className,
}: {
  icon?: ReactNode
  alignTop?: boolean
  children: ReactNode
  className?: string
}) {
  if (!icon) return <>{children}</>
  return (
    <div className={cn('relative', className)}>
      <span
        aria-hidden="true"
        className={cn(
          'pointer-events-none absolute left-3.5 flex text-foreground [&_svg]:size-5',
          alignTop ? 'top-3' : 'top-1/2 -translate-y-1/2',
        )}
      >
        {icon}
      </span>
      {children}
    </div>
  )
}

function Input({ className, icon, type = 'text', ...props }: ComponentProps<'input'> & IconProps) {
  return (
    <IconSlot icon={icon}>
      <input
        type={type}
        className={cn(controlClasses, 'h-11 px-3.5', icon && 'pl-11', className)}
        {...props}
      />
    </IconSlot>
  )
}

function Textarea({ className, icon, ...props }: ComponentProps<'textarea'> & IconProps) {
  return (
    <IconSlot icon={icon} alignTop>
      <textarea
        className={cn(controlClasses, 'min-h-28 resize-y px-3.5 py-3', icon && 'pl-11', className)}
        {...props}
      />
    </IconSlot>
  )
}

/** Native <select>: fully accessible and uses the OS picker on mobile. */
function NativeSelect({
  className,
  icon,
  children,
  ...props
}: ComponentProps<'select'> & IconProps) {
  return (
    <IconSlot icon={icon}>
      <select className={cn(controlClasses, 'h-11 px-3.5', icon && 'pl-11', className)} {...props}>
        {children}
      </select>
    </IconSlot>
  )
}

export { Input, NativeSelect, Textarea }
