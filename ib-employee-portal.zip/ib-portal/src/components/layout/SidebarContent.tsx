import { useAbility } from '@casl/react'
import { Search, X } from 'lucide-react'
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom'

import { Logo } from '@/components/common/Logo'
import { modules } from '@/config/modules'
import type { AppAbility } from '@/lib/ability'
import { cn } from '@/lib/utils'
import { useUiStore } from '@/stores/uiStore'

interface SidebarContentProps {
  /** Icon-only rail (desktop, collapsed). */
  collapsed?: boolean
  /** Called after a link is chosen (used to close the mobile drawer). */
  onNavigate?: () => void
}

export function SidebarContent({ collapsed = false, onNavigate }: SidebarContentProps) {
  const ability = useAbility<AppAbility>()
  const navigate = useNavigate()
  const { pathname } = useLocation()
  const search = useUiStore((state) => state.applicationSearch)
  const setSearch = useUiStore((state) => state.setApplicationSearch)

  function handleSearch(value: string) {
    setSearch(value)
    // Applications live on the home page, so show them as soon as the user searches.
    if (value && pathname !== '/') navigate('/')
  }

  return (
    <div className="flex h-full flex-col">
      <Link
        to="/"
        onClick={onNavigate}
        className={cn(
          'flex h-24 shrink-0 items-center gap-3 border-b border-sidebar-border text-2xl font-bold whitespace-nowrap',
          collapsed ? 'justify-center px-3' : 'px-8',
        )}
      >
        <Logo alt="" className="size-12 shrink-0" />
        <span className={cn(collapsed && 'sr-only')}>IB GROUP</span>
        {collapsed && <span className="sr-only">Home</span>}
      </Link>

      {!collapsed && (
        <search className="mx-3 mt-6 mb-3">
          <label className="flex h-10 items-center gap-2 rounded-lg border border-white/30 bg-white/10 px-2.5 focus-within:border-white/70">
            <Search className="size-4 shrink-0" aria-hidden="true" />
            <span className="sr-only">Search applications</span>
            <input
              type="search"
              value={search}
              onChange={(event) => handleSearch(event.target.value)}
              placeholder="Search applications..."
              autoComplete="off"
              className="min-w-0 flex-1 bg-transparent text-sm text-white outline-none placeholder:text-white/75 [&::-webkit-search-cancel-button]:hidden"
            />
            {search && (
              <button
                type="button"
                aria-label="Clear search"
                onClick={() => setSearch('')}
                className="rounded p-0.5 hover:bg-white/15"
              >
                <X className="size-3.5" aria-hidden="true" />
              </button>
            )}
          </label>
        </search>
      )}

      <nav
        aria-label="Main navigation"
        className={cn('flex-1 overflow-y-auto px-2.5 pb-6', collapsed && 'pt-6')}
      >
        <ul className="grid gap-1.5">
          {modules
            .filter((module) => ability.can('view', module.id))
            .map((module) => (
              <li key={module.id}>
                <NavLink
                  to={module.path}
                  end={module.path === '/'}
                  onClick={onNavigate}
                  title={module.name}
                  className={({ isActive }) =>
                    cn(
                      'flex min-h-12 items-center gap-4 rounded-xl text-base transition-colors',
                      collapsed ? 'justify-center' : 'px-4',
                      isActive
                        ? 'bg-sidebar-active font-bold text-sidebar-active-foreground shadow-sm'
                        : 'text-sidebar-foreground hover:bg-sidebar-hover',
                    )
                  }
                >
                  <module.icon className="size-5.5 shrink-0" aria-hidden="true" />
                  <span className={cn(collapsed && 'sr-only')}>{module.name}</span>
                </NavLink>
              </li>
            ))}
        </ul>
      </nav>
    </div>
  )
}
