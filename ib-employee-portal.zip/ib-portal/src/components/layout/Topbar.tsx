import { ChevronDown, LogOut, Menu, UserRound } from 'lucide-react'

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { useAuthStore } from '@/features/auth/store/authStore'
import { useLogout } from '@/features/auth/hooks'
import { NotificationBell } from '@/features/notifications/components/NotificationBell'

interface TopbarProps {
  onToggleNav: () => void
  navExpanded: boolean
}

export function Topbar({ onToggleNav, navExpanded }: TopbarProps) {
  const user = useAuthStore((state) => state.user)
  const logout = useLogout()
  const showId = user && user.name !== user.employeeId

  return (
    <header className="sticky top-0 z-20 flex h-topbar items-center gap-3 border-b border-border bg-card px-3 shadow-sm sm:gap-5 sm:px-6">
      <button
        type="button"
        aria-label="Toggle navigation"
        aria-expanded={navExpanded}
        aria-controls="main-navigation"
        onClick={onToggleNav}
        className="rounded-lg p-2 text-primary hover:bg-secondary"
      >
        <Menu className="size-6" aria-hidden="true" />
      </button>
      <span className="text-base font-medium sm:text-xl">Employee Portal</span>
      <div className="flex-1" />
      <NotificationBell />
      <DropdownMenu>
        <DropdownMenuTrigger className="flex items-center gap-2 rounded-lg p-1 text-left hover:bg-secondary sm:gap-3">
          <span className="grid size-10 place-items-center rounded-full bg-primary-soft text-primary sm:size-12">
            <UserRound className="size-6" aria-hidden="true" />
          </span>
          <span className="hidden sm:block">
            <b className="font-semibold">{user?.name ?? 'Employee'}</b>
            <small className="ml-1 text-sm text-muted-foreground">
              ({showId ? user.employeeId : 'Employee'})
            </small>
          </span>
          <span className="sr-only sm:hidden">Account menu</span>
          <ChevronDown className="size-4" aria-hidden="true" />
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-60">
          <DropdownMenuLabel>
            Signed in as <b>{user?.name}</b>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem onSelect={logout} className="font-semibold text-primary">
            <LogOut aria-hidden="true" /> Sign out
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  )
}
