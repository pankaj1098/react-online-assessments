import { Suspense } from 'react'
import { Outlet, useNavigation } from 'react-router-dom'

import { PageLoader } from '@/components/common/PageLoader'
import { Sheet, SheetContent, SheetDescription, SheetTitle } from '@/components/ui/sheet'
import { useMediaQuery } from '@/hooks/useMediaQuery'
import { cn } from '@/lib/utils'
import { useUiStore } from '@/stores/uiStore'

import { SidebarContent } from './SidebarContent'
import { Topbar } from './Topbar'

/** Authenticated layout: sidebar + top bar + page content. */
export function AppShell() {
  const isDesktop = useMediaQuery('(min-width: 1024px)')
  const collapsed = useUiStore((state) => state.sidebarCollapsed)
  const mobileOpen = useUiStore((state) => state.mobileNavOpen)
  const toggleSidebar = useUiStore((state) => state.toggleSidebar)
  const setMobileOpen = useUiStore((state) => state.setMobileNavOpen)
  const navigation = useNavigation()

  return (
    <div className="min-h-screen bg-background">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[60] focus:rounded-lg focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground"
      >
        Skip to main content
      </a>

      {navigation.state === 'loading' && (
        <div
          role="progressbar"
          aria-label="Loading page"
          className="fixed inset-x-0 top-0 z-[70] h-1 animate-pulse bg-brand-highlight"
        />
      )}

      {isDesktop ? (
        <aside
          id="main-navigation"
          className={cn(
            'fixed inset-y-0 left-0 z-30 overflow-hidden bg-sidebar text-sidebar-foreground transition-[width] duration-200',
            collapsed ? 'w-sidebar-collapsed' : 'w-sidebar',
          )}
        >
          <SidebarContent collapsed={collapsed} />
        </aside>
      ) : (
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetContent id="main-navigation">
            <SheetTitle className="sr-only">Navigation</SheetTitle>
            <SheetDescription className="sr-only">Portal sections</SheetDescription>
            <SidebarContent onNavigate={() => setMobileOpen(false)} />
          </SheetContent>
        </Sheet>
      )}

      <div
        className={cn(
          'min-h-screen transition-[margin] duration-200',
          isDesktop && (collapsed ? 'ml-sidebar-collapsed' : 'ml-sidebar'),
        )}
      >
        <Topbar
          navExpanded={isDesktop ? !collapsed : mobileOpen}
          onToggleNav={isDesktop ? toggleSidebar : () => setMobileOpen(!mobileOpen)}
        />
        <main id="main-content" tabIndex={-1} className="px-4 py-5 outline-none sm:px-6 sm:pb-8">
          <Suspense fallback={<PageLoader />}>
            <Outlet />
          </Suspense>
        </main>
      </div>
    </div>
  )
}
