# IB Group Employee Portal

HR and employee self-service portal (React migration of the PHP site). Login-only, internal.

| Area         | Choice                                                                       |
| ------------ | ---------------------------------------------------------------------------- |
| Framework    | React 19, JavaScript (JSX), Vite 8, React Compiler                           |
| UI           | Tailwind CSS 4 + shadcn/ui-style components (Radix primitives), lucide icons |
| Routing      | React Router 7, every page lazy-loaded                                       |
| Server state | TanStack Query                                                               |
| Client state | Zustand (session, sidebar)                                                   |
| HTTP         | Axios (token header, refresh-on-401, .NET `ProblemDetails` errors)           |
| Forms        | React Hook Form + Zod                                                        |
| Permissions  | CASL (module access by role)                                                 |
| Quality      | ESLint (+ security plugin), Prettier, Husky, lint-staged, Commitlint, Vitest |

## Getting started

```bash
npm install
cp .env.example .env.local     # optional; .env.development already enables mock data
npm run dev                    # http://localhost:5173
```

In development `VITE_USE_MOCK=true`, so you can sign in with any employee ID and any password
without a backend. Use `locked` as the ID to see an error state.

| Script            | What it does                                  |
| ----------------- | --------------------------------------------- |
| `npm run dev`     | Dev server with hot reload                    |
| `npm run build`   | Type-check, then production build into `dist` |
| `npm run preview` | Serve the production build locally            |
| `npm run lint`    | ESLint                                        |
| `npm run format`  | Prettier                                      |
| `npm test`        | Unit and integration tests (Vitest)           |

## Changing the look: one file

Everything visual lives in **`src/styles/theme.css`**:

- **Font**: change the `@import '@fontsource-variable/inter'` line and `--font-family-sans`
- **Colours**: the `--primary`, `--sidebar`, `--background`... variables in `:root`
- **Font size**: `--font-size-base` (all sizes are rem-based and scale with it)
- **Corner radius**: `--radius`
- **Sidebar / top bar size**: `--spacing-sidebar`, `--spacing-topbar`

No component hard-codes a colour, font or size. The logo is the only image asset:
replace `src/assets/ib-group-logo.svg` (or point `components/common/Logo.jsx` at a PNG), and the
files in `public/` (`favicon.svg`, `favicon-32.png`, `apple-touch-icon.png`, `icon-192.png`,
`icon-512.png`, `og-image.png`).

## Folder structure

```
src/
  app/            App root, providers, router (routes.jsx, guards.jsx)
  components/
    ui/           shadcn-style primitives (button, input, dialog, ...)
    layout/       AppShell, Sidebar, Topbar, breadcrumbs, page hero
    common/       Logo, loaders, empty state
  config/         env, site copy, modules (sidebar), applications (dashboard tiles), API endpoints
  features/       One folder per area, each self-contained
    auth/           api, store, hooks, login page
    dashboard/      announcements, application tiles
    notifications/  bell + panel
    gate-pass/      api, hooks, schemas, list + form pages
    modules/        landing page for areas not migrated yet
    errors/         404, access denied, crash page
  hooks/          shared hooks (page title, media query, debounce)
  lib/            axios client, query client, CASL abilities, date/error helpers
  stores/         Zustand UI state
  styles/         theme.css (the one place to restyle) and index.css
  test/           test setup
```

**Adding a new module/page**: add it to `config/modules.js` (sidebar and permissions pick it up),
create `features/<name>/` with `api/`, `hooks.js`, `pages/`, and register the page in
`app/router/routes.jsx` using the `page(() => import(...))` helper. Call `usePageMeta('Title')` and
render exactly one `<h1>` in each page.

Types are documented with JSDoc (see `src/features/*/types.js`), and request/response shapes are
checked at runtime with Zod.

## Connecting the .NET API

Everything backend-specific is in three places, so adjusting to the real contract is quick:

1. **`src/config/endpoints.js`**: route paths.
2. **`src/features/auth/api/auth.schemas.js`** and **`authApi.js`**: login request body and the
   response shape (`accessToken`, optional `refreshToken`, `user { employeeId, name, roles }`).
3. **`src/features/*/api/*Api.js`**: request/response shapes per feature. Gate pass list is assumed
   to be `GET /gate-passes?search&from&to&purpose&status&page&pageSize` returning `{ items, total }`.

Set `VITE_API_BASE_URL` (default `/api`). In development, set `VITE_API_PROXY_TARGET` to your API
origin and Vite will proxy `/api` to it, so no CORS setup is needed. For production, serve the portal
and API on the same origin (or enable CORS for the portal origin).

Roles come from `user.roles`. Admin is visible only to `admin`; change this in `src/lib/ability.js`.

Mock data is compiled out of production builds, and a production build with `VITE_USE_MOCK=true`
fails on purpose.

## Production

- `npm run build`, then publish `dist/`.
- The app uses clean URLs, so the server must return `index.html` for unknown paths.
  `public/web.config` already does this for IIS. For nginx:
  `location / { try_files $uri /index.html; }`
- Source maps are disabled. JavaScript is split into per-page chunks plus three cached vendor chunks.
- The site is marked `noindex` and `robots.txt` disallows all crawling because it is an internal portal.
- Set `VITE_SITE_URL` (for example `https://portal.ibgroup.com`) so the share image (`og:image`) uses an absolute URL.
- Dashboard application tiles stay disabled until you fill in `href` for each app in
  `src/config/applications.js`.
