/** Only follow post-login redirects that stay inside the app. */
export function safeRedirect(from) {
  if (
    typeof from === 'string' &&
    from.startsWith('/') &&
    !from.startsWith('//') &&
    !from.startsWith('/login')
  ) {
    return from
  }
  return '/'
}
