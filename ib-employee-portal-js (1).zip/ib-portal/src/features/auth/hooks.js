import { useMutation, useQueryClient } from '@tanstack/react-query'
import { authApi } from './api/authApi'
import { useAuthStore } from './store/authStore'

export function useLogin() {
  const setSession = useAuthStore((state) => state.setSession)
  return useMutation({
    mutationFn: (values) => authApi.login(values),
    onSuccess: setSession,
  })
}

export function useLogout() {
  const clear = useAuthStore((state) => state.clear)
  const queryClient = useQueryClient()
  return () => {
    void authApi.logout(useAuthStore.getState().accessToken)
    clear()
    queryClient.clear()
  }
}
