import { endpoints } from '@/config/endpoints'
import { ApiError } from '@/lib/api-error'
import { http } from '@/lib/http'
import { loginResponseSchema } from './auth.schemas'

export const authApi = {
  async login(values) {
    if (__USE_MOCK__) {
      const { mockLogin } = await import('./authMock')
      return mockLogin(values)
    }
    // Request body: rename keys here if the .NET API expects e.g. `userName`.
    const { data } = await http.post(endpoints.auth.login, {
      employeeId: values.employeeId,
      password: values.password,
    })
    const parsed = loginResponseSchema.safeParse(data)
    if (!parsed.success) {
      throw new ApiError('Unexpected response from the sign-in service.')
    }
    const { accessToken, refreshToken, user } = parsed.data
    return { accessToken, refreshToken, user }
  },
  /** The token is passed explicitly because the local session is cleared right after this call. */
  async logout(accessToken) {
    if (__USE_MOCK__ || !accessToken) return
    try {
      await http.post(endpoints.auth.logout, null, {
        headers: { Authorization: `Bearer ${accessToken}` },
      })
    } catch {
      // The local session is cleared regardless of whether the server call worked.
    }
  },
}
