import { ApiError } from '@/lib/api-error'

/** Dev-only: accepts any employee ID with a non-empty password. */
export async function mockLogin({ employeeId }) {
  await new Promise((resolve) => setTimeout(resolve, 400))
  if (employeeId.toLowerCase() === 'locked') {
    throw new ApiError('This account is locked. Please contact your IT administrator.', 403)
  }
  return {
    accessToken: `mock-token-${employeeId}`,
    refreshToken: `mock-refresh-${employeeId}`,
    user: {
      employeeId,
      name: employeeId,
      roles: ['employee', 'admin'],
    },
  }
}
