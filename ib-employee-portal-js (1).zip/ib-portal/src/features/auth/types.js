/**
 * @typedef {Object} AuthUser
 * @property {string} employeeId
 * @property {string} name
 * @property {string} [email]
 * @property {string[]} roles
 */

/**
 * @typedef {Object} AuthSession
 * @property {AuthUser} user
 * @property {string} accessToken
 * @property {string} [refreshToken]
 */

export {}
