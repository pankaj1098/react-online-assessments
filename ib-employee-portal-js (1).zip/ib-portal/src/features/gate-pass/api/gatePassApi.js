import { endpoints } from '@/config/endpoints'
import { http } from '@/lib/http'

/**
 * Gate pass calls. Query parameter names and the `{ items, total }` list shape are the
 * contract assumed for the .NET API - adjust here if the controller differs.
 */
export const gatePassApi = {
  async list(params) {
    if (__USE_MOCK__) return (await import('./gatePassMock')).mockList(params)
    const { data } = await http.get(endpoints.gatePass.collection, {
      params: {
        search: params.search || undefined,
        from: params.from || undefined,
        to: params.to || undefined,
        purpose: params.purpose || undefined,
        status: params.status || undefined,
        page: params.page,
        pageSize: params.pageSize,
      },
    })
    return data
  },
  async get(id) {
    if (__USE_MOCK__) return (await import('./gatePassMock')).mockGet(id)
    const { data } = await http.get(endpoints.gatePass.item(id))
    return data
  },
  async create(input) {
    if (__USE_MOCK__) return (await import('./gatePassMock')).mockCreate(input)
    const { data } = await http.post(endpoints.gatePass.collection, input)
    return data
  },
  async update(id, input) {
    if (__USE_MOCK__) return (await import('./gatePassMock')).mockUpdate(id, input)
    const { data } = await http.put(endpoints.gatePass.item(id), input)
    return data
  },
}
