import { z } from 'zod'
import { gatePassPurposes } from '../types'

export const gatePassFormSchema = z.object({
  place: z
    .string()
    .trim()
    .min(1, 'Enter the place.')
    .max(150, 'Place is too long (max 150 characters).'),
  dateTime: z.string().min(1, 'Select the date and time.'),
  contactPerson: z
    .string()
    .trim()
    .min(1, 'Enter the contact person.')
    .max(100, 'Name is too long (max 100 characters).'),
  // Starts as "" (nothing selected); the pipe turns it into a typed purpose or a friendly error.
  purpose: z.string().pipe(z.enum(gatePassPurposes, { error: 'Select the purpose of visit.' })),
  reason: z
    .string()
    .trim()
    .min(1, 'Enter the reason for the visit.')
    .max(500, 'Reason is too long (max 500 characters).'),
})

export const REASON_MAX_LENGTH = 500
