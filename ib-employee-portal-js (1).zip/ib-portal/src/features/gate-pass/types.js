export const gatePassPurposes = ['Official', 'Personal', 'Business', 'Emergency', 'Other']

export const gatePassStatuses = ['Pending', 'Approved', 'Rejected']

/** @typedef {'Official' | 'Personal' | 'Business' | 'Emergency' | 'Other'} GatePassPurpose */

/** @typedef {'Pending' | 'Approved' | 'Rejected'} GatePassStatus */

/**
 * @typedef {Object} GatePassRequest
 * @property {string} id
 * @property {string} place
 * @property {string} dateTime Local date-time, "YYYY-MM-DDTHH:mm"
 * @property {GatePassPurpose} purpose
 * @property {string} contactPerson
 * @property {string} reason
 * @property {GatePassStatus} status Set by the server
 * @property {string} createdOn ISO timestamp set by the server
 */

/**
 * What the employee fills in: place, dateTime, purpose, contactPerson, reason.
 * @typedef {Pick<GatePassRequest, 'place' | 'dateTime' | 'purpose' | 'contactPerson' | 'reason'>} GatePassInput
 */

/**
 * @typedef {Object} GatePassFilters
 * @property {string} from "YYYY-MM-DD" or ""
 * @property {string} to
 * @property {GatePassPurpose | ''} purpose
 * @property {GatePassStatus | ''} status
 */

/**
 * @typedef {GatePassFilters & { search: string, page: number, pageSize: number }} GatePassListParams
 */

/**
 * @template T
 * @typedef {Object} Paged
 * @property {T[]} items
 * @property {number} total
 */

export const emptyFilters = { from: '', to: '', purpose: '', status: '' }
