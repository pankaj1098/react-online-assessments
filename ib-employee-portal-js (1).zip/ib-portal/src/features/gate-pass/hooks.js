import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { gatePassApi } from './api/gatePassApi'

export const gatePassKeys = {
  all: ['gate-pass'],
  list: (params) => [...gatePassKeys.all, 'list', params],
  detail: (id) => [...gatePassKeys.all, 'detail', id],
}

export function useGatePassList(params) {
  return useQuery({
    queryKey: gatePassKeys.list(params),
    queryFn: () => gatePassApi.list(params),
    placeholderData: keepPreviousData,
  })
}

export function useGatePass(id) {
  return useQuery({
    queryKey: gatePassKeys.detail(id ?? ''),
    queryFn: () => gatePassApi.get(id ?? ''),
    enabled: Boolean(id),
  })
}

export function useCreateGatePass() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (input) => gatePassApi.create(input),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: gatePassKeys.all }),
  })
}

export function useUpdateGatePass(id) {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (input) => gatePassApi.update(id, input),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: gatePassKeys.all }),
  })
}
