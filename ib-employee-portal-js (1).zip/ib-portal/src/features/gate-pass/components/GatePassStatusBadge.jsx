import { CircleCheck, Clock, CircleX } from 'lucide-react'
import { Badge } from '@/components/ui/badge'

const config = {
  Approved: { variant: 'success', icon: CircleCheck },
  Pending: { variant: 'warning', icon: Clock },
  Rejected: { variant: 'danger', icon: CircleX },
}

export function GatePassStatusBadge({ status }) {
  const { variant, icon: Icon } = config[status]
  return (
    <Badge variant={variant}>
      <Icon aria-hidden="true" />
      {status}
    </Badge>
  )
}
