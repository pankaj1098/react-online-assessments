import { usePageMeta } from '@/hooks/usePageMeta'
import { useAuthStore } from '@/features/auth/store/authStore'
import { NotificationsPanel } from '@/features/notifications/components/NotificationsPanel'
import { AnnouncementBar } from '../components/AnnouncementBar'
import { ApplicationsPanel } from '../components/ApplicationsPanel'

export default function DashboardPage() {
  usePageMeta('Home', 'Your IB Group applications, announcements and notifications in one place.')
  const user = useAuthStore((state) => state.user)
  return (
    <>
      <AnnouncementBar />
      <div className="mt-6 grid items-start gap-5 xl:grid-cols-[minmax(0,1.58fr)_minmax(22rem,1fr)]">
        <div className="min-w-0">
          <div className="mb-4 px-1">
            <h1 className="text-2xl font-bold tracking-tight sm:text-4xl">
              Welcome back, {user?.name ?? 'Employee'}
            </h1>
            <p className="mt-1.5 text-muted-foreground">
              Access and manage all IB Group applications from one place.
            </p>
          </div>
          <ApplicationsPanel />
        </div>
        <NotificationsPanel />
      </div>
    </>
  )
}
