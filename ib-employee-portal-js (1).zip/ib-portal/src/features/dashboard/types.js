/**
 * @typedef {Object} Announcement
 * @property {string} id
 * @property {string} message
 */

export {}
