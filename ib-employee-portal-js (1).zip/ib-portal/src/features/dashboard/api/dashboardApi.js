import { endpoints } from '@/config/endpoints'
import { http } from '@/lib/http'

export const dashboardApi = {
  async announcements() {
    if (__USE_MOCK__) {
      const { mockAnnouncements } = await import('./dashboardMock')
      return mockAnnouncements()
    }
    const { data } = await http.get(endpoints.dashboard.announcements)
    return data
  },
}
