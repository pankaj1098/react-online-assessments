export async function mockAnnouncements() {
  await new Promise((resolve) => setTimeout(resolve, 200))
  return [
    { id: 'a-1', message: 'IB Group Annual Townhall on 28 Nov 2026 at 4:00 PM.' },
    {
      id: 'a-2',
      message: 'Holiday: Office will remain closed on 25 Nov 2026 (Guru Nanak Jayanti).',
    },
  ]
}
