import { ChevronLeft, ChevronRight, Megaphone } from 'lucide-react'
import { useState } from 'react'
import { useAnnouncements } from '../hooks'

export function AnnouncementBar() {
  const { data: announcements = [] } = useAnnouncements()
  const [index, setIndex] = useState(0)
  if (announcements.length === 0) return null
  const count = announcements.length
  const current = announcements[index % count]
  const next = count > 1 ? announcements[(index + 1) % count] : undefined
  return (
    <section
      aria-label="Announcements"
      className="flex min-h-14 items-center gap-3 overflow-hidden rounded-2xl bg-primary-soft px-4 py-2 text-foreground shadow-sm sm:gap-4 sm:px-5"
    >
      <Megaphone className="size-6 shrink-0 text-primary" aria-hidden="true" />
      <b className="shrink-0 text-base text-primary-soft-foreground sm:text-lg">Announcement:</b>
      <span aria-hidden="true" className="hidden text-primary sm:inline">
        |
      </span>
      <p aria-live="polite" className="min-w-0 flex-1 truncate text-sm">
        {current?.message}
      </p>
      {next && (
        <>
          <span
            aria-hidden="true"
            className="hidden size-2.5 shrink-0 rounded-full bg-primary xl:block"
          />
          <p aria-hidden="true" className="hidden min-w-0 flex-1 truncate text-sm xl:block">
            {next.message}
          </p>
        </>
      )}
      {count > 1 && (
        <div className="flex shrink-0 gap-1.5">
          <button
            type="button"
            aria-label="Previous announcement"
            onClick={() => setIndex((index + count - 1) % count)}
            className="grid h-9 w-9 place-items-center rounded-lg border border-primary/20 bg-card text-primary hover:bg-secondary"
          >
            <ChevronLeft className="size-5" aria-hidden="true" />
          </button>
          <button
            type="button"
            aria-label="Next announcement"
            onClick={() => setIndex((index + 1) % count)}
            className="grid h-9 w-9 place-items-center rounded-lg border border-primary/20 bg-card text-primary hover:bg-secondary"
          >
            <ChevronRight className="size-5" aria-hidden="true" />
          </button>
        </div>
      )}
    </section>
  )
}
