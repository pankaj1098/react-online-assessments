import { useAbility } from '@casl/react'
import { ChevronRight } from 'lucide-react'
import { Link, useLocation } from 'react-router-dom'
import { PageBreadcrumbs } from '@/components/layout/PageBreadcrumbs'
import { PageHero } from '@/components/layout/PageHero'
import { Card } from '@/components/ui/card'
import { findModuleTrail } from '@/config/modules'
import NotFoundPage from '@/features/errors/pages/NotFoundPage'
import { usePageMeta } from '@/hooks/usePageMeta'

/** Landing page for a module: lists its sub modules, or a "coming soon" note if it has none. */
export default function ModulePage() {
  const { pathname } = useLocation()
  const ability = useAbility()
  const trail = findModuleTrail(pathname)
  const module = trail.at(-1)
  usePageMeta(module?.name, module?.summary)
  if (!module) return <NotFoundPage />

  const Icon = module.icon ?? trail[0].icon
  const children = (module.children ?? []).filter((child) => ability.can('view', child.id))
  const crumbs = trail.map((item, index) => ({
    label: item.name,
    to: index < trail.length - 1 ? item.path : undefined,
  }))

  return (
    <div className="mx-auto max-w-[100rem]">
      <PageBreadcrumbs items={crumbs} />
      <PageHero icon={<Icon />} title={module.name} description={module.summary} />
      {children.length > 0 ? (
        <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {children.map((child) => (
            <li key={child.id}>
              <Card className="transition hover:-translate-y-0.5 hover:shadow-md">
                <Link
                  to={child.path}
                  className="flex items-center justify-between gap-3 rounded-2xl p-5"
                >
                  <span className="min-w-0">
                    <b className="block font-semibold">{child.name}</b>
                    <span className="mt-1 block text-sm text-muted-foreground">
                      {child.summary}
                    </span>
                  </span>
                  <ChevronRight className="size-5 shrink-0 text-primary" aria-hidden="true" />
                </Link>
              </Card>
            </li>
          ))}
        </ul>
      ) : (
        <div className="rounded-2xl border border-border bg-card p-8 text-center shadow-sm">
          <p className="font-semibold">This section is being moved to the new portal.</p>
          <p className="mt-2 text-muted-foreground">
            {module.name} tools will appear here soon. Until then, continue to use the existing
            portal for this area.
          </p>
        </div>
      )}
    </div>
  )
}
