import { endpoints } from '@/config/endpoints'
import { http } from '@/lib/http'

export const notificationsApi = {
  async list() {
    if (__USE_MOCK__) {
      const { mockNotifications } = await import('./notificationsMock')
      return mockNotifications()
    }
    const { data } = await http.get(endpoints.dashboard.notifications)
    return data
  },
}
