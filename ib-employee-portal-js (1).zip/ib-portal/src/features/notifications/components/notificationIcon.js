import { Bell, CalendarDays, FileText, Users } from 'lucide-react'

export const notificationIcons = {
  event: CalendarDays,
  holiday: CalendarDays,
  hr: Users,
  policy: FileText,
  general: Bell,
}
