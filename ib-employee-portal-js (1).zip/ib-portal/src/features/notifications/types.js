/** @typedef {'event' | 'hr' | 'holiday' | 'policy' | 'general'} NotificationCategory */

/**
 * @typedef {Object} PortalNotification
 * @property {string} id
 * @property {NotificationCategory} category
 * @property {string} title
 * @property {string} message
 * @property {string} createdAt ISO timestamp
 * @property {boolean} important
 * @property {boolean} unread
 */

export {}
