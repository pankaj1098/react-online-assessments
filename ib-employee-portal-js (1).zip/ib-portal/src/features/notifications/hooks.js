import { useQuery } from '@tanstack/react-query'
import { notificationsApi } from './api/notificationsApi'

export const notificationKeys = {
  all: ['notifications'],
}

export function useNotifications() {
  return useQuery({
    queryKey: notificationKeys.all,
    queryFn: notificationsApi.list,
    // Keep the bell badge reasonably fresh without hammering the API.
    refetchInterval: 5 * 60_000,
  })
}
