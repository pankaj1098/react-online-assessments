export const MEETING_ROOMS_PATH = '/admin/meeting-room-bookings'

export const bookingStatuses = ['Pending', 'Accepted', 'Rejected', 'Cancelled']

export const calendarViews = [
  { id: 'month', label: 'Month' },
  { id: 'week', label: 'Week' },
  { id: 'day', label: 'Day' },
  { id: 'list', label: 'List' },
]

/**
 * @typedef {Object} MeetingRoom
 * @property {string} id
 * @property {string} name
 * @property {string} location Building or group, e.g. "Corp-I"
 * @property {number} capacity
 * @property {string[]} facilities
 * @property {string} tone Theme tone used to colour-code the room
 */

/**
 * One row per day.
 * @typedef {Object} Booking
 * @property {string} id
 * @property {string} roomId
 * @property {string} roomName
 * @property {string} date "YYYY-MM-DD"
 * @property {string} startTime "HH:mm"
 * @property {string} endTime "HH:mm"
 * @property {string} title
 * @property {number} persons
 * @property {string} additionalRequest
 * @property {'Pending' | 'Accepted' | 'Rejected' | 'Cancelled'} status Derived from isApproved / isCancelled
 * @property {string} managerRemarks Filled when the manager rejects
 * @property {string} createdOn ISO timestamp
 * @property {TimelineEntry[]} [timeline]
 */

/**
 * @typedef {Object} TimelineEntry
 * @property {string} id
 * @property {'created' | 'approved' | 'rejected' | 'cancelled' | 'comment' | 'edited'} type
 * @property {string} actor
 * @property {string} message
 * @property {string} at ISO timestamp
 */

export {}
