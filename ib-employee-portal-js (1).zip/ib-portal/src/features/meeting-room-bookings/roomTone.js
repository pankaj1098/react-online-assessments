/**
 * Room colour-coding uses the theme's tone tokens (theme.css), never raw colours.
 * Full class names (not built dynamically) so Tailwind can detect them.
 */
const tones = {
  green: {
    dot: 'bg-tone-green-border',
    event: 'border-l-4 border-tone-green-border bg-tone-green-bg',
  },
  blue: { dot: 'bg-tone-blue-border', event: 'border-l-4 border-tone-blue-border bg-tone-blue-bg' },
  purple: {
    dot: 'bg-tone-purple-border',
    event: 'border-l-4 border-tone-purple-border bg-tone-purple-bg',
  },
  orange: {
    dot: 'bg-tone-orange-border',
    event: 'border-l-4 border-tone-orange-border bg-tone-orange-bg',
  },
  teal: { dot: 'bg-tone-teal-border', event: 'border-l-4 border-tone-teal-border bg-tone-teal-bg' },
  rose: { dot: 'bg-tone-rose-border', event: 'border-l-4 border-tone-rose-border bg-tone-rose-bg' },
  amber: {
    dot: 'bg-tone-amber-border',
    event: 'border-l-4 border-tone-amber-border bg-tone-amber-bg',
  },
}

export const toneOrder = Object.keys(tones)

export function toneStyles(tone) {
  return tones[tone] ?? tones.green
}
