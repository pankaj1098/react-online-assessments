const pad = (value) => String(value).padStart(2, '0')

export const weekdayLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
export const weekdayNames = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday',
]

/** Local calendar date as "YYYY-MM-DD" (not UTC). */
export function toDateString(date) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
}

export function todayLocal() {
  return toDateString(new Date())
}

export function toLocalDate(dateString) {
  return new Date(`${dateString}T00:00`)
}

export function addDays(dateString, days) {
  const date = toLocalDate(dateString)
  date.setDate(date.getDate() + days)
  return toDateString(date)
}

export function shiftMonth(dateString, months) {
  const date = toLocalDate(dateString)
  date.setDate(1)
  date.setMonth(date.getMonth() + months)
  return toDateString(date)
}

export function startOfMonth(dateString) {
  return `${dateString.slice(0, 7)}-01`
}

export function endOfMonth(dateString) {
  const date = toLocalDate(dateString)
  return toDateString(new Date(date.getFullYear(), date.getMonth() + 1, 0))
}

/** Monday = 0 ... Sunday = 6. */
export function weekdayIndex(dateString) {
  return (toLocalDate(dateString).getDay() + 6) % 7
}

export function startOfWeek(dateString) {
  return addDays(dateString, -weekdayIndex(dateString))
}

/** Number of days from start to end, both included. */
export function daysBetween(start, end) {
  return Math.round((toLocalDate(end) - toLocalDate(start)) / 86_400_000) + 1
}

export function eachDay(start, end) {
  return Array.from({ length: daysBetween(start, end) }, (_, index) => addDays(start, index))
}

/** The full Monday-to-Sunday grid that covers a month. */
export function monthGridRange(dateString) {
  return {
    from: startOfWeek(startOfMonth(dateString)),
    to: addDays(startOfWeek(endOfMonth(dateString)), 6),
  }
}

export function dateParts(dateString) {
  const date = toLocalDate(dateString)
  return { day: date.getDate(), month: date.toLocaleString('en-GB', { month: 'short' }) }
}

/** "14:30" -> "2:30 PM". */
export function formatTime(value) {
  const [hours, minutes] = value.split(':').map(Number)
  return `${hours % 12 || 12}:${pad(minutes)} ${hours < 12 ? 'AM' : 'PM'}`
}

export function formatTimeRange(start, end) {
  return `${formatTime(start)} - ${formatTime(end)}`
}

export function toMinutes(value) {
  const [hours, minutes] = value.split(':').map(Number)
  return hours * 60 + minutes
}

export const formatHourShort = (hour) => `${hour % 12 || 12}${hour < 12 ? 'a' : 'p'}`

export const formatHourLong = (hour) => `${hour % 12 || 12} ${hour < 12 ? 'am' : 'pm'}`

export function formatDateLong(dateString) {
  return toLocalDate(dateString).toLocaleDateString('en-GB', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  })
}

export function formatDayMonth(dateString) {
  return toLocalDate(dateString).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })
}

export function formatMonthYear(dateString) {
  return toLocalDate(dateString).toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })
}

/** "Mon 23" - short column header for the week view. */
export function formatWeekdayDay(dateString) {
  return `${weekdayLabels[weekdayIndex(dateString)]} ${Number(dateString.slice(8))}`
}
