import { zodResolver } from '@hookform/resolvers/zod'
import {
  ArrowLeft,
  ArrowRight,
  CalendarDays,
  Check,
  Clock,
  MessageSquare,
  Pencil,
  Users,
} from 'lucide-react'
import { useState } from 'react'
import { useForm, useWatch } from 'react-hook-form'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input, Textarea } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useDebouncedValue } from '@/hooks/useDebouncedValue'
import { getErrorMessage } from '@/lib/api-error'
import { bookingFormSchema, MAX_BOOKING_DAYS, REQUEST_MAX_LENGTH } from '../api/meetingRoom.schemas'
import { formatDate } from '@/lib/date'
import { cn } from '@/lib/utils'
import { daysBetween, formatTimeRange, todayLocal } from '../format'
import { useAvailability, useCalendar } from '../hooks'
import { AvailabilityNotice } from './AvailabilityNotice'
import { RoomPicker } from './RoomPicker'
import { RoomSchedule } from './RoomSchedule'

function Section({ step, title, description, children }) {
  return (
    <section
      aria-labelledby={`step-${step}`}
      className="rounded-2xl border border-border bg-card p-5 shadow-sm sm:p-6"
    >
      <div className="mb-5 flex items-start gap-3.5">
        <span
          aria-hidden="true"
          className="grid size-8 shrink-0 place-items-center rounded-full bg-primary text-sm font-bold text-primary-foreground"
        >
          {step}
        </span>
        <div>
          <h2 id={`step-${step}`} className="text-lg font-bold tracking-tight">
            {title}
          </h2>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </div>
      {children}
    </section>
  )
}

function Field({ id, label, required = true, error, hint, children }) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>
        {label}
        {required && <span className="text-destructive"> *</span>}
      </Label>
      {children}
      {error && (
        <p id={`${id}-error`} className="text-sm text-destructive">
          {error}
        </p>
      )}
      {hint}
    </div>
  )
}

const approvalSteps = [
  'You submit the request.',
  'The Meeting Room Manager reviews it.',
  'You get an email and a notification with the decision.',
]

const steps = [
  { id: 1, label: 'Room', fields: ['roomId'] },
  { id: 2, label: 'Date and time', fields: ['startDate', 'endDate', 'startTime', 'endTime'] },
  { id: 3, label: 'Meeting details', fields: ['title', 'persons', 'additionalRequest'] },
]

function Stepper({ current }) {
  return (
    <nav aria-label="Booking steps">
      <ol className="flex flex-wrap gap-2 sm:gap-3">
        {steps.map(({ id, label }) => {
          const done = id < current
          const active = id === current
          return (
            <li
              key={id}
              aria-current={active ? 'step' : undefined}
              className={cn(
                'flex items-center gap-2.5 rounded-full border px-3.5 py-2 text-sm font-semibold',
                active && 'border-primary bg-primary-soft text-primary',
                done && 'border-border bg-card text-foreground',
                !active && !done && 'border-border bg-card text-muted-foreground',
              )}
            >
              <span
                aria-hidden="true"
                className={cn(
                  'grid size-6 place-items-center rounded-full text-xs font-bold',
                  active || done
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground',
                )}
              >
                {done ? <Check className="size-3.5" /> : id}
              </span>
              <span>
                <span className="sr-only">Step {id}: </span>
                {label}
                {done && <span className="sr-only"> (completed)</span>}
              </span>
            </li>
          )
        })}
      </ol>
    </nav>
  )
}

/**
 * Create and edit share this three-step form:
 *   1. choose the room (its bookings for the day are shown on the right),
 *   2. choose the date and time (checked against existing bookings),
 *   3. enter the meeting details and submit.
 * In edit mode there is a single date (no end date).
 * `onSubmit` receives values with `persons` as a number and `endDate` filled in.
 */
export function BookingForm({
  mode,
  rooms,
  roomsPending,
  defaultValues,
  excludeId,
  isSubmitting,
  submitError,
  onSubmit,
  onCancel,
}) {
  const isEdit = mode === 'edit'
  const [step, setStep] = useState(1)
  const [viewDate, setViewDate] = useState(defaultValues.startDate || todayLocal())
  const {
    register,
    handleSubmit,
    control,
    setError,
    setValue,
    trigger,
    formState: { errors },
  } = useForm({ resolver: zodResolver(bookingFormSchema), defaultValues })
  const [roomId, startDate, endDate, startTime, endTime, additionalRequest] = useWatch({
    control,
    name: ['roomId', 'startDate', 'endDate', 'startTime', 'endTime', 'additionalRequest'],
  })
  const room = rooms.find((item) => item.id === roomId)
  const effectiveEnd = isEdit ? startDate : endDate || startDate

  // Check availability once everything needed is filled in and valid.
  const ready = Boolean(
    roomId &&
    startDate &&
    startTime &&
    endTime &&
    startDate >= todayLocal() &&
    effectiveEnd >= startDate &&
    daysBetween(startDate, effectiveEnd) <= MAX_BOOKING_DAYS &&
    endTime > startTime,
  )
  const slot = ready ? [roomId, startDate, effectiveEnd, startTime, endTime].join('|') : ''
  const debouncedSlot = useDebouncedValue(slot)
  const [slotRoom, slotStart, slotEnd, slotFrom, slotTo] = debouncedSlot.split('|')
  const availability = useAvailability(
    {
      roomId: slotRoom,
      startDate: slotStart,
      endDate: slotEnd,
      startTime: slotFrom,
      endTime: slotTo,
      excludeId,
    },
    debouncedSlot !== '',
  )
  let availabilityState = 'idle'
  if (slot) {
    if (slot !== debouncedSlot || availability.isFetching) availabilityState = 'checking'
    else if (availability.isError) availabilityState = 'error'
    else if (availability.data?.available === false) availabilityState = 'unavailable'
    else if (availability.data?.available) availabilityState = 'available'
    else availabilityState = 'checking'
  }

  // Step 1 browses any day; later steps follow the chosen start date.
  const scheduleDate = step === 1 ? viewDate : startDate
  const schedule = useCalendar(
    { from: scheduleDate, to: scheduleDate, roomId },
    Boolean(roomId && scheduleDate),
  )

  const invalid = (name) => (errors[name] ? true : undefined)
  const describedBy = (name) => (errors[name] ? `${name}-error` : undefined)
  const current = steps[step - 1]

  async function goNext() {
    const valid = await trigger(current.fields)
    if (!valid) return
    if (step === 1 && !startDate) setValue('startDate', viewDate)
    if (step === 2 && availabilityState === 'unavailable') return
    setStep(step + 1)
  }

  function submit(values) {
    const persons = Number(values.persons)
    if (room && persons > room.capacity) {
      setError('persons', { message: `${room.name} seats up to ${room.capacity} people.` })
      return
    }
    onSubmit({
      ...values,
      persons,
      endDate: isEdit ? values.startDate : values.endDate || values.startDate,
    })
  }

  function onFormSubmit(event) {
    if (step < steps.length) {
      event.preventDefault()
      void goNext()
      return
    }
    void handleSubmit(submit)(event)
  }

  const dateSummary =
    startDate &&
    (effectiveEnd && effectiveEnd !== startDate
      ? `${formatDate(`${startDate}T00:00`)} to ${formatDate(`${effectiveEnd}T00:00`)}`
      : formatDate(`${startDate}T00:00`))

  return (
    <form
      onSubmit={onFormSubmit}
      noValidate
      className="grid items-start gap-5 xl:grid-cols-[minmax(0,1fr)_22rem]"
    >
      <div className="grid gap-5">
        <Stepper current={step} />

        {step === 1 && (
          <Section
            step={1}
            title="Choose a room"
            description="Pick a room. Its bookings for the day appear on the right, so you can see when it is taken and by whom."
          >
            <RoomPicker
              rooms={rooms}
              isPending={roomsPending}
              errorMessage={errors.roomId?.message}
              register={register}
            />
          </Section>
        )}

        {step === 2 && (
          <Section
            step={2}
            title="Date and time"
            description={
              isEdit
                ? 'Change the day or the time slot.'
                : 'Leave the end date blank for one day. A multi-day request creates one request per day.'
            }
          >
            <p className="mb-4 rounded-xl bg-muted px-3.5 py-2.5 text-sm">
              Room: <b>{room?.name}</b> ({room?.location})
            </p>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field id="startDate" label="Start date" error={errors.startDate?.message}>
                <Input
                  id="startDate"
                  type="date"
                  min={todayLocal()}
                  icon={<CalendarDays />}
                  aria-invalid={invalid('startDate')}
                  aria-describedby={describedBy('startDate')}
                  {...register('startDate')}
                />
              </Field>
              {!isEdit && (
                <Field
                  id="endDate"
                  label="End date"
                  required={false}
                  error={errors.endDate?.message}
                >
                  <Input
                    id="endDate"
                    type="date"
                    min={startDate || todayLocal()}
                    icon={<CalendarDays />}
                    aria-invalid={invalid('endDate')}
                    aria-describedby={describedBy('endDate')}
                    {...register('endDate')}
                  />
                </Field>
              )}
              <Field id="startTime" label="Start time" error={errors.startTime?.message}>
                <Input
                  id="startTime"
                  type="time"
                  icon={<Clock />}
                  aria-invalid={invalid('startTime')}
                  aria-describedby={describedBy('startTime')}
                  {...register('startTime')}
                />
              </Field>
              <Field id="endTime" label="End time" error={errors.endTime?.message}>
                <Input
                  id="endTime"
                  type="time"
                  icon={<Clock />}
                  aria-invalid={invalid('endTime')}
                  aria-describedby={describedBy('endTime')}
                  {...register('endTime')}
                />
              </Field>
            </div>
            <div className="mt-4">
              <AvailabilityNotice state={availabilityState} message={availability.data?.message} />
            </div>
          </Section>
        )}

        {step === 3 && (
          <Section
            step={3}
            title="Meeting details"
            description="Tell us what the meeting is about, then submit your request."
          >
            <div className="grid gap-4">
              <Field id="title" label="Meeting title" error={errors.title?.message}>
                <Input
                  id="title"
                  icon={<Pencil />}
                  placeholder="e.g. Weekly team sync"
                  aria-invalid={invalid('title')}
                  aria-describedby={describedBy('title')}
                  {...register('title')}
                />
              </Field>
              <Field
                id="persons"
                label="Number of persons"
                error={errors.persons?.message}
                hint={
                  room && (
                    <small className="block text-muted-foreground">
                      {room.name} seats up to {room.capacity}.
                    </small>
                  )
                }
              >
                <Input
                  id="persons"
                  inputMode="numeric"
                  icon={<Users />}
                  placeholder="How many people will attend?"
                  aria-invalid={invalid('persons')}
                  aria-describedby={describedBy('persons')}
                  {...register('persons')}
                />
              </Field>
              <Field
                id="additionalRequest"
                label="Additional request"
                required={false}
                error={errors.additionalRequest?.message}
                hint={
                  <small className="block text-muted-foreground">
                    {REQUEST_MAX_LENGTH - (additionalRequest ?? '').length} characters remaining
                  </small>
                }
              >
                <Textarea
                  id="additionalRequest"
                  icon={<MessageSquare />}
                  maxLength={REQUEST_MAX_LENGTH}
                  placeholder="Projector, refreshments, seating... (optional)"
                  className="min-h-24"
                  aria-invalid={invalid('additionalRequest')}
                  aria-describedby={describedBy('additionalRequest')}
                  {...register('additionalRequest')}
                />
              </Field>
            </div>
          </Section>
        )}

        {step === 3 && submitError != null && (
          <p role="alert" className="rounded-lg bg-danger-soft px-3 py-2 text-sm text-danger">
            {getErrorMessage(submitError)}
          </p>
        )}

        <div className="flex flex-wrap justify-between gap-3">
          <Button
            type="button"
            variant="outline"
            className="min-w-28"
            onClick={step === 1 ? onCancel : () => setStep(step - 1)}
          >
            {step === 1 ? (
              'Cancel'
            ) : (
              <>
                <ArrowLeft aria-hidden="true" /> Back
              </>
            )}
          </Button>
          {step < steps.length ? (
            <Button
              type="button"
              className="min-w-36"
              onClick={() => void goNext()}
              disabled={step === 2 && availabilityState === 'unavailable'}
            >
              Next <ArrowRight aria-hidden="true" />
            </Button>
          ) : (
            <Button type="submit" disabled={isSubmitting} className="min-w-44">
              {isSubmitting ? 'Saving...' : isEdit ? 'Save Changes' : 'Submit Request'}
              {!isSubmitting && <ArrowRight aria-hidden="true" />}
            </Button>
          )}
        </div>
      </div>

      <aside className="grid gap-5 xl:sticky xl:top-24">
        <RoomSchedule
          room={room}
          date={scheduleDate}
          query={schedule}
          onDateChange={step === 1 ? setViewDate : undefined}
          highlight={step >= 2 ? { startTime, endTime } : undefined}
        />
        {step === 3 && (
          <Card className="p-5">
            <h2 className="mb-3 text-lg font-bold tracking-tight">Your booking</h2>
            <dl className="grid gap-2 text-sm">
              <div>
                <dt className="text-muted-foreground">Room</dt>
                <dd className="font-semibold">
                  {room?.name} ({room?.location})
                </dd>
              </div>
              <div>
                <dt className="text-muted-foreground">Date</dt>
                <dd className="font-semibold">{dateSummary}</dd>
              </div>
              <div>
                <dt className="text-muted-foreground">Time</dt>
                <dd className="font-semibold">{formatTimeRange(startTime, endTime)}</dd>
              </div>
            </dl>
          </Card>
        )}
        <Card className="p-5">
          <h2 className="mb-3 text-lg font-bold tracking-tight">What happens next</h2>
          <ol className="grid gap-3 text-sm">
            {approvalSteps.map((text, index) => (
              <li key={text} className="flex items-start gap-3">
                <span
                  aria-hidden="true"
                  className="grid size-6 shrink-0 place-items-center rounded-full bg-primary-soft text-xs font-bold text-primary"
                >
                  {index + 1}
                </span>
                <span>{text}</span>
              </li>
            ))}
          </ol>
        </Card>
      </aside>
    </form>
  )
}
