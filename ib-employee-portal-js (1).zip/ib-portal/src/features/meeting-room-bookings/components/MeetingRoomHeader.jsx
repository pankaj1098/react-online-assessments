import { CalendarDays, ClipboardList, LayoutDashboard, Plus } from 'lucide-react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { cn } from '@/lib/utils'
import { useMyBookings } from '../hooks'
import { MEETING_ROOMS_PATH } from '../types'

const tabs = [
  { to: MEETING_ROOMS_PATH, label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: `${MEETING_ROOMS_PATH}/calendar`, label: 'Calendar', icon: CalendarDays },
  { to: `${MEETING_ROOMS_PATH}/my-bookings`, label: 'My bookings', icon: ClipboardList },
]

/**
 * Header shared by every meeting room page: title (the page's single h1), the "Book a room"
 * button and the section tabs, all in one card.
 */
export function MeetingRoomHeader({ icon, title, description }) {
  const { pathname } = useLocation()
  const booking = pathname.endsWith('/create') || pathname.endsWith('/edit')
  const pending = useMyBookings({ status: 'Pending', page: 1, pageSize: 1 })
  const pendingCount = pending.data?.total ?? 0
  return (
    <Card className="mb-5 overflow-hidden">
      <div className="flex flex-wrap items-center gap-4 px-5 pt-5 sm:gap-5 sm:px-7 sm:pt-6">
        <div
          aria-hidden="true"
          className="grid size-14 shrink-0 place-items-center rounded-2xl bg-primary-soft text-primary [&_svg]:size-7"
        >
          {icon}
        </div>
        <div className="min-w-0 flex-1">
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{title}</h1>
          <p className="mt-1 text-muted-foreground">{description}</p>
        </div>
        {!booking && (
          <Button asChild className="max-sm:w-full">
            <Link to={`${MEETING_ROOMS_PATH}/create`}>
              <Plus aria-hidden="true" /> Book a room
            </Link>
          </Button>
        )}
      </div>
      <nav aria-label="Meeting room sections" className="mt-4 overflow-x-auto px-3 sm:px-5">
        <ul className="flex min-w-max gap-1">
          {tabs.map(({ to, label, icon: Icon, end }) => (
            <li key={to}>
              <NavLink
                to={to}
                end={end}
                className={({ isActive }) =>
                  cn(
                    '-mb-px flex min-h-12 items-center gap-2 border-b-2 px-4 text-sm font-semibold whitespace-nowrap transition-colors',
                    isActive
                      ? 'border-primary text-primary'
                      : 'border-transparent text-muted-foreground hover:text-foreground',
                  )
                }
              >
                <Icon className="size-4" aria-hidden="true" />
                {label}
                {to.endsWith('my-bookings') && pendingCount > 0 && (
                  <span className="rounded-full bg-warning-soft px-2 py-0.5 text-xs font-bold text-warning">
                    {pendingCount} pending
                  </span>
                )}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
      <div className="border-t border-border" />
    </Card>
  )
}
