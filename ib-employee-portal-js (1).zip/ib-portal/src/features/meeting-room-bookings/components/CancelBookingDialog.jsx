import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog'
import { getErrorMessage } from '@/lib/api-error'
import { formatDate } from '@/lib/date'
import { formatTime } from '../format'
import { useCancelBooking } from '../hooks'

function CancelBody({ booking, onClose, onCancelled }) {
  const cancel = useCancelBooking()
  return (
    <>
      <DialogTitle>Cancel this booking?</DialogTitle>
      <DialogDescription className="mt-1">
        {booking.title} in {booking.roomName} on {formatDate(`${booking.date}T00:00`)} at{' '}
        {formatTime(booking.startTime)}.
        {booking.status === 'Accepted' && ' The Meeting Room Manager will be informed.'}
      </DialogDescription>
      {cancel.isError && (
        <p role="alert" className="mt-4 rounded-lg bg-danger-soft px-3 py-2 text-sm text-danger">
          {getErrorMessage(cancel.error)}
        </p>
      )}
      <div className="mt-6 flex justify-end gap-3">
        <Button variant="outline" onClick={onClose}>
          Keep booking
        </Button>
        <Button
          variant="destructive"
          disabled={cancel.isPending}
          onClick={() => cancel.mutate(booking.id, { onSuccess: onCancelled })}
        >
          {cancel.isPending ? 'Cancelling...' : 'Cancel booking'}
        </Button>
      </div>
    </>
  )
}

export function CancelBookingDialog({ booking, onClose, onCancelled }) {
  return (
    <Dialog open={booking !== null} onOpenChange={(open) => !open && onClose()}>
      <DialogContent>
        {booking && (
          <CancelBody
            key={booking.id}
            booking={booking}
            onClose={onClose}
            onCancelled={onCancelled}
          />
        )}
      </DialogContent>
    </Dialog>
  )
}
