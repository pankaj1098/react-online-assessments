import { CalendarClock } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { getErrorMessage } from '@/lib/api-error'
import { formatDate } from '@/lib/date'
import { cn } from '@/lib/utils'
import { formatTimeRange, toMinutes } from '../format'

/**
 * Everything already booked in the chosen room on the chosen day, with who booked it.
 * Pass `onDateChange` to let the user browse other days (step 1).
 * `highlight` is an optional { startTime, endTime } slot the user is considering.
 */
export function RoomSchedule({ room, date, query, onDateChange, highlight }) {
  const day = date ? formatDate(`${date}T00:00`) : ''
  let body
  if (!room || !date) {
    body = (
      <p className="text-sm text-muted-foreground">
        Select a room to see who has booked it and at what time.
      </p>
    )
  } else if (query.isPending) {
    body = <Skeleton className="h-16" />
  } else if (query.isError) {
    body = <p className="text-sm text-destructive">{getErrorMessage(query.error)}</p>
  } else if (query.data.length === 0) {
    body = (
      <p className="rounded-xl bg-success-soft px-3.5 py-2.5 text-sm text-success">
        {room.name} is free all day on {day}.
      </p>
    )
  } else {
    body = (
      <>
        <p className="mb-3 text-sm text-muted-foreground">
          {room.name} on {day}:
        </p>
        <ul className="grid gap-2">
          {query.data.map((event) => {
            const clashes =
              highlight?.startTime &&
              highlight?.endTime &&
              toMinutes(highlight.startTime) < toMinutes(event.endTime) &&
              toMinutes(highlight.endTime) > toMinutes(event.startTime)
            return (
              <li
                key={event.id}
                className={cn(
                  'rounded-xl px-3.5 py-2.5 text-sm',
                  clashes ? 'bg-danger-soft text-danger' : 'bg-muted',
                )}
              >
                <b className="block font-semibold">
                  {formatTimeRange(event.startTime, event.endTime)}
                </b>
                <span className={clashes ? undefined : 'text-muted-foreground'}>
                  {event.isMine ? 'Booked by you' : `Booked by ${event.requesterName}`}
                  {event.department && !event.isMine ? ` · ${event.department}` : ''}
                </span>
                {event.title && (
                  <span className={cn('block', !clashes && 'text-muted-foreground')}>
                    {event.title}
                  </span>
                )}
              </li>
            )
          })}
        </ul>
      </>
    )
  }
  return (
    <Card className="p-5">
      <h2 className="mb-3 flex items-center gap-2.5 text-lg font-bold tracking-tight">
        <CalendarClock className="size-5 text-primary" aria-hidden="true" /> Room schedule
      </h2>
      {onDateChange && room && (
        <div className="mb-4 space-y-1.5">
          <Label htmlFor="viewDate">Day to view</Label>
          <Input
            id="viewDate"
            type="date"
            value={date}
            onChange={(event) => onDateChange(event.target.value)}
          />
        </div>
      )}
      {body}
    </Card>
  )
}
