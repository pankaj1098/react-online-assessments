import { CalendarX, CircleCheck, CircleX, Clock } from 'lucide-react'
import { Badge } from '@/components/ui/badge'

const config = {
  Pending: { variant: 'warning', icon: Clock },
  Accepted: { variant: 'success', icon: CircleCheck },
  Rejected: { variant: 'danger', icon: CircleX },
  Cancelled: { variant: 'neutral', icon: CalendarX },
}

export function BookingStatusBadge({ status }) {
  const { variant, icon: Icon } = config[status]
  return (
    <Badge variant={variant}>
      <Icon aria-hidden="true" />
      {status}
    </Badge>
  )
}
