import { CalendarX, CircleCheck, CirclePlus, CircleX, MessageSquare, Pencil } from 'lucide-react'
import { formatDateTime } from '@/lib/date'
import { cn } from '@/lib/utils'

const icons = {
  created: CirclePlus,
  approved: CircleCheck,
  rejected: CircleX,
  cancelled: CalendarX,
  comment: MessageSquare,
  edited: Pencil,
}

const tones = {
  approved: 'bg-success-soft text-success',
  rejected: 'bg-danger-soft text-danger',
  cancelled: 'bg-danger-soft text-danger',
}

/** Oldest first, like a history of what happened to the request. */
export function BookingTimeline({ entries }) {
  return (
    <ol className="relative grid gap-5 before:absolute before:top-2 before:bottom-2 before:left-4 before:w-px before:bg-border">
      {entries.map((item) => {
        const Icon = icons[item.type] ?? CirclePlus
        return (
          <li key={item.id} className="relative flex gap-3.5">
            <span
              className={cn(
                'relative z-10 grid size-8 shrink-0 place-items-center rounded-full',
                tones[item.type] ?? 'bg-primary-soft text-primary',
              )}
            >
              <Icon className="size-4" aria-hidden="true" />
            </span>
            <div className="min-w-0 pt-0.5">
              <p className="text-sm font-semibold break-words whitespace-pre-wrap">
                {item.message}
              </p>
              <p className="mt-0.5 text-xs text-muted-foreground">
                {item.actor} &middot; {formatDateTime(item.at)}
              </p>
            </div>
          </li>
        )
      })}
    </ol>
  )
}
