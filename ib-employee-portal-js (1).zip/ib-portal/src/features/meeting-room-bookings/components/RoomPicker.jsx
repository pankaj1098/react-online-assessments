import { Check, Users } from 'lucide-react'
import { Skeleton } from '@/components/ui/skeleton'
import { cn } from '@/lib/utils'
import { toneStyles } from '../roomTone'

/** Radio cards grouped by building. Colour dots come from the theme's tone tokens. */
export function RoomPicker({ rooms, isPending, errorMessage, register }) {
  const locations = [...new Set(rooms.map((item) => item.location))]
  return (
    <fieldset aria-describedby={errorMessage ? 'roomId-error' : undefined}>
      <legend className="sr-only">Room</legend>
      {isPending && (
        <div className="grid gap-2.5 sm:grid-cols-2 xl:grid-cols-3">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-20 rounded-xl" />
          ))}
        </div>
      )}
      {locations.map((location) => (
        <div key={location} className="mb-5 last:mb-0">
          <h3 className="mb-2 text-xs font-bold tracking-wide text-muted-foreground uppercase">
            {location}
          </h3>
          <div className="grid gap-2.5 sm:grid-cols-2 xl:grid-cols-3">
            {rooms
              .filter((item) => item.location === location)
              .map((item) => (
                <label
                  key={item.id}
                  className="group flex cursor-pointer gap-3 rounded-xl border border-input bg-card p-3 transition-colors hover:bg-secondary has-[:checked]:border-primary has-[:checked]:bg-primary-soft has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-ring"
                >
                  <input type="radio" value={item.id} className="sr-only" {...register('roomId')} />
                  <span
                    aria-hidden="true"
                    className={cn('mt-1.5 size-3 shrink-0 rounded-full', toneStyles(item.tone).dot)}
                  />
                  <span className="min-w-0 flex-1">
                    <b className="block text-sm font-semibold">{item.name}</b>
                    <span className="mt-0.5 flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Users className="size-3.5" aria-hidden="true" />
                      Seats {item.capacity}
                    </span>
                    <span className="mt-1 block text-xs text-muted-foreground">
                      {item.facilities.join(' · ')}
                    </span>
                  </span>
                  <Check
                    className="size-4 shrink-0 text-primary opacity-0 group-has-[:checked]:opacity-100"
                    aria-hidden="true"
                  />
                </label>
              ))}
          </div>
        </div>
      ))}
      {errorMessage && (
        <p id="roomId-error" className="mt-3 text-sm text-destructive">
          {errorMessage}
        </p>
      )}
    </fieldset>
  )
}
