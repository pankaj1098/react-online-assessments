import { EmptyState } from '@/components/common/EmptyState'
import { cn } from '@/lib/utils'
import { bookingStatuses } from '../types'

/**
 * Vertical bars. `data`: [{ label, title?, value }]. The tallest bars are drawn darker
 * ("peak"). Drawn with theme colours, no chart library.
 */
export function ColumnChart({ data, label }) {
  const max = Math.max(0, ...data.map((item) => item.value))
  const summary = data.map((item) => `${item.title ?? item.label}: ${item.value}`).join(', ')
  return (
    <div>
      <div
        role="img"
        aria-label={`${label}. ${summary}`}
        className="flex h-56 items-stretch gap-1.5 border-b border-border sm:gap-3"
      >
        {data.map((item) => {
          const peak = max > 0 && item.value === max
          return (
            <div key={item.label} className="flex min-w-0 flex-1 flex-col justify-end">
              <span className="mb-1 text-center text-xs font-semibold text-foreground">
                {item.value}
              </span>
              <div
                className={cn(
                  'w-full rounded-t-md',
                  item.value === 0 ? 'bg-muted' : peak ? 'bg-sidebar' : 'bg-primary/65',
                )}
                style={{
                  height: item.value === 0 ? '0.25rem' : `${(item.value / max) * 82}%`,
                }}
              />
            </div>
          )
        })}
      </div>
      <div aria-hidden="true" className="mt-2 flex gap-1.5 sm:gap-3">
        {data.map((item) => (
          <span
            key={item.label}
            className="min-w-0 flex-1 text-center text-xs text-muted-foreground"
          >
            {item.label}
          </span>
        ))}
      </div>
      <p aria-hidden="true" className="mt-4 flex items-center gap-4 text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <span className="size-2.5 rounded-sm bg-sidebar" /> Peak
        </span>
        <span className="flex items-center gap-1.5">
          <span className="size-2.5 rounded-sm bg-primary/65" /> Other
        </span>
      </p>
    </div>
  )
}

const segmentColours = {
  Accepted: 'bg-success',
  Pending: 'bg-tone-amber-border',
  Rejected: 'bg-danger',
  Cancelled: 'bg-muted-foreground',
}

const segmentOrder = ['Accepted', 'Pending', 'Rejected', 'Cancelled']

/** Total line plus one segmented bar. `counts`: { Pending, Accepted, Rejected, Cancelled }. */
export function StatusSummary({ counts }) {
  const total = bookingStatuses.reduce((sum, status) => sum + (counts[status] ?? 0), 0)
  const parts = segmentOrder
    .filter((status) => counts[status] > 0)
    .map((status) => `${counts[status]} ${status.toLowerCase()}`)
  if (total === 0) return <EmptyState>No booking requests in this period.</EmptyState>
  return (
    <div>
      <div className="mb-3 flex flex-wrap items-baseline justify-between gap-2 text-sm">
        <b>
          {total} {total === 1 ? 'request' : 'requests'} in this period
        </b>
        <span className="text-muted-foreground">{parts.join(' · ')}</span>
      </div>
      <div
        role="img"
        aria-label={`Requests by status: ${parts.join(', ')}`}
        className="flex h-3 gap-1 overflow-hidden rounded-full"
      >
        {segmentOrder.map(
          (status) =>
            counts[status] > 0 && (
              <span
                key={status}
                className={cn('rounded-full', segmentColours[status])}
                style={{ flex: `${counts[status]} 1 0%` }}
              />
            ),
        )}
      </div>
    </div>
  )
}
