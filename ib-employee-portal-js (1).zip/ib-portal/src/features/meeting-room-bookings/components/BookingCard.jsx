import { CalendarX, Clock, DoorOpen, Eye, Pencil, Users } from 'lucide-react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { dateParts, formatTimeRange } from '../format'
import { canCancelBooking, canEditBooking } from '../status'
import { MEETING_ROOMS_PATH } from '../types'
import { BookingStatusBadge } from './BookingStatusBadge'

/** One booking as a list item. Pass `onCancel` to show the cancel action. */
export function BookingCard({ booking, onCancel }) {
  const { day, month } = dateParts(booking.date)
  const path = `${MEETING_ROOMS_PATH}/${encodeURIComponent(booking.id)}`
  return (
    <li className="flex flex-wrap items-center gap-4 rounded-2xl border border-border bg-card p-4 shadow-sm transition hover:shadow-md sm:flex-nowrap">
      <div
        aria-hidden="true"
        className="grid size-16 shrink-0 place-content-center rounded-2xl bg-primary-soft text-center text-primary"
      >
        <span className="text-2xl leading-none font-extrabold">{day}</span>
        <span className="mt-1 text-xs font-semibold uppercase">{month}</span>
      </div>
      <div className="min-w-0 flex-1">
        <h3 className="truncate font-semibold">
          <Link to={path} className="hover:underline">
            {booking.title}
          </Link>
        </h3>
        <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
          <DoorOpen className="size-4" aria-hidden="true" />
          {booking.roomName}
        </p>
        <p className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
          <span className="flex items-center gap-1.5">
            <Clock className="size-4 text-primary" aria-hidden="true" />
            {formatTimeRange(booking.startTime, booking.endTime)}
          </span>
          <span className="flex items-center gap-1.5">
            <Users className="size-4 text-primary" aria-hidden="true" />
            {booking.persons} persons
          </span>
        </p>
      </div>
      <div className="flex flex-wrap items-center gap-3 max-sm:w-full max-sm:justify-between">
        <BookingStatusBadge status={booking.status} />
        <div className="flex gap-2">
          <Button asChild variant="outline" size="icon" title="View booking">
            <Link to={path} aria-label={`View booking ${booking.title}`}>
              <Eye aria-hidden="true" />
            </Link>
          </Button>
          {canEditBooking(booking) && (
            <Button asChild variant="outline" size="icon" title="Edit booking">
              <Link to={`${path}/edit`} aria-label={`Edit booking ${booking.title}`}>
                <Pencil aria-hidden="true" />
              </Link>
            </Button>
          )}
          {onCancel && canCancelBooking(booking) && (
            <Button
              variant="outline"
              size="icon"
              title="Cancel booking"
              aria-label={`Cancel booking ${booking.title}`}
              onClick={() => onCancel(booking)}
            >
              <CalendarX aria-hidden="true" />
            </Button>
          )}
        </div>
      </div>
    </li>
  )
}
