import { CircleAlert, CircleCheck, Info, LoaderCircle } from 'lucide-react'
import { cn } from '@/lib/utils'

const states = {
  idle: {
    icon: Info,
    className: 'bg-muted text-muted-foreground',
    text: 'Pick a room, dates and times to check availability.',
  },
  checking: {
    icon: LoaderCircle,
    className: 'bg-muted text-muted-foreground',
    text: 'Checking availability...',
    spin: true,
  },
  available: {
    icon: CircleCheck,
    className: 'bg-success-soft text-success',
    text: 'This slot is free. Your request will go to the Meeting Room Manager for approval.',
  },
  unavailable: { icon: CircleAlert, className: 'bg-danger-soft text-danger' },
  error: {
    icon: CircleAlert,
    className: 'bg-warning-soft text-warning',
    text: 'Could not check availability right now. You can still submit; it is checked again on submit.',
  },
}

export function AvailabilityNotice({ state, message }) {
  const { icon: Icon, className, text, spin } = states[state]
  return (
    <p
      role="status"
      className={cn('flex items-start gap-2.5 rounded-xl px-3.5 py-2.5 text-sm', className)}
    >
      <Icon className={cn('mt-0.5 size-4 shrink-0', spin && 'animate-spin')} aria-hidden="true" />
      <span>{state === 'unavailable' ? message : text}</span>
    </p>
  )
}
