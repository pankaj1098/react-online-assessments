import { EmptyState } from '@/components/common/EmptyState'
import { cn } from '@/lib/utils'
import {
  addDays,
  eachDay,
  formatDateLong,
  formatTime,
  formatTimeRange,
  formatWeekdayDay,
  monthGridRange,
  startOfWeek,
  todayLocal,
  weekdayLabels,
} from '../format'
import { toneStyles } from '../roomTone'

function groupByDate(events) {
  const groups = new Map()
  for (const event of events) {
    const list = groups.get(event.date) ?? []
    list.push(event)
    groups.set(event.date, list)
  }
  for (const list of groups.values()) list.sort((a, b) => a.startTime.localeCompare(b.startTime))
  return groups
}

function EventRow({ event, toneOf }) {
  return (
    <li className={cn('rounded-lg px-3 py-2.5 text-sm', toneStyles(toneOf(event.roomId)).event)}>
      <p className="font-semibold">{formatTimeRange(event.startTime, event.endTime)}</p>
      <p className="mt-0.5 break-words">{event.title}</p>
      <p className="text-muted-foreground">
        {event.roomName} &middot; {event.requesterName}
        {event.department ? `, ${event.department}` : ''}
      </p>
    </li>
  )
}

function DayColumn({ date, events, toneOf, header = 'long' }) {
  const isToday = date === todayLocal()
  return (
    <section
      aria-label={formatDateLong(date)}
      className="min-w-0 rounded-xl border border-border bg-card"
    >
      {header !== 'none' && (
        <h3
          className={cn(
            'rounded-t-xl border-b border-border px-3 py-2 text-sm font-bold',
            isToday
              ? 'bg-primary text-primary-foreground'
              : 'bg-primary-soft text-primary-soft-foreground',
          )}
        >
          {header === 'short' ? formatWeekdayDay(date) : formatDateLong(date)}
        </h3>
      )}
      {events.length === 0 ? (
        <p className="px-3 py-4 text-sm text-muted-foreground">No bookings.</p>
      ) : (
        <ul className="grid gap-2 p-2.5">
          {events.map((event) => (
            <EventRow key={event.id} event={event} toneOf={toneOf} />
          ))}
        </ul>
      )}
    </section>
  )
}

function MonthView({ anchor, events, toneOf, onPickDay }) {
  const { from, to } = monthGridRange(anchor)
  const byDate = groupByDate(events)
  const month = anchor.slice(0, 7)
  const today = todayLocal()
  return (
    <div className="overflow-x-auto">
      <div className="grid min-w-[42rem] grid-cols-7 gap-px overflow-hidden rounded-xl border border-border bg-border">
        {weekdayLabels.map((label) => (
          <div
            key={label}
            className="bg-muted px-2 py-2 text-center text-xs font-bold text-muted-foreground"
          >
            {label}
          </div>
        ))}
        {eachDay(from, to).map((date) => {
          const dayEvents = byDate.get(date) ?? []
          const inMonth = date.slice(0, 7) === month
          return (
            <div key={date} className={cn('min-h-28 bg-card p-1.5', !inMonth && 'bg-muted/50')}>
              <button
                type="button"
                aria-label={`Open ${formatDateLong(date)}`}
                onClick={() => onPickDay(date)}
                className={cn(
                  'mb-1 grid size-7 place-items-center rounded-full text-sm font-semibold hover:bg-secondary',
                  !inMonth && 'text-muted-foreground',
                  date === today && 'bg-primary text-primary-foreground hover:bg-primary-hover',
                )}
              >
                {Number(date.slice(8))}
              </button>
              <ul className="grid gap-1">
                {dayEvents.slice(0, 3).map((event) => (
                  <li
                    key={event.id}
                    title={`${event.title} - ${event.roomName}`}
                    className={cn(
                      'truncate rounded px-1.5 py-1 text-xs',
                      toneStyles(toneOf(event.roomId)).event,
                    )}
                  >
                    <b>{formatTime(event.startTime)}</b> {event.roomName}
                  </li>
                ))}
              </ul>
              {dayEvents.length > 3 && (
                <button
                  type="button"
                  onClick={() => onPickDay(date)}
                  className="mt-1 px-1 text-xs font-semibold text-primary hover:underline"
                >
                  +{dayEvents.length - 3} more
                </button>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

/** Month, week, day and list views over the same list of events. */
export function BookingsCalendar({ view, anchor, events, toneOf, onPickDay }) {
  const byDate = groupByDate(events)
  if (view === 'month') {
    return <MonthView anchor={anchor} events={events} toneOf={toneOf} onPickDay={onPickDay} />
  }
  if (view === 'week') {
    const first = startOfWeek(anchor)
    return (
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-7">
        {Array.from({ length: 7 }, (_, index) => addDays(first, index)).map((date) => (
          <DayColumn
            key={date}
            date={date}
            events={byDate.get(date) ?? []}
            toneOf={toneOf}
            header="short"
          />
        ))}
      </div>
    )
  }
  if (view === 'day') {
    return (
      <DayColumn date={anchor} events={byDate.get(anchor) ?? []} toneOf={toneOf} header="none" />
    )
  }
  const dates = [...byDate.keys()].sort()
  if (dates.length === 0) return <EmptyState>No approved bookings in this period.</EmptyState>
  return (
    <div className="grid gap-3">
      {dates.map((date) => (
        <DayColumn key={date} date={date} events={byDate.get(date)} toneOf={toneOf} />
      ))}
    </div>
  )
}
