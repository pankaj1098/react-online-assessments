import { todayLocal } from './format'

/** isCancelled wins; then isApproved: true = Accepted, false = Rejected, null = Pending. */
export function getBookingStatus({ isCancelled, isApproved }) {
  if (isCancelled === true) return 'Cancelled'
  if (isApproved === true) return 'Accepted'
  if (isApproved === false) return 'Rejected'
  return 'Pending'
}

export const isPastBooking = (booking) => booking.date < todayLocal()

export const canEditBooking = (booking) => booking.status === 'Pending' && !isPastBooking(booking)

export const canCancelBooking = (booking) =>
  (booking.status === 'Pending' || booking.status === 'Accepted') && !isPastBooking(booking)

export const canCommentOnBooking = (booking) => booking.status !== 'Cancelled'
