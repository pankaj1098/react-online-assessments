import { CalendarX, DoorOpen, Pencil, SendHorizontal, X } from 'lucide-react'
import { useState } from 'react'
import { Link, useLocation, useParams } from 'react-router-dom'
import { PageBreadcrumbs } from '@/components/layout/PageBreadcrumbs'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Textarea } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { usePageMeta } from '@/hooks/usePageMeta'
import { getErrorMessage, toApiError } from '@/lib/api-error'
import { formatDateTime } from '@/lib/date'
import { BookingStatusBadge } from '../components/BookingStatusBadge'
import { BookingTimeline } from '../components/BookingTimeline'
import { CancelBookingDialog } from '../components/CancelBookingDialog'
import { MeetingRoomHeader } from '../components/MeetingRoomHeader'
import { formatDateLong, formatTimeRange } from '../format'
import { useAddComment, useBooking } from '../hooks'
import { canCancelBooking, canCommentOnBooking, canEditBooking } from '../status'
import { MEETING_ROOMS_PATH } from '../types'

const NOTE_MAX_LENGTH = 500

function StatusNote({ booking }) {
  if (booking.status === 'Pending') {
    return (
      <p className="rounded-xl bg-warning-soft px-4 py-3 text-sm text-warning">
        Waiting for the Meeting Room Manager to review. You will get an email when a decision is
        made.
      </p>
    )
  }
  if (booking.status === 'Accepted') {
    return (
      <p className="rounded-xl bg-success-soft px-4 py-3 text-sm text-success">
        Your booking is confirmed. The house keeping team has been informed.
      </p>
    )
  }
  if (booking.status === 'Rejected') {
    return (
      <div className="rounded-xl bg-danger-soft px-4 py-3 text-sm text-danger">
        <p className="font-semibold">Reason from the Meeting Room Manager</p>
        <p className="mt-1 break-words">{booking.managerRemarks || 'No reason was given.'}</p>
      </div>
    )
  }
  return (
    <p className="rounded-xl bg-muted px-4 py-3 text-sm text-muted-foreground">
      This booking was cancelled.
    </p>
  )
}

function NoteForm({ id }) {
  const addComment = useAddComment(id)
  const [text, setText] = useState('')
  const [error, setError] = useState('')
  function submit(event) {
    event.preventDefault()
    if (!text.trim()) {
      setError('Write a note first.')
      return
    }
    setError('')
    addComment.mutate(text.trim(), { onSuccess: () => setText('') })
  }
  return (
    <form onSubmit={submit} noValidate className="mt-6 grid gap-2 border-t border-border pt-5">
      <Label htmlFor="booking-note">Add a note for the Meeting Room Manager</Label>
      <Textarea
        id="booking-note"
        value={text}
        maxLength={NOTE_MAX_LENGTH}
        onChange={(event) => setText(event.target.value)}
        placeholder="e.g. We now need a second screen."
        className="min-h-20"
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? 'booking-note-error' : undefined}
      />
      {error && (
        <p id="booking-note-error" className="text-sm text-destructive">
          {error}
        </p>
      )}
      {addComment.isError && (
        <p role="alert" className="text-sm text-destructive">
          {getErrorMessage(addComment.error)}
        </p>
      )}
      <div className="flex justify-end">
        <Button type="submit" disabled={addComment.isPending}>
          {addComment.isPending ? 'Sending...' : 'Add note'}
          {!addComment.isPending && <SendHorizontal aria-hidden="true" />}
        </Button>
      </div>
    </form>
  )
}

export default function BookingDetailsPage() {
  const { id } = useParams()
  const location = useLocation()
  const { data: booking, isPending, isError, error } = useBooking(id)
  const [notice, setNotice] = useState(location.state?.notice ?? null)
  const [cancelTarget, setCancelTarget] = useState(null)
  usePageMeta('Booking details', 'See the status and history of your meeting room booking.')

  let body
  if (isPending) {
    body = (
      <div role="status" className="grid gap-5 xl:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
        <span className="sr-only">Loading booking</span>
        <Skeleton className="h-96 rounded-2xl" />
        <Skeleton className="h-96 rounded-2xl" />
      </div>
    )
  } else if (isError) {
    body = (
      <div role="alert" className="rounded-2xl border border-border bg-card p-8 text-center">
        <p className="font-semibold">
          {toApiError(error).status === 404
            ? 'This booking could not be found.'
            : getErrorMessage(error)}
        </p>
        <Button asChild className="mt-5">
          <Link to={`${MEETING_ROOMS_PATH}/my-bookings`}>Back to My Bookings</Link>
        </Button>
      </div>
    )
  } else {
    const rows = [
      ['Room', booking.roomName],
      ['Date', formatDateLong(booking.date)],
      ['Time', formatTimeRange(booking.startTime, booking.endTime)],
      ['Persons', booking.persons],
      ['Additional request', booking.additionalRequest || '-'],
      ['Requested on', formatDateTime(booking.createdOn)],
      ['Reference', booking.id],
    ]
    body = (
      <div className="grid items-start gap-5 xl:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
        <Card className="p-5 sm:p-6">
          <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
            <h2 className="min-w-0 text-xl font-bold tracking-tight break-words">
              {booking.title}
            </h2>
            <BookingStatusBadge status={booking.status} />
          </div>
          <StatusNote booking={booking} />
          <dl className="mt-5 grid gap-3.5">
            {rows.map(([key, value]) => (
              <div key={key} className="grid grid-cols-[9rem_1fr] gap-2.5">
                <dt className="text-muted-foreground">{key}</dt>
                <dd className="font-semibold break-words">{value}</dd>
              </div>
            ))}
          </dl>
          {(canEditBooking(booking) || canCancelBooking(booking)) && (
            <div className="mt-6 flex flex-wrap justify-end gap-3 border-t border-border pt-5">
              {canEditBooking(booking) && (
                <Button asChild variant="outline">
                  <Link to={`${MEETING_ROOMS_PATH}/${encodeURIComponent(booking.id)}/edit`}>
                    <Pencil aria-hidden="true" /> Edit
                  </Link>
                </Button>
              )}
              {canCancelBooking(booking) && (
                <Button variant="outline" onClick={() => setCancelTarget(booking)}>
                  <CalendarX aria-hidden="true" /> Cancel booking
                </Button>
              )}
            </div>
          )}
        </Card>

        <Card className="p-5 sm:p-6">
          <h2 className="mb-5 text-xl font-bold tracking-tight">Timeline</h2>
          <BookingTimeline entries={booking.timeline ?? []} />
          {canCommentOnBooking(booking) && <NoteForm id={booking.id} />}
        </Card>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-[100rem]">
      <PageBreadcrumbs
        items={[
          { label: 'Admin', to: '/admin' },
          { label: 'Meeting Room Bookings', to: MEETING_ROOMS_PATH },
          { label: 'My Bookings', to: `${MEETING_ROOMS_PATH}/my-bookings` },
          { label: booking?.id ?? 'Booking' },
        ]}
      />
      <MeetingRoomHeader
        icon={<DoorOpen />}
        title="Booking details"
        description={booking ? `Reference ${booking.id}` : 'Status and history of your request.'}
      />
      {notice && (
        <div
          role="status"
          className="mb-5 flex items-center justify-between gap-3 rounded-xl bg-success-soft px-4 py-3 text-success"
        >
          <p className="font-semibold">{notice}</p>
          <button
            type="button"
            aria-label="Dismiss message"
            onClick={() => setNotice(null)}
            className="rounded p-1 hover:bg-card/50"
          >
            <X className="size-4" aria-hidden="true" />
          </button>
        </div>
      )}
      {body}
      <CancelBookingDialog
        booking={cancelTarget}
        onClose={() => setCancelTarget(null)}
        onCancelled={() => {
          setCancelTarget(null)
          setNotice('Booking cancelled.')
        }}
      />
    </div>
  )
}
