import {
  ArrowRight,
  Bell,
  Building2,
  CalendarX,
  ChevronRight,
  CircleCheck,
  CircleX,
  Clock,
  DoorOpen,
  Lightbulb,
  Users,
} from 'lucide-react'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { MeetingRoomHeader } from '../components/MeetingRoomHeader'
import { PageBreadcrumbs } from '@/components/layout/PageBreadcrumbs'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { usePageMeta } from '@/hooks/usePageMeta'
import { getErrorMessage } from '@/lib/api-error'
import { cn } from '@/lib/utils'
import { ColumnChart, StatusSummary } from '../components/InsightCharts'
import {
  daysBetween,
  endOfMonth,
  formatHourLong,
  formatHourShort,
  formatTimeRange,
  dateParts,
  startOfMonth,
  todayLocal,
  weekdayLabels,
  weekdayNames,
} from '../format'
import { useInsights, useMyBookings } from '../hooks'
import { MEETING_ROOMS_PATH } from '../types'

const HOURS = Array.from({ length: 11 }, (_, index) => index + 8)

const statCards = [
  {
    status: 'Pending',
    label: 'Pending approval',
    hint: 'Waiting for a decision',
    icon: Clock,
    tone: 'bg-warning-soft text-warning',
    highlight: true,
  },
  {
    status: 'Accepted',
    label: 'Accepted',
    hint: 'Confirmed for you',
    icon: CircleCheck,
    tone: 'bg-success-soft text-success',
  },
  {
    status: 'Rejected',
    label: 'Rejected',
    hint: 'Try a different slot',
    icon: CircleX,
    tone: 'bg-danger-soft text-danger',
  },
  {
    status: 'Cancelled',
    label: 'Cancelled',
    hint: 'None in this period',
    icon: CalendarX,
    tone: 'bg-muted text-muted-foreground',
  },
]

const joinWords = (items) =>
  items.length <= 2 ? items.join(' and ') : `${items.slice(0, -1).join(', ')} and ${items.at(-1)}`

/** "Busiest at 9 AM and 3 PM. Rooms are easiest to get after 5 PM." */
function timingInsight(hourData) {
  const max = Math.max(0, ...hourData.map((item) => item.value))
  if (max === 0) return null
  const busiest = hourData
    .filter((item) => item.value === max)
    .map((item) => item.title.toUpperCase())
  const min = Math.min(...hourData.map((item) => item.value))
  const quietest = hourData.filter((item) => item.value === min)
  const trailing = quietest.at(-1) === hourData.at(-1)
  const easy = trailing
    ? `after ${(hourData[hourData.indexOf(quietest[0]) - 1] ?? quietest[0]).title.toUpperCase()}`
    : `around ${quietest[0].title.toUpperCase()}`
  return { busiest: joinWords(busiest), easy }
}

/** "Saturday is the busiest day. Wed to Fri have no bookings." */
function weekdayInsight(dayData) {
  const max = Math.max(0, ...dayData.map((item) => item.value))
  if (max === 0) return null
  const busiest = dayData
    .map((item, index) => (item.value === max ? weekdayNames[index] : null))
    .filter(Boolean)
  const quiet = []
  let run = []
  for (const [index, item] of dayData.entries()) {
    if (item.value === 0) run.push(index)
    else if (run.length) {
      quiet.push(run)
      run = []
    }
  }
  if (run.length) quiet.push(run)
  const phrases = quiet.map((days) =>
    days.length === 1
      ? weekdayLabels[days[0]]
      : `${weekdayLabels[days[0]]} to ${weekdayLabels[days.at(-1)]}`,
  )
  const quietDays = quiet.reduce((sum, days) => sum + days.length, 0)
  return {
    busiest: joinWords(busiest),
    plural: busiest.length > 1,
    quiet: phrases.length
      ? `${joinWords(phrases)} ${quietDays === 1 ? 'has' : 'have'} no bookings.`
      : '',
  }
}

function InsightCard({ title, insight, className, children }) {
  return (
    <Card className={cn('p-5 sm:p-6', className)}>
      <h3 className="text-lg font-bold tracking-tight">{title}</h3>
      {insight && (
        <p className="mt-1 mb-5 flex items-start gap-2 text-sm text-muted-foreground">
          <Lightbulb className="mt-0.5 size-4 shrink-0 text-tone-amber-border" aria-hidden="true" />
          <span>{insight}</span>
        </p>
      )}
      {children}
    </Card>
  )
}

function dayLabel(date) {
  const diff = daysBetween(todayLocal(), date)
  if (diff === 0) return 'Today'
  if (diff === 1) return 'Tomorrow'
  return `In ${diff} days`
}

function nowHHmm() {
  const now = new Date()
  return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`
}

function NextMeeting({ query }) {
  const today = todayLocal()
  const now = nowHHmm()
  const next = (query.data?.items ?? []).find(
    (item) => item.date > today || (item.date === today && item.endTime > now),
  )
  let body
  if (query.isPending) {
    body = <Skeleton className="h-48 bg-white/10" />
  } else if (query.isError) {
    body = (
      <div role="alert" className="my-auto text-sm">
        <p>{getErrorMessage(query.error)}</p>
        <Button
          variant="outline"
          className="mt-3 bg-transparent"
          onClick={() => void query.refetch()}
        >
          Try again
        </Button>
      </div>
    )
  } else if (!next) {
    body = (
      <div className="my-auto py-6">
        <h3 className="text-2xl font-bold tracking-tight">No upcoming meetings</h3>
        <p className="mt-2 text-sidebar-foreground/80">
          Accepted bookings show up here. Find a free room and send a request.
        </p>
        <Button asChild variant="secondary" className="mt-6">
          <Link to={`${MEETING_ROOMS_PATH}/create`}>
            Book a room <ArrowRight aria-hidden="true" />
          </Link>
        </Button>
      </div>
    )
  } else {
    const { day, month } = dateParts(next.date)
    const path = `${MEETING_ROOMS_PATH}/${encodeURIComponent(next.id)}`
    body = (
      <>
        <div className="flex items-start gap-4">
          <div
            aria-hidden="true"
            className="grid size-16 shrink-0 place-content-center rounded-2xl bg-white text-center text-sidebar"
          >
            <span className="text-3xl leading-none font-extrabold">{day}</span>
            <span className="mt-1 text-xs font-semibold uppercase">{month}</span>
          </div>
          <div className="min-w-0">
            <h3 className="text-2xl font-bold tracking-tight sm:text-3xl">{next.title}</h3>
            <ul className="mt-3 flex flex-wrap gap-2 text-sm">
              <li className="flex items-center gap-1.5 rounded-lg bg-white/10 px-3 py-1.5">
                <Clock className="size-4" aria-hidden="true" />
                {formatTimeRange(next.startTime, next.endTime)}
              </li>
              <li className="flex items-center gap-1.5 rounded-lg bg-white/10 px-3 py-1.5">
                <Building2 className="size-4" aria-hidden="true" />
                {next.roomName}
              </li>
              <li className="flex items-center gap-1.5 rounded-lg bg-white/10 px-3 py-1.5">
                <Users className="size-4" aria-hidden="true" />
                {next.persons} persons
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-auto flex flex-wrap items-center justify-between gap-3 pt-10">
          <span className="inline-flex items-center gap-2 rounded-full bg-success-soft px-3.5 py-1.5 text-sm font-semibold text-success">
            <CircleCheck className="size-4" aria-hidden="true" /> Accepted - you&apos;re all set
          </span>
          <div className="flex flex-wrap gap-3">
            <Button asChild variant="secondary">
              <Link to={path}>View details</Link>
            </Button>
            <Button
              asChild
              variant="outline"
              className="border-white/40 bg-transparent text-sidebar-foreground hover:bg-white/10 hover:text-sidebar-foreground"
            >
              <Link to={`${MEETING_ROOMS_PATH}/my-bookings`} state={{ status: 'Accepted' }}>
                All meetings <ArrowRight aria-hidden="true" />
              </Link>
            </Button>
          </div>
        </div>
      </>
    )
    return (
      <section
        aria-labelledby="next-meeting-heading"
        className="flex flex-col rounded-3xl bg-sidebar p-6 text-sidebar-foreground shadow-sm sm:p-7"
      >
        <p
          id="next-meeting-heading"
          className="mb-5 flex items-center gap-3 text-xs font-bold tracking-widest uppercase"
        >
          Your next meeting
          <span className="rounded-full bg-white px-2.5 py-0.5 text-xs font-semibold tracking-normal text-sidebar normal-case">
            {dayLabel(next.date)}
          </span>
        </p>
        {body}
      </section>
    )
  }
  return (
    <section
      aria-labelledby="next-meeting-heading"
      className="flex flex-col rounded-3xl bg-sidebar p-6 text-sidebar-foreground shadow-sm sm:p-7"
    >
      <p id="next-meeting-heading" className="mb-5 text-xs font-bold tracking-widest uppercase">
        Your next meeting
      </p>
      {body}
    </section>
  )
}

function Attention({ pending, rejected }) {
  const loading = pending.isPending || rejected.isPending
  const pendingCount = pending.data?.total ?? 0
  const rejectedCount = rejected.data?.total ?? 0
  const plural = (n, one, many) => (n === 1 ? one : many)
  return (
    <section
      aria-labelledby="attention-heading"
      className="rounded-3xl border border-tone-amber-border/50 bg-tone-amber-bg p-6 shadow-sm sm:p-7"
    >
      <h3
        id="attention-heading"
        className="mb-5 flex items-center gap-3 border-b border-tone-amber-border/40 pb-5 text-xl font-bold tracking-tight"
      >
        <span className="grid size-10 place-items-center rounded-full bg-tone-amber-border/30 text-warning">
          <Bell className="size-5" aria-hidden="true" />
        </span>
        Needs your attention
      </h3>
      {loading && <Skeleton className="h-32" />}
      {!loading && pendingCount === 0 && rejectedCount === 0 && (
        <p className="flex items-center gap-2 text-sm text-success">
          <CircleCheck className="size-4" aria-hidden="true" /> You&apos;re all caught up. Nothing
          is waiting on you.
        </p>
      )}
      {pendingCount > 0 && (
        <div className="grid gap-2">
          <h4 className="flex items-center gap-2 font-semibold text-warning">
            <Clock className="size-4" aria-hidden="true" />
            {pendingCount} {plural(pendingCount, 'request is', 'requests are')} waiting for approval
          </h4>
          <p className="text-sm text-foreground/80">
            The approver hasn&apos;t responded yet. Check My bookings for updates.
          </p>
          <Button asChild className="mt-2 w-fit bg-warning text-white hover:bg-warning/90">
            <Link to={`${MEETING_ROOMS_PATH}/my-bookings`} state={{ status: 'Pending' }}>
              Track request
            </Link>
          </Button>
        </div>
      )}
      {pendingCount > 0 && rejectedCount > 0 && (
        <div className="my-5 border-t border-tone-amber-border/40" />
      )}
      {rejectedCount > 0 && (
        <div className="grid gap-2">
          <h4 className="flex items-center gap-2 font-semibold text-danger">
            <CircleX className="size-4" aria-hidden="true" />
            {rejectedCount} {plural(rejectedCount, 'request was', 'requests were')} rejected
          </h4>
          <p className="text-sm text-foreground/80">Try another room or time and send it again.</p>
          <Link
            to={`${MEETING_ROOMS_PATH}/create`}
            className="mt-1 inline-flex w-fit items-center gap-2 text-sm font-semibold text-primary underline underline-offset-4"
          >
            Book another slot <ArrowRight className="size-4" aria-hidden="true" />
          </Link>
        </div>
      )}
    </section>
  )
}

export default function MeetingRoomDashboardPage() {
  usePageMeta('Meeting Room Bookings', 'Book meeting rooms and keep track of your requests.')
  const [range, setRange] = useState(() => {
    const today = todayLocal()
    return { from: startOfMonth(today), to: endOfMonth(today) }
  })
  const [rangeError, setRangeError] = useState(false)
  const insights = useInsights(range)
  const today = todayLocal()
  const upcoming = useMyBookings({
    status: 'Accepted',
    from: today,
    sort: 'dateAsc',
    page: 1,
    pageSize: 5,
  })
  const pending = useMyBookings({ status: 'Pending', from: today, page: 1, pageSize: 1 })
  const rejected = useMyBookings({ status: 'Rejected', from: today, page: 1, pageSize: 1 })

  function changeRange(key, value) {
    if (!value) return
    const next = { ...range, [key]: value }
    if (next.from > next.to) {
      setRangeError(true)
      return
    }
    setRangeError(false)
    setRange(next)
  }

  const data = insights.data
  const hourCounts = new Map((data?.byHour ?? []).map((item) => [item.hour, item.count]))
  const dayCounts = new Map((data?.byWeekday ?? []).map((item) => [item.day, item.count]))
  const hourData = HOURS.map((hour) => ({
    label: formatHourShort(hour),
    title: formatHourLong(hour),
    value: hourCounts.get(hour) ?? 0,
  }))
  const dayData = weekdayLabels.map((label, index) => ({ label, value: dayCounts.get(index) ?? 0 }))
  const rooms = data?.byRoom ?? []
  const maxRoom = Math.max(1, ...rooms.map((item) => item.count))
  const counts = data?.byStatus ?? { Pending: 0, Accepted: 0, Rejected: 0, Cancelled: 0 }
  const timing = timingInsight(hourData)
  const weekdays = weekdayInsight(dayData)

  return (
    <div className="mx-auto max-w-[100rem]">
      <PageBreadcrumbs
        items={[{ label: 'Admin', to: '/admin' }, { label: 'Meeting Room Bookings' }]}
      />
      <MeetingRoomHeader
        icon={<DoorOpen />}
        title="Meeting Room Bookings"
        description="Find a room, send a request and follow it until it is approved."
      />

      <div className="mb-8 grid gap-5 xl:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
        <NextMeeting query={upcoming} />
        <Attention pending={pending} rejected={rejected} />
      </div>

      <section aria-labelledby="overview-heading">
        <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 id="overview-heading" className="text-2xl font-bold tracking-tight">
              Overview
            </h2>
            <p className="text-sm text-muted-foreground">
              Your booking requests in the selected dates
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-border bg-card p-2 pl-4 shadow-sm">
            <label
              htmlFor="range-from"
              className="text-xs font-bold text-muted-foreground uppercase"
            >
              From
            </label>
            <Input
              id="range-from"
              type="date"
              value={range.from}
              onChange={(event) => changeRange('from', event.target.value)}
              className="h-10 w-auto"
            />
            <label htmlFor="range-to" className="text-xs font-bold text-muted-foreground uppercase">
              To
            </label>
            <Input
              id="range-to"
              type="date"
              value={range.to}
              onChange={(event) => changeRange('to', event.target.value)}
              className="h-10 w-auto"
            />
          </div>
        </div>
        {rangeError && (
          <p role="alert" className="mb-4 px-1 text-sm text-destructive">
            &quot;From&quot; must be on or before &quot;To&quot;.
          </p>
        )}

        <div className="mb-4 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {statCards.map(({ status, label, hint, icon: Icon, tone, highlight }) => {
            const count = counts[status] ?? 0
            return (
              <Link
                key={status}
                to={`${MEETING_ROOMS_PATH}/my-bookings`}
                state={{ status }}
                className={cn(
                  'flex items-center gap-4 rounded-2xl border p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md',
                  highlight && count > 0
                    ? 'border-tone-amber-border bg-tone-amber-bg'
                    : 'border-border bg-card',
                )}
              >
                <span className={cn('grid size-14 shrink-0 place-items-center rounded-2xl', tone)}>
                  <Icon className="size-6" aria-hidden="true" />
                </span>
                <span>
                  <b className="block text-4xl leading-none font-extrabold">
                    {insights.isPending ? '-' : count}
                  </b>
                  <b className="mt-1.5 block text-sm font-semibold">{label}</b>
                  <span className="block text-xs text-muted-foreground">
                    {status === 'Cancelled' && count > 0 ? 'Cancelled by you' : hint}
                  </span>
                </span>
              </Link>
            )
          })}
        </div>

        <Card className="mb-5 p-5">
          {insights.isPending ? <Skeleton className="h-10" /> : <StatusSummary counts={counts} />}
        </Card>

        {insights.isError ? (
          <div
            role="alert"
            className="rounded-2xl border border-border bg-card p-6 text-center text-sm"
          >
            <p className="text-destructive">{getErrorMessage(insights.error)}</p>
            <Button variant="link" onClick={() => void insights.refetch()}>
              Try again
            </Button>
          </div>
        ) : (
          <div className="grid gap-5">
            <div className="grid gap-5 xl:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)]">
              <InsightCard
                title="Popular timing"
                insight={
                  timing && (
                    <>
                      Busiest at <b className="text-foreground">{timing.busiest}</b>. Rooms are
                      easiest to get {timing.easy}.
                    </>
                  )
                }
              >
                {insights.isPending ? (
                  <Skeleton className="h-56" />
                ) : (
                  <ColumnChart data={hourData} label="Popular timing by hour" />
                )}
              </InsightCard>
              <InsightCard
                title="Busiest days"
                insight={
                  weekdays && (
                    <>
                      <b className="text-foreground">{weekdays.busiest}</b>{' '}
                      {weekdays.plural ? 'are the busiest days' : 'is the busiest day'}.{' '}
                      {weekdays.quiet}
                    </>
                  )
                }
              >
                {insights.isPending ? (
                  <Skeleton className="h-56" />
                ) : (
                  <ColumnChart data={dayData} label="Meetings by day of the week" />
                )}
              </InsightCard>
            </div>

            <InsightCard title="Bookings by room">
              <p className="mt-1 mb-5 text-sm text-muted-foreground">
                Most booked first. Pick any room to start a request.
              </p>
              {insights.isPending ? (
                <Skeleton className="h-48" />
              ) : rooms.length === 0 ? (
                <p className="text-sm text-muted-foreground">No bookings in this period.</p>
              ) : (
                <ol className="grid gap-x-10 gap-y-5 md:grid-flow-col md:grid-cols-2 md:grid-rows-4">
                  {rooms.slice(0, 8).map((room, index) => (
                    <li key={room.roomId}>
                      <Link
                        to={`${MEETING_ROOMS_PATH}/create`}
                        state={{ roomId: room.roomId }}
                        className="group flex items-center gap-4 rounded-xl"
                      >
                        <span
                          aria-hidden="true"
                          className="grid size-8 shrink-0 place-items-center rounded-full bg-muted text-sm font-semibold"
                        >
                          {index + 1}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="mb-1.5 flex items-center justify-between gap-3 text-sm">
                            <span className="flex min-w-0 items-center gap-2">
                              <b className="truncate font-semibold group-hover:underline">
                                {room.roomName}
                              </b>
                              {room.location && (
                                <span className="shrink-0 rounded-md bg-muted px-2 py-0.5 text-xs text-muted-foreground">
                                  {room.location}
                                </span>
                              )}
                            </span>
                            <span className="shrink-0 text-xs font-semibold">
                              {room.count} {room.count === 1 ? 'booking' : 'bookings'}
                            </span>
                          </span>
                          <span className="block h-2 overflow-hidden rounded-full bg-muted">
                            <span
                              className={cn(
                                'block h-full rounded-full',
                                index === 0 ? 'bg-sidebar' : 'bg-primary/65',
                              )}
                              style={{ width: `${(room.count / maxRoom) * 100}%` }}
                            />
                          </span>
                        </span>
                        <ChevronRight
                          className="size-4 shrink-0 text-muted-foreground"
                          aria-hidden="true"
                        />
                        <span className="sr-only">Start a request for {room.roomName}</span>
                      </Link>
                    </li>
                  ))}
                </ol>
              )}
            </InsightCard>
          </div>
        )}
      </section>
    </div>
  )
}
