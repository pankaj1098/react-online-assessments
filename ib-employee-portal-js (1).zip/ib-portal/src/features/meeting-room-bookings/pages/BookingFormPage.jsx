import { DoorOpen } from 'lucide-react'
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom'
import { PageBreadcrumbs } from '@/components/layout/PageBreadcrumbs'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { usePageMeta } from '@/hooks/usePageMeta'
import { getErrorMessage, toApiError } from '@/lib/api-error'
import { BookingForm } from '../components/BookingForm'
import { MeetingRoomHeader } from '../components/MeetingRoomHeader'
import { useBooking, useCreateBooking, useMeetingRooms, useUpdateBooking } from '../hooks'
import { canEditBooking } from '../status'
import { MEETING_ROOMS_PATH } from '../types'

const blankForm = {
  title: '',
  persons: '',
  additionalRequest: '',
  startDate: '',
  endDate: '',
  startTime: '',
  endTime: '',
  roomId: '',
}

/** Handles both "Book a Meeting Room" (/create) and "Edit" (/:id/edit). */
export default function BookingFormPage() {
  const { id } = useParams()
  const isEdit = Boolean(id)
  const title = isEdit ? 'Edit Booking Request' : 'Book a Meeting Room'
  usePageMeta(title, 'Send a meeting room request for approval by the Meeting Room Manager.')
  const navigate = useNavigate()
  const preselectedRoom = useLocation().state?.roomId ?? ''
  const roomsQuery = useMeetingRooms()
  const existing = useBooking(id)
  const create = useCreateBooking()
  const update = useUpdateBooking(id ?? '')
  const mutation = isEdit ? update : create
  const detailsPath = id ? `${MEETING_ROOMS_PATH}/${encodeURIComponent(id)}` : MEETING_ROOMS_PATH

  function handleSubmit(values) {
    if (isEdit) {
      update.mutate(
        {
          roomId: values.roomId,
          date: values.startDate,
          startTime: values.startTime,
          endTime: values.endTime,
          title: values.title,
          persons: values.persons,
          additionalRequest: values.additionalRequest,
        },
        {
          onSuccess: () =>
            void navigate(detailsPath, { state: { notice: 'Booking request updated.' } }),
        },
      )
      return
    }
    create.mutate(
      {
        title: values.title,
        persons: values.persons,
        additionalRequest: values.additionalRequest,
        startDate: values.startDate,
        endDate: values.endDate,
        startTime: values.startTime,
        endTime: values.endTime,
        roomId: values.roomId,
      },
      {
        onSuccess: (created) =>
          void navigate(`${MEETING_ROOMS_PATH}/my-bookings`, {
            state: {
              notice:
                created.length > 1
                  ? `${created.length} booking requests submitted for approval.`
                  : 'Booking request submitted for approval.',
            },
          }),
      },
    )
  }

  let body
  if (isEdit && existing.isPending) {
    body = (
      <div className="space-y-4" role="status">
        <span className="sr-only">Loading booking</span>
        {[0, 1, 2].map((i) => (
          <Skeleton key={i} className="h-40 rounded-2xl" />
        ))}
      </div>
    )
  } else if (isEdit && existing.isError) {
    const status = toApiError(existing.error).status
    body = (
      <div role="alert" className="rounded-2xl border border-border bg-card p-8 text-center">
        <p className="font-semibold">
          {status === 404 ? 'This booking could not be found.' : getErrorMessage(existing.error)}
        </p>
        <Button asChild className="mt-5">
          <Link to={`${MEETING_ROOMS_PATH}/my-bookings`}>Back to My Bookings</Link>
        </Button>
      </div>
    )
  } else if (isEdit && existing.data && !canEditBooking(existing.data)) {
    body = (
      <div role="alert" className="rounded-2xl border border-border bg-card p-8 text-center">
        <p className="font-semibold">Only upcoming Pending requests can be edited.</p>
        <Button asChild className="mt-5">
          <Link to={detailsPath}>Back to booking</Link>
        </Button>
      </div>
    )
  } else {
    const booking = existing.data
    const defaults = booking
      ? {
          title: booking.title,
          persons: String(booking.persons),
          additionalRequest: booking.additionalRequest ?? '',
          startDate: booking.date,
          endDate: '',
          startTime: booking.startTime,
          endTime: booking.endTime,
          roomId: booking.roomId,
        }
      : { ...blankForm, roomId: preselectedRoom }
    body = (
      <BookingForm
        mode={isEdit ? 'edit' : 'create'}
        rooms={roomsQuery.data ?? []}
        roomsPending={roomsQuery.isPending}
        defaultValues={defaults}
        excludeId={id}
        isSubmitting={mutation.isPending}
        submitError={mutation.error}
        onSubmit={handleSubmit}
        onCancel={() => void navigate(isEdit ? detailsPath : MEETING_ROOMS_PATH)}
      />
    )
  }

  return (
    <div className="mx-auto max-w-[100rem]">
      <PageBreadcrumbs
        items={[
          { label: 'Admin', to: '/admin' },
          { label: 'Meeting Room Bookings', to: MEETING_ROOMS_PATH },
          { label: title },
        ]}
      />
      <MeetingRoomHeader
        icon={<DoorOpen />}
        title={title}
        description="Choose a room and a time. The Meeting Room Manager approves every request."
      />
      {body}
    </div>
  )
}
