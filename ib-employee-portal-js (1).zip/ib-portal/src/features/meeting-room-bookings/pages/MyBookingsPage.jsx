import { ClipboardList, Plus, Search, X } from 'lucide-react'
import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { EmptyState } from '@/components/common/EmptyState'
import { PageBreadcrumbs } from '@/components/layout/PageBreadcrumbs'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { useDebouncedValue } from '@/hooks/useDebouncedValue'
import { usePageMeta } from '@/hooks/usePageMeta'
import { getErrorMessage } from '@/lib/api-error'
import { cn } from '@/lib/utils'
import { BookingCard } from '../components/BookingCard'
import { CancelBookingDialog } from '../components/CancelBookingDialog'
import { MeetingRoomHeader } from '../components/MeetingRoomHeader'
import { useMyBookings } from '../hooks'
import { bookingStatuses, MEETING_ROOMS_PATH } from '../types'

const PAGE_STEP = 8
const statusFilters = ['', ...bookingStatuses]

export default function MyBookingsPage() {
  usePageMeta('My Bookings', 'Track, edit and cancel your meeting room booking requests.')
  const location = useLocation()
  const [notice, setNotice] = useState(location.state?.notice ?? null)
  const [status, setStatus] = useState(location.state?.status ?? '')
  const [search, setSearch] = useState('')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [pageSize, setPageSize] = useState(PAGE_STEP)
  const [cancelTarget, setCancelTarget] = useState(null)
  const debouncedSearch = useDebouncedValue(search)
  const invalidRange = Boolean(from && to && from > to)
  const { data, isPending, isError, error, refetch, isPlaceholderData } = useMyBookings({
    status,
    search: debouncedSearch,
    from,
    to,
    sort: 'dateDesc',
    page: 1,
    pageSize,
  })
  const items = data?.items ?? []
  const total = data?.total ?? 0

  return (
    <div className="mx-auto max-w-[100rem]">
      <PageBreadcrumbs
        items={[
          { label: 'Admin', to: '/admin' },
          { label: 'Meeting Room Bookings', to: MEETING_ROOMS_PATH },
          { label: 'My Bookings' },
        ]}
      />
      <MeetingRoomHeader
        icon={<ClipboardList />}
        title="My Bookings"
        description="Every request you have sent, and what happened to it."
      />

      {notice && (
        <div
          role="status"
          className="mb-5 flex items-center justify-between gap-3 rounded-xl bg-success-soft px-4 py-3 text-success"
        >
          <p className="font-semibold">{notice}</p>
          <button
            type="button"
            aria-label="Dismiss message"
            onClick={() => setNotice(null)}
            className="rounded p-1 hover:bg-card/50"
          >
            <X className="size-4" aria-hidden="true" />
          </button>
        </div>
      )}

      <Card className="mb-5 p-5">
        <div className="grid items-end gap-4 lg:grid-cols-[minmax(0,1.4fr)_repeat(2,minmax(0,0.5fr))]">
          <div className="grid gap-1.5 text-sm">
            <label htmlFor="booking-search">Search</label>
            <Input
              id="booking-search"
              type="search"
              icon={<Search />}
              value={search}
              onChange={(event) => {
                setSearch(event.target.value)
                setPageSize(PAGE_STEP)
              }}
              placeholder="Title, room or reference..."
              className="h-12"
            />
          </div>
          <div className="grid gap-1.5 text-sm">
            <label htmlFor="booking-from">From date</label>
            <Input
              id="booking-from"
              type="date"
              value={from}
              onChange={(event) => setFrom(event.target.value)}
              className="h-12"
            />
          </div>
          <div className="grid gap-1.5 text-sm">
            <label htmlFor="booking-to">To date</label>
            <Input
              id="booking-to"
              type="date"
              value={to}
              onChange={(event) => setTo(event.target.value)}
              className="h-12"
            />
          </div>
        </div>
        {invalidRange && (
          <p role="alert" className="mt-3 text-sm text-destructive">
            &quot;From date&quot; must be on or before &quot;To date&quot;.
          </p>
        )}
        <div role="group" aria-label="Filter by status" className="mt-4 flex flex-wrap gap-2">
          {statusFilters.map((value) => (
            <button
              key={value || 'all'}
              type="button"
              aria-pressed={status === value}
              onClick={() => {
                setStatus(value)
                setPageSize(PAGE_STEP)
              }}
              className={cn(
                'min-h-10 rounded-xl border px-4 text-sm whitespace-nowrap transition-colors',
                status === value
                  ? 'border-primary bg-primary font-bold text-primary-foreground shadow-sm'
                  : 'border-input bg-card hover:bg-secondary',
              )}
            >
              {value || 'All'}
            </button>
          ))}
        </div>
      </Card>

      <Card className="p-5">
        {isPending && (
          <div role="status" className="grid gap-3">
            <span className="sr-only">Loading bookings</span>
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-24 rounded-2xl" />
            ))}
          </div>
        )}
        {isError && (
          <div role="alert" className="py-8 text-center text-sm">
            <p className="text-destructive">{getErrorMessage(error)}</p>
            <Button variant="link" onClick={() => void refetch()}>
              Try again
            </Button>
          </div>
        )}
        {!isPending && !isError && items.length === 0 && (
          <EmptyState>No bookings match your filters.</EmptyState>
        )}
        <ul
          aria-busy={isPlaceholderData}
          className={cn('grid gap-3', isPlaceholderData && 'opacity-60')}
        >
          {items.map((booking) => (
            <BookingCard key={booking.id} booking={booking} onCancel={setCancelTarget} />
          ))}
        </ul>
        {items.length > 0 && (
          <div className="mt-5 flex flex-col items-center gap-3 text-sm text-muted-foreground sm:flex-row sm:justify-between">
            <span>
              Showing {items.length} of {total} bookings
            </span>
            {items.length < total && (
              <Button variant="outline" onClick={() => setPageSize(pageSize + PAGE_STEP)}>
                Show more
              </Button>
            )}
          </div>
        )}
      </Card>

      <CancelBookingDialog
        booking={cancelTarget}
        onClose={() => setCancelTarget(null)}
        onCancelled={() => {
          setCancelTarget(null)
          setNotice('Booking cancelled.')
        }}
      />
    </div>
  )
}
