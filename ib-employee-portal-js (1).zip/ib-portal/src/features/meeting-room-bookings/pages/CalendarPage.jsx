import { ChevronLeft, ChevronRight, DoorOpen } from 'lucide-react'
import { useState } from 'react'
import { PageBreadcrumbs } from '@/components/layout/PageBreadcrumbs'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { NativeSelect } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { usePageMeta } from '@/hooks/usePageMeta'
import { getErrorMessage } from '@/lib/api-error'
import { cn } from '@/lib/utils'
import { BookingsCalendar } from '../components/BookingsCalendar'
import { MeetingRoomHeader } from '../components/MeetingRoomHeader'
import {
  addDays,
  endOfMonth,
  formatDateLong,
  formatDayMonth,
  formatMonthYear,
  monthGridRange,
  shiftMonth,
  startOfMonth,
  startOfWeek,
  todayLocal,
} from '../format'
import { useCalendar, useMeetingRooms } from '../hooks'
import { toneStyles } from '../roomTone'
import { calendarViews } from '../types'

function rangeFor(view, anchor) {
  if (view === 'month') return monthGridRange(anchor)
  if (view === 'week') {
    const from = startOfWeek(anchor)
    return { from, to: addDays(from, 6) }
  }
  if (view === 'day') return { from: anchor, to: anchor }
  return { from: startOfMonth(anchor), to: endOfMonth(anchor) }
}

function shift(view, anchor, direction) {
  if (view === 'week') return addDays(anchor, 7 * direction)
  if (view === 'day') return addDays(anchor, direction)
  return shiftMonth(anchor, direction)
}

function titleFor(view, anchor) {
  if (view === 'week') {
    const from = startOfWeek(anchor)
    return `${formatDayMonth(from)} - ${formatDayMonth(addDays(from, 6))}`
  }
  if (view === 'day') return formatDateLong(anchor)
  return formatMonthYear(anchor)
}

export default function CalendarPage() {
  usePageMeta('Booking Calendar', 'See approved meeting room bookings by month, week, day or list.')
  const [view, setView] = useState('month')
  const [anchor, setAnchor] = useState(todayLocal)
  const [roomId, setRoomId] = useState('')
  const roomsQuery = useMeetingRooms()
  const rooms = roomsQuery.data ?? []
  const range = rangeFor(view, anchor)
  const {
    data: events = [],
    isPending,
    isError,
    error,
    refetch,
    isPlaceholderData,
  } = useCalendar({
    ...range,
    roomId,
  })
  const toneOf = (id) => rooms.find((item) => item.id === id)?.tone

  function pickDay(date) {
    setAnchor(date)
    setView('day')
  }

  return (
    <div className="mx-auto max-w-[100rem]">
      <PageBreadcrumbs
        items={[
          { label: 'Admin', to: '/admin' },
          { label: 'Meeting Room Bookings', to: '/admin/meeting-room-bookings' },
          { label: 'Calendar' },
        ]}
      />
      <MeetingRoomHeader
        icon={<DoorOpen />}
        title="Booking Calendar"
        description="Approved bookings of every room, so you can pick a free slot."
      />

      <Card className="p-5">
        <div className="mb-5 flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex gap-1.5">
              <Button
                variant="outline"
                size="icon"
                aria-label="Previous"
                onClick={() => setAnchor(shift(view, anchor, -1))}
              >
                <ChevronLeft aria-hidden="true" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                aria-label="Next"
                onClick={() => setAnchor(shift(view, anchor, 1))}
              >
                <ChevronRight aria-hidden="true" />
              </Button>
              <Button variant="secondary" onClick={() => setAnchor(todayLocal())}>
                Today
              </Button>
            </div>
            <h2 aria-live="polite" className="text-xl font-bold tracking-tight">
              {titleFor(view, anchor)}
            </h2>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <div role="group" aria-label="Calendar view" className="flex gap-1.5">
              {calendarViews.map(({ id, label }) => (
                <button
                  key={id}
                  type="button"
                  aria-pressed={view === id}
                  onClick={() => setView(id)}
                  className={cn(
                    'min-h-10 rounded-xl border px-4 text-sm whitespace-nowrap transition-colors',
                    view === id
                      ? 'border-primary bg-primary font-bold text-primary-foreground shadow-sm'
                      : 'border-input bg-card hover:bg-secondary',
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
            <NativeSelect
              aria-label="Filter by room"
              value={roomId}
              onChange={(event) => setRoomId(event.target.value)}
              className="h-10 sm:w-56"
            >
              <option value="">All rooms</option>
              {rooms.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name} ({item.location})
                </option>
              ))}
            </NativeSelect>
          </div>
        </div>

        {rooms.length > 0 && (
          <ul
            aria-label="Room colours"
            className="mb-5 flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-muted-foreground"
          >
            {rooms.map((item) => (
              <li key={item.id} className="flex items-center gap-1.5">
                <span
                  aria-hidden="true"
                  className={cn('size-2.5 rounded-full', toneStyles(item.tone).dot)}
                />
                {item.name} ({item.location})
              </li>
            ))}
          </ul>
        )}

        {isPending && <Skeleton className="h-96 rounded-xl" />}
        {isError && (
          <div role="alert" className="py-8 text-center text-sm">
            <p className="text-destructive">{getErrorMessage(error)}</p>
            <Button variant="link" onClick={() => void refetch()}>
              Try again
            </Button>
          </div>
        )}
        {!isPending && !isError && (
          <div aria-busy={isPlaceholderData} className={cn(isPlaceholderData && 'opacity-60')}>
            <BookingsCalendar
              view={view}
              anchor={anchor}
              events={events}
              toneOf={toneOf}
              onPickDay={pickDay}
            />
          </div>
        )}
      </Card>
    </div>
  )
}
