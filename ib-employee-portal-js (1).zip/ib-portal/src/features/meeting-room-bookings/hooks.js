import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { meetingRoomApi } from './api/meetingRoomApi'

export const meetingRoomKeys = {
  all: ['meeting-rooms'],
  rooms: () => [...meetingRoomKeys.all, 'rooms'],
  list: (params) => [...meetingRoomKeys.all, 'list', params],
  detail: (id) => [...meetingRoomKeys.all, 'detail', id],
  calendar: (params) => [...meetingRoomKeys.all, 'calendar', params],
  insights: (params) => [...meetingRoomKeys.all, 'insights', params],
  availability: (params) => [...meetingRoomKeys.all, 'availability', params],
}

export function useMeetingRooms() {
  return useQuery({
    queryKey: meetingRoomKeys.rooms(),
    queryFn: meetingRoomApi.rooms,
    staleTime: 5 * 60_000,
  })
}

export function useMyBookings(params) {
  return useQuery({
    queryKey: meetingRoomKeys.list(params),
    queryFn: () => meetingRoomApi.list(params),
    placeholderData: keepPreviousData,
  })
}

export function useBooking(id) {
  return useQuery({
    queryKey: meetingRoomKeys.detail(id ?? ''),
    queryFn: () => meetingRoomApi.get(id ?? ''),
    enabled: Boolean(id),
  })
}

export function useCalendar(params, enabled = true) {
  return useQuery({
    queryKey: meetingRoomKeys.calendar(params),
    queryFn: () => meetingRoomApi.calendar(params),
    enabled,
    placeholderData: keepPreviousData,
  })
}

export function useInsights(params) {
  return useQuery({
    queryKey: meetingRoomKeys.insights(params),
    queryFn: () => meetingRoomApi.insights(params),
    placeholderData: keepPreviousData,
  })
}

export function useAvailability(params, enabled) {
  return useQuery({
    queryKey: meetingRoomKeys.availability(params),
    queryFn: () => meetingRoomApi.availability(params),
    enabled,
    staleTime: 10_000,
    retry: false,
  })
}

function useInvalidateAll() {
  const queryClient = useQueryClient()
  return () => queryClient.invalidateQueries({ queryKey: meetingRoomKeys.all })
}

export function useCreateBooking() {
  const invalidate = useInvalidateAll()
  return useMutation({
    mutationFn: (input) => meetingRoomApi.create(input),
    onSuccess: invalidate,
  })
}

export function useUpdateBooking(id) {
  const invalidate = useInvalidateAll()
  return useMutation({
    mutationFn: (input) => meetingRoomApi.update(id, input),
    onSuccess: invalidate,
  })
}

export function useCancelBooking() {
  const invalidate = useInvalidateAll()
  return useMutation({
    mutationFn: (id) => meetingRoomApi.cancel(id),
    onSuccess: invalidate,
  })
}

export function useAddComment(id) {
  const invalidate = useInvalidateAll()
  return useMutation({
    mutationFn: (message) => meetingRoomApi.addComment(id, message),
    onSuccess: invalidate,
  })
}
