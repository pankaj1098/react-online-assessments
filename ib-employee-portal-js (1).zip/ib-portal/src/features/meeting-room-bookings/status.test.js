import { describe, expect, it } from 'vitest'
import { getBookingStatus } from './status'

describe('getBookingStatus', () => {
  it('maps the approval flags to a status', () => {
    expect(getBookingStatus({ isCancelled: false, isApproved: null })).toBe('Pending')
    expect(getBookingStatus({ isCancelled: false, isApproved: true })).toBe('Accepted')
    expect(getBookingStatus({ isCancelled: false, isApproved: false })).toBe('Rejected')
  })
  it('lets cancelled win over approval', () => {
    expect(getBookingStatus({ isCancelled: true, isApproved: true })).toBe('Cancelled')
  })
})
