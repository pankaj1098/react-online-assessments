import { z } from 'zod'
import { daysBetween, todayLocal } from '../format'

export const REQUEST_MAX_LENGTH = 500
export const MAX_BOOKING_DAYS = 31

/** `endDate` is optional: blank means a single day. */
export const bookingFormSchema = z
  .object({
    title: z
      .string()
      .trim()
      .min(1, 'Enter the meeting title.')
      .max(150, 'Title is too long (max 150 characters).'),
    persons: z
      .string()
      .trim()
      .regex(/^[1-9]\d{0,2}$/, 'Enter the number of persons (1-999).'),
    additionalRequest: z
      .string()
      .trim()
      .max(REQUEST_MAX_LENGTH, `Request is too long (max ${REQUEST_MAX_LENGTH} characters).`),
    startDate: z.string().min(1, 'Select the start date.'),
    endDate: z.string(),
    startTime: z.string().min(1, 'Select the start time.'),
    endTime: z.string().min(1, 'Select the end time.'),
    roomId: z.string().min(1, 'Select a room.'),
  })
  .superRefine((values, ctx) => {
    const end = values.endDate || values.startDate
    if (values.startDate && values.startDate < todayLocal()) {
      ctx.addIssue({
        code: 'custom',
        path: ['startDate'],
        message: 'The start date cannot be in the past.',
      })
    }
    if (values.startDate && end < values.startDate) {
      ctx.addIssue({
        code: 'custom',
        path: ['endDate'],
        message: 'End date must be on or after the start date.',
      })
    } else if (values.startDate && daysBetween(values.startDate, end) > MAX_BOOKING_DAYS) {
      ctx.addIssue({
        code: 'custom',
        path: ['endDate'],
        message: `A request can cover at most ${MAX_BOOKING_DAYS} days.`,
      })
    }
    if (values.startTime && values.endTime && values.endTime <= values.startTime) {
      ctx.addIssue({
        code: 'custom',
        path: ['endTime'],
        message: 'End time must be after the start time.',
      })
    }
  })
