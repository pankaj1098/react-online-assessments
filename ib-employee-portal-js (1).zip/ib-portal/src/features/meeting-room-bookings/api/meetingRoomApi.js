import { endpoints } from '@/config/endpoints'
import { ApiError } from '@/lib/api-error'
import { http } from '@/lib/http'
import { toneOrder } from '../roomTone'
import { getBookingStatus } from '../status'

/**
 * Meeting room calls. Paths, query names and response shapes are the contract assumed for the
 * .NET API - adjust here if it differs. The server sends `isApproved` (null/true/false) and
 * `isCancelled`; they are turned into a single `status` here.
 */
function normalizeRoom(room, index) {
  return { ...room, tone: room.tone ?? toneOrder[index % toneOrder.length] }
}

function normalizeBooking(raw) {
  const { isApproved, isCancelled, ...booking } = raw
  return { ...booking, status: getBookingStatus({ isApproved, isCancelled }) }
}

const normalizePage = (page) => ({ items: page.items.map(normalizeBooking), total: page.total })

export const meetingRoomApi = {
  async rooms() {
    if (__USE_MOCK__) {
      const { mockRooms } = await import('./meetingRoomMock')
      return (await mockRooms()).map(normalizeRoom)
    }
    const { data } = await http.get(endpoints.meetingRooms.rooms)
    return data.map(normalizeRoom)
  },
  async list(params) {
    if (__USE_MOCK__) {
      const { mockList } = await import('./meetingRoomMock')
      return normalizePage(await mockList(params))
    }
    const { data } = await http.get(endpoints.meetingRooms.bookings, {
      params: {
        status: params.status || undefined,
        search: params.search || undefined,
        from: params.from || undefined,
        to: params.to || undefined,
        sort: params.sort || undefined,
        page: params.page,
        pageSize: params.pageSize,
      },
    })
    return normalizePage(data)
  },
  async get(id) {
    if (__USE_MOCK__) {
      const { mockGet } = await import('./meetingRoomMock')
      return normalizeBooking(await mockGet(id))
    }
    const { data } = await http.get(endpoints.meetingRooms.item(id))
    return normalizeBooking(data)
  },
  /** Returns one booking per day of the request. */
  async create(input) {
    if (__USE_MOCK__) {
      const { mockCreate } = await import('./meetingRoomMock')
      return (await mockCreate(input)).map(normalizeBooking)
    }
    const { data } = await http.post(endpoints.meetingRooms.bookings, input)
    return (Array.isArray(data) ? data : [data]).map(normalizeBooking)
  },
  async update(id, input) {
    if (__USE_MOCK__) {
      const { mockUpdate } = await import('./meetingRoomMock')
      return normalizeBooking(await mockUpdate(id, input))
    }
    const { data } = await http.put(endpoints.meetingRooms.item(id), input)
    return normalizeBooking(data)
  },
  async cancel(id) {
    if (__USE_MOCK__) {
      const { mockCancel } = await import('./meetingRoomMock')
      return normalizeBooking(await mockCancel(id))
    }
    const { data } = await http.post(endpoints.meetingRooms.cancel(id))
    return normalizeBooking(data)
  },
  /** Adds a comment to the booking's timeline. */
  async addComment(id, message) {
    if (__USE_MOCK__) {
      const { mockAddComment } = await import('./meetingRoomMock')
      return mockAddComment(id, message)
    }
    const { data } = await http.post(endpoints.meetingRooms.comments(id), { message })
    return data
  },
  /** Approved bookings of every employee, as calendar events. */
  async calendar(params) {
    if (__USE_MOCK__) {
      const { mockCalendar } = await import('./meetingRoomMock')
      return mockCalendar(params)
    }
    const { data } = await http.get(endpoints.meetingRooms.calendar, {
      params: { from: params.from, to: params.to, roomId: params.roomId || undefined },
    })
    return data
  },
  /** A 409 from the server means the slot clashes; it is returned as `{ available: false }`. */
  async availability(params) {
    if (__USE_MOCK__) {
      const { mockAvailability } = await import('./meetingRoomMock')
      return mockAvailability(params)
    }
    try {
      await http.post(endpoints.meetingRooms.availability, params)
      return { available: true }
    } catch (error) {
      if (error instanceof ApiError && error.status === 409) {
        return { available: false, message: error.message }
      }
      throw error
    }
  },
  async insights(params) {
    if (__USE_MOCK__) {
      const { mockInsights } = await import('./meetingRoomMock')
      return mockInsights(params)
    }
    const { data } = await http.get(endpoints.meetingRooms.insights, {
      params: { from: params.from, to: params.to },
    })
    return data
  },
}
