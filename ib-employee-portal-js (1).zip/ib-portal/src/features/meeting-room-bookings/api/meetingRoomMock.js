import { ApiError } from '@/lib/api-error'
import { formatDate } from '@/lib/date'
import { readJson, writeJson } from '@/lib/storage'
import { addDays, eachDay, formatTime, toMinutes, todayLocal, weekdayIndex } from '../format'
import { getBookingStatus } from '../status'

/** Dev-only sample data. Room names come from the old portal; capacities and people are invented. */
const STORAGE_KEY = 'ib-meeting-room-bookings-v2'
const ME = 'me'

function room(id, name, location, capacity, facilities) {
  return { id, name, location, capacity, facilities }
}

const rooms = [
  room('board-room-corp-1', 'Board Room', 'Corp-I', 20, ['Projector', 'Video conferencing']),
  room('mapple', 'Mapple', 'Corp-I', 8, ['TV screen', 'Whiteboard']),
  room('ruby', 'Ruby', 'Corp-I', 6, ['Whiteboard']),
  room('tulip', 'Tulip', 'Corp-I', 10, ['Projector', 'Whiteboard']),
  room('sapphire', 'Sapphire', 'Corp-I', 12, ['Projector', 'Video conferencing']),
  room('saffron', 'SAFFRON', 'Corp-II', 8, ['TV screen', 'Whiteboard']),
  room('blue-bell', 'BLUE BELL', 'Corp-II', 10, ['Projector', 'Whiteboard']),
  room('apricot', 'APRICOT', 'Corp-II', 6, ['Whiteboard']),
  room('daisy', 'DAISY', 'Corp-II', 4, ['TV screen']),
  room('executive-zone', 'Executive Zone', 'CET', 14, ['Projector', 'Video conferencing']),
  room('board-room-cet', 'Board Room', 'CET', 16, ['Projector', 'Video conferencing']),
]

const roomLabel = (item) => `${item.name} (${item.location})`
const findRoom = (id) => rooms.find((item) => item.id === id)

/** Seed entries use stable ids so React keys do not change between reads. */
function entry(type, message, actor, hoursAgo) {
  return {
    id: `${type}-${hoursAgo}`,
    type,
    message,
    actor,
    at: new Date(Date.now() - hoursAgo * 3_600_000).toISOString(),
  }
}

function liveEntry(type, message) {
  return {
    id: `${type}-${Date.now()}`,
    type,
    message,
    actor: 'You',
    at: new Date().toISOString(),
  }
}

function booking(fields) {
  return {
    ownerId: 'other',
    requesterName: 'A. Mehta',
    department: 'Operations',
    persons: 4,
    additionalRequest: '',
    isApproved: true,
    isCancelled: false,
    managerRemarks: '',
    createdOn: new Date().toISOString(),
    timeline: [],
    ...fields,
    roomName: roomLabel(findRoom(fields.roomId)),
  }
}

function buildSeed() {
  const day = (offset) => addDays(todayLocal(), offset)
  const mine = { ownerId: ME, requesterName: 'You', department: 'Your department' }
  const created = (hours) => entry('created', 'Request created', 'You', hours)
  const approved = (hours) =>
    entry('approved', 'Approved by the Meeting Room Manager', 'Meeting Room Manager', hours)

  const names = ['A. Mehta', 'R. Iyer', 'S. Khan', 'P. Nair', 'D. Shah', 'K. Rao']
  const departments = [
    'Finance',
    'Operations',
    'Sales',
    'Information Technology',
    'HR',
    'Marketing',
  ]
  const titles = ['Project review', 'Client call', 'Sprint planning', 'Budget meeting', 'Training']
  const others = Array.from({ length: 18 }, (_, i) => {
    const start = 8 + ((i * 5) % 9)
    return booking({
      id: `MR-2${String(i).padStart(3, '0')}`,
      roomId: rooms[(i * 3) % rooms.length].id,
      date: day(((i * 7) % 41) - 20),
      startTime: `${String(start).padStart(2, '0')}:00`,
      endTime: `${String(start + 1).padStart(2, '0')}:30`,
      title: titles[i % titles.length],
      persons: 3 + (i % 5),
      requesterName: names[i % names.length],
      department: departments[i % departments.length],
    })
  })

  return [
    booking({
      ...mine,
      id: 'MR-1001',
      roomId: 'saffron',
      date: day(3),
      startTime: '10:00',
      endTime: '11:30',
      title: 'Quarterly planning',
      persons: 8,
      additionalRequest: 'Please arrange a projector.',
      isApproved: null,
      timeline: [created(3)],
    }),
    booking({
      ...mine,
      id: 'MR-1002',
      roomId: 'blue-bell',
      date: day(1),
      startTime: '15:00',
      endTime: '16:00',
      title: 'Vendor catch-up',
      persons: 5,
      timeline: [created(30), approved(26)],
    }),
    booking({
      ...mine,
      id: 'MR-1003',
      roomId: 'executive-zone',
      date: day(2),
      startTime: '09:00',
      endTime: '10:00',
      title: 'Client visit',
      persons: 6,
      isApproved: false,
      managerRemarks: 'The room is reserved for a leadership event.',
      timeline: [
        created(50),
        entry('rejected', 'Rejected by the Meeting Room Manager', 'Meeting Room Manager', 44),
      ],
    }),
    booking({
      ...mine,
      id: 'MR-1004',
      roomId: 'daisy',
      date: day(5),
      startTime: '12:00',
      endTime: '13:00',
      title: 'Hiring panel',
      persons: 4,
      isCancelled: true,
      timeline: [
        created(80),
        approved(70),
        entry('cancelled', 'You cancelled this booking', 'You', 20),
      ],
    }),
    booking({
      ...mine,
      id: 'MR-0999',
      roomId: 'ruby',
      date: day(-3),
      startTime: '09:30',
      endTime: '10:00',
      title: 'Team stand-up',
      persons: 4,
      timeline: [created(120), approved(110)],
    }),
    ...others,
  ]
}

const delay = () => new Promise((resolve) => setTimeout(resolve, 250))
const load = () => readJson(STORAGE_KEY) ?? buildSeed()
const save = (items) => writeJson(STORAGE_KEY, items)
const sortKey = (item) => `${item.date}T${item.startTime}`

/** Only Accepted bookings block a slot; Pending ones do not. */
function findClash(items, { roomId, date, startTime, endTime, excludeId }) {
  return items.find(
    (item) =>
      item.roomId === roomId &&
      item.date === date &&
      item.id !== excludeId &&
      item.isApproved === true &&
      !item.isCancelled &&
      startTime < item.endTime &&
      endTime > item.startTime,
  )
}

function clashMessage(clash) {
  return `${clash.roomName} is already booked on ${formatDate(`${clash.date}T00:00`)} from ${formatTime(clash.startTime)} to ${formatTime(clash.endTime)}.`
}

export async function mockRooms() {
  await delay()
  return rooms
}

export async function mockList(params) {
  await delay()
  const search = (params.search ?? '').trim().toLowerCase()
  const direction = params.sort === 'dateAsc' ? 1 : -1
  const filtered = load()
    .filter(
      (item) =>
        item.ownerId === ME &&
        (!params.status || getBookingStatus(item) === params.status) &&
        (!params.from || item.date >= params.from) &&
        (!params.to || item.date <= params.to) &&
        (!search || [item.title, item.roomName, item.id].join(' ').toLowerCase().includes(search)),
    )
    .sort((a, b) => direction * sortKey(a).localeCompare(sortKey(b)))
  const start = (params.page - 1) * params.pageSize
  return { items: filtered.slice(start, start + params.pageSize), total: filtered.length }
}

export async function mockGet(id) {
  await delay()
  const found = load().find((item) => item.id === id && item.ownerId === ME)
  if (!found) throw new ApiError('Booking not found.', 404)
  return found
}

export async function mockAvailability(params) {
  await delay()
  const items = load()
  for (const date of eachDay(params.startDate, params.endDate)) {
    const clash = findClash(items, { ...params, date })
    if (clash) return { available: false, message: clashMessage(clash) }
  }
  return { available: true }
}

/** A multi-day request creates one Pending row per day. */
export async function mockCreate(input) {
  const target = findRoom(input.roomId)
  if (!target) throw new ApiError('The selected room was not found.', 404)
  if (input.persons > target.capacity) {
    throw new ApiError(`${target.name} seats up to ${target.capacity} people.`, 400)
  }
  const availability = await mockAvailability(input)
  if (!availability.available) throw new ApiError(availability.message, 409)
  const stamp = Date.now()
  const created = eachDay(input.startDate, input.endDate).map((date, index) =>
    booking({
      ownerId: ME,
      requesterName: 'You',
      department: 'Your department',
      id: `MR-${stamp}-${index + 1}`,
      roomId: input.roomId,
      date,
      startTime: input.startTime,
      endTime: input.endTime,
      title: input.title,
      persons: input.persons,
      additionalRequest: input.additionalRequest,
      isApproved: null,
      timeline: [liveEntry('created', 'Request created')],
    }),
  )
  save([...created, ...load()])
  return created
}

export async function mockUpdate(id, input) {
  await delay()
  const items = load()
  const existing = items.find((item) => item.id === id && item.ownerId === ME)
  if (!existing) throw new ApiError('Booking not found.', 404)
  if (getBookingStatus(existing) !== 'Pending') {
    throw new ApiError('Only pending bookings can be edited.', 400)
  }
  const target = findRoom(input.roomId)
  if (!target) throw new ApiError('The selected room was not found.', 404)
  if (input.persons > target.capacity) {
    throw new ApiError(`${target.name} seats up to ${target.capacity} people.`, 400)
  }
  const clash = findClash(items, { ...input, excludeId: id })
  if (clash) throw new ApiError(clashMessage(clash), 409)
  const updated = {
    ...existing,
    ...input,
    roomName: roomLabel(target),
    timeline: [...existing.timeline, liveEntry('edited', 'Booking details updated')],
  }
  save(items.map((item) => (item.id === id ? updated : item)))
  return updated
}

export async function mockCancel(id) {
  await delay()
  const items = load()
  const existing = items.find((item) => item.id === id && item.ownerId === ME)
  if (!existing) throw new ApiError('Booking not found.', 404)
  const updated = {
    ...existing,
    isCancelled: true,
    timeline: [...existing.timeline, liveEntry('cancelled', 'You cancelled this booking')],
  }
  save(items.map((item) => (item.id === id ? updated : item)))
  return updated
}

export async function mockAddComment(id, message) {
  await delay()
  const items = load()
  const existing = items.find((item) => item.id === id && item.ownerId === ME)
  if (!existing) throw new ApiError('Booking not found.', 404)
  const added = liveEntry('comment', message)
  save(
    items.map((item) =>
      item.id === id ? { ...existing, timeline: [...existing.timeline, added] } : item,
    ),
  )
  return added
}

export async function mockCalendar({ from, to, roomId }) {
  await delay()
  return load()
    .filter(
      (item) =>
        item.isApproved === true &&
        !item.isCancelled &&
        item.date >= from &&
        item.date <= to &&
        (!roomId || item.roomId === roomId),
    )
    .sort((a, b) => sortKey(a).localeCompare(sortKey(b)))
    .map((item) => ({
      id: item.id,
      roomId: item.roomId,
      roomName: item.roomName,
      date: item.date,
      startTime: item.startTime,
      endTime: item.endTime,
      title: item.title,
      requesterName: item.requesterName,
      department: item.department,
      isMine: item.ownerId === ME,
    }))
}

export async function mockInsights({ from, to }) {
  await delay()
  const inRange = load().filter((item) => item.date >= from && item.date <= to)
  const approved = inRange.filter((item) => item.isApproved === true && !item.isCancelled)
  const roomCounts = new Map()
  const hourCounts = new Map()
  const dayCounts = new Map()
  for (const item of approved) {
    roomCounts.set(item.roomId, (roomCounts.get(item.roomId) ?? 0) + 1)
    const first = Math.floor(toMinutes(item.startTime) / 60)
    const last = Math.ceil(toMinutes(item.endTime) / 60)
    for (let hour = first; hour < last; hour++) {
      hourCounts.set(hour, (hourCounts.get(hour) ?? 0) + 1)
    }
    const dayIndex = weekdayIndex(item.date)
    dayCounts.set(dayIndex, (dayCounts.get(dayIndex) ?? 0) + 1)
  }
  const byStatus = { Pending: 0, Accepted: 0, Rejected: 0, Cancelled: 0 }
  for (const item of inRange) {
    if (item.ownerId === ME) byStatus[getBookingStatus(item)] += 1
  }
  return {
    byRoom: [...roomCounts]
      .map(([roomId, count]) => {
        const found = findRoom(roomId)
        return { roomId, roomName: found?.name ?? roomId, location: found?.location ?? '', count }
      })
      .sort((a, b) => b.count - a.count || a.roomName.localeCompare(b.roomName)),
    byHour: [...hourCounts].map(([hour, count]) => ({ hour, count })),
    byWeekday: [...dayCounts].map(([day, count]) => ({ day, count })),
    byStatus,
  }
}
