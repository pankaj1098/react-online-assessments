import { describe, expect, it } from 'vitest'
import { addDays, todayLocal } from '../format'
import { bookingFormSchema } from './meetingRoom.schemas'

const valid = {
  title: 'Weekly sync',
  persons: '5',
  additionalRequest: '',
  startDate: addDays(todayLocal(), 3),
  endDate: '',
  startTime: '10:00',
  endTime: '11:00',
  roomId: 'saffron',
}

describe('bookingFormSchema', () => {
  it('accepts a single-day request with no end date', () => {
    expect(bookingFormSchema.safeParse(valid).success).toBe(true)
  })
  it('rejects an end time that is not after the start time', () => {
    const result = bookingFormSchema.safeParse({ ...valid, endTime: '10:00' })
    expect(result.success).toBe(false)
    expect(result.error?.issues[0]?.message).toBe('End time must be after the start time.')
  })
  it('rejects an end date before the start date', () => {
    const result = bookingFormSchema.safeParse({ ...valid, endDate: addDays(todayLocal(), 1) })
    expect(result.success).toBe(false)
  })
})
