import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'

export const useUiStore = create()(
  persist(
    (set) => ({
      sidebarCollapsed: false,
      mobileNavOpen: false,
      applicationSearch: '',
      toggleSidebar: () => set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
      setMobileNavOpen: (open) => set({ mobileNavOpen: open }),
      setApplicationSearch: (value) => set({ applicationSearch: value }),
    }),
    {
      name: 'ib-portal-ui',
      storage: createJSONStorage(() => window.localStorage),
      partialize: ({ sidebarCollapsed }) => ({ sidebarCollapsed }),
    },
  ),
)
