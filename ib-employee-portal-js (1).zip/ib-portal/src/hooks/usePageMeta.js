import { useEffect } from 'react'
import { buildTitle, site } from '@/config/site'

/**
 * Sets the browser tab title and meta description for the current page.
 * Every page calls this once so each one has a unique title and description.
 */
export function usePageMeta(title, description = site.description) {
  useEffect(() => {
    document.title = buildTitle(title)
    document.querySelector('meta[name="description"]')?.setAttribute('content', description)
  }, [title, description])
}
