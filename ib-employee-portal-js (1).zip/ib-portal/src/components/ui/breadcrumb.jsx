import { Slot } from '@radix-ui/react-slot'
import { ChevronRight } from 'lucide-react'
import { cn } from '@/lib/utils'

function Breadcrumb(props) {
  return <nav aria-label="Breadcrumb" {...props} />
}

function BreadcrumbList({ className, ...props }) {
  return (
    <ol
      className={cn('flex flex-wrap items-center gap-2 text-sm text-muted-foreground', className)}
      {...props}
    />
  )
}

function BreadcrumbItem({ className, ...props }) {
  return <li className={cn('inline-flex items-center gap-2', className)} {...props} />
}

function BreadcrumbLink({ asChild, className, ...props }) {
  const Comp = asChild ? Slot : 'a'
  return (
    <Comp
      className={cn('inline-flex items-center gap-2 text-foreground hover:underline', className)}
      {...props}
    />
  )
}

function BreadcrumbPage({ className, ...props }) {
  return (
    <span aria-current="page" className={cn('font-medium text-foreground', className)} {...props} />
  )
}

function BreadcrumbSeparator({ className, ...props }) {
  return (
    <li
      role="presentation"
      aria-hidden="true"
      className={cn('flex [&_svg]:size-4', className)}
      {...props}
    >
      <ChevronRight />
    </li>
  )
}

export {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
}
