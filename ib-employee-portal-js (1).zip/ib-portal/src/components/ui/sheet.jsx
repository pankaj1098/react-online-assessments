import * as DialogPrimitive from '@radix-ui/react-dialog'
import { cn } from '@/lib/utils'
import { DialogOverlay } from './dialog'

const Sheet = DialogPrimitive.Root

const SheetTitle = DialogPrimitive.Title

const SheetDescription = DialogPrimitive.Description

/** Slide-in panel from the left edge (used for the mobile navigation drawer). */
function SheetContent({ className, children, ...props }) {
  return (
    <DialogPrimitive.Portal>
      <DialogOverlay />
      <DialogPrimitive.Content
        className={cn(
          'fixed inset-y-0 left-0 z-50 w-sidebar max-w-[85vw] animate-slide-in-left bg-sidebar text-sidebar-foreground shadow-xl',
          className,
        )}
        {...props}
      >
        {children}
      </DialogPrimitive.Content>
    </DialogPrimitive.Portal>
  )
}

export { Sheet, SheetContent, SheetDescription, SheetTitle }
