export function EmptyState({ children }) {
  return (
    <p className="col-span-full px-4 py-8 text-center text-sm text-muted-foreground">{children}</p>
  )
}
