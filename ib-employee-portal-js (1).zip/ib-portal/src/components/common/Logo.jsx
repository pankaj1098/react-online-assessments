import logoUrl from '@/assets/ib-group-logo.svg'
import { cn } from '@/lib/utils'

/** The single place that imports the logo file. Swap the asset to rebrand. */
export function Logo({ className, alt = 'IB Group logo' }) {
  return (
    <img
      src={logoUrl}
      alt={alt}
      width={64}
      height={64}
      className={cn('rounded-full bg-white object-contain', className)}
    />
  )
}
