import { Card } from '@/components/ui/card'
import { cn } from '@/lib/utils'

/** Page header. Renders the page's single <h1>. */
export function PageHero({ icon, title, description, action, variant = 'card' }) {
  const content = (
    <div
      className={cn(
        'flex flex-wrap items-center gap-4 bg-gradient-to-br from-card from-55% to-primary-soft/60 p-5 sm:gap-5 sm:p-6',
        variant === 'embedded' && 'border-b border-border',
      )}
    >
      <div
        aria-hidden="true"
        className="grid size-16 shrink-0 place-items-center rounded-2xl bg-primary-soft text-primary sm:size-20 [&_svg]:size-8 sm:[&_svg]:size-10"
      >
        {icon}
      </div>
      <div className="min-w-0 flex-1">
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{title}</h1>
        <p className="mt-1.5 text-muted-foreground">{description}</p>
      </div>
      {action}
    </div>
  )
  if (variant === 'embedded') return content
  return <Card className="mb-5 overflow-hidden">{content}</Card>
}
