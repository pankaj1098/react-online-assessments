import { useAbility } from '@casl/react'
import { ChevronDown, Search, X } from 'lucide-react'
import { useState } from 'react'
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom'
import { Logo } from '@/components/common/Logo'
import { findModuleTrail, modules } from '@/config/modules'
import { cn } from '@/lib/utils'
import { useUiStore } from '@/stores/uiStore'

/** One sidebar row. If the module has sub modules it gets an expand button and nests them. */
function SidebarItem({ module, collapsed = false, depth = 0, onNavigate }) {
  const ability = useAbility()
  const { pathname } = useLocation()
  // null = follow the URL (open while you are inside this branch); true/false = user's choice.
  const [toggled, setToggled] = useState(null)
  const children = (module.children ?? []).filter((child) => ability.can('view', child.id))
  const hasChildren = children.length > 0 && !collapsed
  const inBranch = findModuleTrail(pathname).some((item) => item.id === module.id)
  const expanded = hasChildren && (toggled ?? inBranch)
  const Icon = module.icon
  return (
    <li>
      <div className="relative">
        <NavLink
          to={module.path}
          // Parents match their own page only, so the highlight moves to the sub module.
          end={module.path === '/' || children.length > 0}
          onClick={onNavigate}
          title={module.name}
          className={({ isActive }) =>
            cn(
              'flex items-center rounded-xl transition-colors',
              depth === 0 ? 'min-h-12 gap-4 text-base' : 'min-h-10 gap-3 text-sm',
              collapsed ? 'justify-center' : depth === 0 ? 'px-4' : 'px-3',
              hasChildren && 'pr-12',
              isActive
                ? 'bg-sidebar-active font-bold text-sidebar-active-foreground shadow-sm'
                : cn('text-sidebar-foreground hover:bg-sidebar-hover', inBranch && 'font-bold'),
            )
          }
        >
          {Icon && <Icon className="size-5.5 shrink-0" aria-hidden="true" />}
          <span className={cn(collapsed && 'sr-only')}>{module.name}</span>
        </NavLink>
        {hasChildren && (
          <button
            type="button"
            aria-expanded={expanded}
            aria-label={`${expanded ? 'Collapse' : 'Expand'} ${module.name}`}
            onClick={() => setToggled(!expanded)}
            className="absolute top-1/2 right-2 -translate-y-1/2 rounded-lg p-2 hover:bg-sidebar-hover"
          >
            <ChevronDown
              className={cn('size-4 transition-transform', expanded && 'rotate-180')}
              aria-hidden="true"
            />
          </button>
        )}
      </div>
      {expanded && (
        <ul className="mt-1 mb-1 ml-9 grid gap-1 border-l border-sidebar-border pl-2">
          {children.map((child) => (
            <SidebarItem key={child.id} module={child} depth={depth + 1} onNavigate={onNavigate} />
          ))}
        </ul>
      )}
    </li>
  )
}

export function SidebarContent({ collapsed = false, onNavigate }) {
  const ability = useAbility()
  const navigate = useNavigate()
  const { pathname } = useLocation()
  const search = useUiStore((state) => state.applicationSearch)
  const setSearch = useUiStore((state) => state.setApplicationSearch)
  function handleSearch(value) {
    setSearch(value)
    // Applications live on the home page, so show them as soon as the user searches.
    if (value && pathname !== '/') navigate('/')
  }
  return (
    <div className="flex h-full flex-col">
      <Link
        to="/"
        onClick={onNavigate}
        className={cn(
          'flex h-topbar shrink-0 items-center gap-3 border-b border-sidebar-border text-xl font-bold whitespace-nowrap',
          collapsed ? 'justify-center px-3' : 'px-6',
        )}
      >
        <Logo alt="" className="size-10 shrink-0" />
        <span className={cn(collapsed && 'sr-only')}>IB GROUP</span>
        {collapsed && <span className="sr-only">Home</span>}
      </Link>

      {!collapsed && (
        <search className="mx-3 mt-6 mb-3">
          <label className="flex h-10 items-center gap-2 rounded-lg border border-white/30 bg-white/10 px-2.5 focus-within:border-white/70">
            <Search className="size-4 shrink-0" aria-hidden="true" />
            <span className="sr-only">Search applications</span>
            <input
              type="search"
              value={search}
              onChange={(event) => handleSearch(event.target.value)}
              placeholder="Search applications..."
              autoComplete="off"
              className="min-w-0 flex-1 bg-transparent text-sm text-white outline-none placeholder:text-white/75 [&::-webkit-search-cancel-button]:hidden"
            />
            {search && (
              <button
                type="button"
                aria-label="Clear search"
                onClick={() => setSearch('')}
                className="rounded p-0.5 hover:bg-white/15"
              >
                <X className="size-3.5" aria-hidden="true" />
              </button>
            )}
          </label>
        </search>
      )}

      <nav
        aria-label="Main navigation"
        className={cn('flex-1 overflow-y-auto px-2.5 pb-6', collapsed && 'pt-6')}
      >
        <ul className="grid gap-1.5">
          {modules
            .filter((module) => ability.can('view', module.id))
            .map((module) => (
              <SidebarItem
                key={module.id}
                module={module}
                collapsed={collapsed}
                onNavigate={onNavigate}
              />
            ))}
        </ul>
      </nav>
    </div>
  )
}
