import { z } from 'zod'

const envSchema = z.object({
  VITE_API_BASE_URL: z.string().min(1).default('/api'),
})

const parsed = envSchema.safeParse(import.meta.env)

if (!parsed.success) {
  throw new Error(`Invalid environment configuration: ${z.prettifyError(parsed.error)}`)
}

/** Validated, typed environment values. Import this instead of `import.meta.env`. */
export const env = {
  apiBaseUrl: parsed.data.VITE_API_BASE_URL.replace(/\/+$/, ''),
}
