import {
  FileText,
  House,
  Megaphone,
  Monitor,
  Receipt,
  Settings,
  UserRound,
  Users,
} from 'lucide-react'

/**
 * Every area of the portal. Drives the sidebar, routes and permission checks.
 * A module can have `children` (sub modules), and those can have their own `children`.
 */
export const modules = [
  {
    id: 'home',
    name: 'Home',
    path: '/',
    icon: House,
    summary: 'Your applications and notifications.',
  },
  {
    id: 'hr',
    name: 'HR',
    path: '/hr',
    icon: Users,
    summary: 'Human resources services and requests.',
  },
  {
    id: 'it',
    name: 'IT',
    path: '/it',
    icon: Monitor,
    summary: 'IT support, assets and access requests.',
  },
  {
    id: 'taxes',
    name: 'Taxes',
    path: '/taxes',
    icon: Receipt,
    summary: 'Tax declarations and statements.',
  },
  {
    id: 'ibigian-self-service',
    name: 'Ibigian Self Service',
    path: '/self-service',
    icon: UserRound,
    summary: 'View and manage your own employee details.',
  },
  {
    id: 'admin',
    name: 'Admin',
    path: '/admin',
    icon: Settings,
    summary: 'Office administration services.',
    children: [
      {
        id: 'travel-request',
        name: 'Travel Request',
        path: '/admin/travel-request',
        summary: 'Raise and track travel requests.',
      },
      {
        id: 'visitor-request',
        name: 'Visitor Request',
        path: '/admin/visitor-request',
        summary: 'Register visitors and track their requests.',
      },
      {
        id: 'facility-request',
        name: 'Facility Request',
        path: '/admin/facility-request',
        summary: 'Request office facilities and services.',
        children: [
          {
            id: 'facility-requests',
            name: 'Facility Requests',
            path: '/admin/facility-request/facility-requests',
            summary: 'Raise and track general facility requests.',
          },
          {
            id: 'hospitality-request',
            name: 'Hospitality Request',
            path: '/admin/facility-request/hospitality-request',
            summary: 'Request hospitality arrangements.',
          },
          {
            id: 'food-request',
            name: 'Food Request',
            path: '/admin/facility-request/food-request',
            summary: 'Request food and refreshments.',
          },
          {
            id: 'company-car-request',
            name: 'Company Car Request',
            path: '/admin/facility-request/company-car-request',
            summary: 'Request a company car.',
          },
          {
            id: 'facility-travel-request',
            name: 'Travel Request',
            path: '/admin/facility-request/travel-request',
            summary: 'Raise travel requests under facilities.',
          },
        ],
      },
      {
        id: 'gate-pass',
        name: 'Gate Pass',
        path: '/gate-pass',
        summary: 'Create, track and manage gate pass requests.',
      },
      {
        id: 'meeting-room-bookings',
        name: 'Meeting Room Bookings',
        path: '/admin/meeting-room-bookings',
        summary: 'Book and manage meeting rooms.',
      },
      {
        id: 'courier-service',
        name: 'Courier Service',
        path: '/admin/courier-service',
        summary: 'Send and track courier shipments.',
      },
      {
        id: 'house-keeping',
        name: 'House Keeping',
        path: '/admin/house-keeping',
        summary: 'Raise house keeping requests.',
      },
      {
        id: 'contact-directory',
        name: 'Contact Directory',
        path: '/admin/contact-directory',
        summary: 'Find colleagues and their contact details.',
      },
    ],
  },
  {
    id: 'corp-communication',
    name: 'Corp Communication',
    path: '/corp-communication',
    icon: Megaphone,
    summary: 'Company announcements and communication.',
  },
  {
    id: 'corporate-policies',
    name: 'Corporate Policies',
    path: '/corporate-policies',
    icon: FileText,
    summary: 'Company policies and guidelines.',
  },
]

/** All modules at every level, in order. */
export function flattenModules(list = modules) {
  return list.flatMap((module) => [module, ...flattenModules(module.children ?? [])])
}

/** Path from the top-level module down to the one matching the URL, e.g. [Admin, Gate Pass]. */
export function findModuleTrail(pathname, list = modules, trail = []) {
  let best = []
  for (const module of list) {
    if (module.path === '/') continue
    const next = [...trail, module]
    if (pathname === module.path || pathname.startsWith(`${module.path}/`)) best = next
    const deeper = findModuleTrail(pathname, module.children ?? [], next)
    if (deeper.length > best.length) best = deeper
  }
  return best
}

export function findModuleByPath(pathname) {
  return findModuleTrail(pathname).at(-1)
}
