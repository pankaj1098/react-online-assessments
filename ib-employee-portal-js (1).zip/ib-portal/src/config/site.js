/** Site-wide copy used for page titles and descriptions. */
export const site = {
  name: 'IB Group Employee Portal',
  shortName: 'IB Group',
  description:
    'IB Group Employee Portal: sign in to view your details, raise requests such as gate passes, and open IB Group workplace applications.',
  titleSeparator: ' | ',
}

/** "Gate Pass | IB Group Employee Portal" */
export function buildTitle(pageTitle) {
  return pageTitle ? `${pageTitle}${site.titleSeparator}${site.name}` : site.name
}
