/**
 * .NET Web API routes, relative to VITE_API_BASE_URL.
 * Adjust these to match the real controllers - this is the only file that knows the URLs.
 */
export const endpoints = {
  auth: {
    login: '/auth/login',
    refresh: '/auth/refresh',
    logout: '/auth/logout',
  },
  dashboard: {
    announcements: '/announcements',
    notifications: '/notifications',
  },
  gatePass: {
    collection: '/gate-passes',
    item: (id) => `/gate-passes/${encodeURIComponent(id)}`,
  },
  meetingRooms: {
    rooms: '/meeting-rooms', // enabled rooms only (old: AutoComplete?source=GetMeetingRooms)
    bookings: '/meeting-room-bookings', // GET = my bookings, POST = create
    item: (id) => `/meeting-room-bookings/${encodeURIComponent(id)}`, // details, edit
    cancel: (id) => `/meeting-room-bookings/${encodeURIComponent(id)}/cancel`,
    comments: (id) => `/meeting-room-bookings/${encodeURIComponent(id)}/comments`, // UpdateDetails
    calendar: '/meeting-room-bookings/calendar', // approved bookings as events
    availability: '/meeting-room-bookings/availability', // CheckMeetingRoomAvailability, 409 on clash
    insights: '/meeting-room-bookings/insights',
  },
}
